## Feature 1.5: Pre-purchase Offers (Storefront "Add to Cart" Popup) - Example & Conceptual Guide

**Source URL (Primary for Theme App Extensions Concept):** https://shopify.dev/docs/apps/build/online-store/theme-app-extensions
**Additional Context (Community/Conceptual - No single official tutorial for this exact scenario):** Based on search results like community discussions (e.g., modifying add-to-cart, popup discussions) and general Theme App Extension capabilities.

**Tutorial Title/Concept:** Building a Storefront "Add to Cart" Offer Popup using Theme App Extensions and JavaScript.

**Relevance to NextSell Feature:** This addresses **Feature 1.5 (Pre-purchase Offers)**, specifically the requirement for a popup to appear *on the storefront (e.g., product page, collection page) when a user clicks an "Add to Cart" button*, before proceeding to checkout. This is distinct from pre-purchase offers within the checkout flow (which use Checkout UI Extensions and are Shopify Plus specific).

**Key Learnings & Implementation Approach (Conceptual Guide):**

While Shopify doesn't provide a single, end-to-end tutorial for *this exact type* of "add to cart" popup offer using Theme App Extensions, the implementation would combine principles from Theme App Extensions and standard web development practices (JavaScript event handling, DOM manipulation, AJAX).

1.  **Theme App Extension (App Embed Block):**
    *   NextSell would create a Theme App Extension, likely using an **App Embed Block**. This type of block is suitable for injecting JavaScript that needs to run across product pages or globally to listen for events.
    *   The extension would include JavaScript assets (`assets` directory within the extension).

2.  **JavaScript Logic (Core of the Feature):**
    *   **Event Listener:** The primary task of the JavaScript is to identify and attach event listeners to all relevant "Add to Cart" buttons on the storefront. This can be challenging due to theme variations. Strategies include:
        *   Targeting common Shopify button classes/IDs (e.g., `form[action*="/cart/add"] [type="submit"]`).
        *   Providing a configuration option in the NextSell app admin for merchants to specify a CSS selector for their theme's add-to-cart buttons if default selectors fail.
    *   **Intercepting/Augmenting Cart Addition:**
        *   The script could try to `preventDefault()` on the button click, show the popup, and then if the offer is accepted/declined, programmatically submit the original product and potentially the offered product using the AJAX Cart API.
        *   Alternatively, it could let the original product be added via AJAX (if the theme supports it), listen for the successful AJAX cart update event, and then trigger the offer popup.
    *   **Popup Display:** The JavaScript would dynamically create and display a modal/popup. The content of this popup (the offer) would be based on rules configured by the merchant in the NextSell app.
    *   **Fetching Offer Configuration:** The script would need to fetch the relevant offer rules. This could be done by:
        *   The Theme App Extension embedding configuration data (as JSON) into the page when it renders (if the offers are simple or don't change too frequently per page load).
        *   The JavaScript making an asynchronous call (e.g., `fetch`) to a NextSell app proxy endpoint or a backend API to get the appropriate offer based on the product being added or current cart state.
    *   **Adding Offered Product:** If the user accepts the offer in the popup, the JavaScript would use Shopify's AJAX Cart API (`/cart/add.js`) to add the offered product(s) to the cart.

3.  **UI for the Popup:**
    *   The popup's HTML structure, CSS styling, and interactive elements (e.g., "Accept Offer," "Decline" buttons) would be part of the assets bundled with the Theme App Extension.

**How NextSell can use this approach:**

*   **Broad Compatibility:** Theme App Extensions work on all Shopify plans, making this approach suitable for a wider audience than Checkout UI Extensions.
*   **Customizable Offers:** NextSell can allow merchants to define various offer types (e.g., upsell, cross-sell, discounted item) to be presented in the popup.

**Key Considerations (since no direct tutorial):**

*   **Theme Robustness:** The biggest challenge is reliably interacting with "Add to Cart" buttons and AJAX cart behavior across many different Shopify themes. Extensive testing and potentially fallback mechanisms or clear merchant guidance on selectors would be needed.
*   **User Experience (UX):** Popups can be intrusive. NextSell should provide merchants with options to control:
    *   When and how often popups appear (e.g., once per session, only for certain products, delay before showing).
    *   The design and clarity of the popup.
    *   Ease of dismissal.
*   **Performance:** The injected JavaScript should be lightweight and optimized to avoid slowing down the storefront.
*   **Shopify's AJAX Cart API:** Deep understanding and correct usage of the AJAX Cart API are essential for adding items without page reloads and for updating the cart state that the popup might depend on.
*   **Community Examples/Third-Party Apps:** While not official Shopify tutorials, looking at how existing upsell/popup apps on the Shopify App Store function can provide clues, though their exact implementation methods might not always use Theme App Extensions or might involve more direct theme liquid modifications (which Theme App Extensions aim to avoid).

This conceptual guide, based on Theme App Extension capabilities, provides a pathway for NextSell to implement storefront "add to cart" popups. Development would involve significant custom JavaScript work.
