## Feature 1.1: Create Discounts

**Source URL:** https://shopify.dev/docs/apps/build/discounts

**Key Takeaways & Relevance:**

This Shopify documentation page, "About discounts", is a primary resource for understanding how to implement discount functionality in a Shopify app. It outlines two main approaches:

1.  **GraphQL Admin API:** This API is used to create and manage discounts that are native to Shopify. This is suitable for standard discount types like:
    *   **Automatic discounts:** Applied at checkout if prerequisites are met (e.g., Buy X Get Y, Spend X Get Y).
    *   **Code discounts:** Applied when a customer enters a discount code.
    *   The documentation specifies the necessary **access scopes**: `write_discounts` (required), and optional scopes like `read_customers`, `read_products`, `read_shipping` depending on the complexity of the discount logic.
    *   **Relevance:** This is essential for creating percentage-based, fixed-amount, and potentially free shipping discounts (if structured as a monetary discount on shipping costs that effectively makes it free).

2.  **Shopify Functions:** These allow extending Shopify's backend logic to create custom discount types not available out-of-the-box. This is more powerful for complex scenarios.
    *   **Discount Classes:** Functions can create new discount classes:
        *   **Order discount:** Applies to all merchandise in the cart (e.g., $5 off order, 20% off all products, tiered discounts by spend).
        *   **Product discount:** Applies to specific products/variants (e.g., 20% off shirts, $5 off blue shirts, BOGO-style offers like "buy 4 shirts, get 2 blue shirts free").
        *   **Shipping discount:** Applies to shipping rates (e.g., free shipping, 20% off shipping, $5 off specific shipping rates).
    *   **Relevance:** This is crucial for more advanced discount logic that might be required by NextSell, especially for complex product-specific or tiered discounts. The "free shipping" aspect of the user's request can be directly addressed via Shipping discount functions or potentially via the GraphQL Admin API if it's a simple store-wide free shipping discount code/automatic discount.

**Specific Sections to Focus On:**

*   **"Build with the GraphQL Admin API" section:** For understanding how to create standard automatic and code discounts. Pay attention to the discount methods table and the required access scopes.
*   **"Build with Shopify Functions" section:** For advanced/custom discount types. The table describing Order, Product, and Shipping discount classes is particularly important.
*   **"Related mutations and queries" section:** Provides links to the specific GraphQL mutations (for creating/updating/deleting) and queries (for retrieving) discounts. This will be the reference for actual API calls.
*   **"Admin UI extensions vs. Remix App UI" section:** This is important for deciding how the merchant will configure these discounts within the Shopify admin. For NextSell, providing a good merchant experience is key, so understanding these options is vital.
*   **"Limitations" section:** Notes constraints like the maximum number of automatic app discounts (25 per store) and general Shopify Functions limitations.
*   **"Getting started" tutorials:** Links to practical examples like "Build a product discount function" and "Build a discount function with an Admin UI extension" will be very helpful for implementation.

**Opinion/Further Considerations:**

*   The app will likely need to use a combination of the GraphQL Admin API for simpler discount types and Shopify Functions for more complex, custom discount logic to meet all potential merchant needs.
*   The choice between Admin UI extensions and a Remix App UI for the merchant interface will depend on the complexity of the discount configuration NextSell aims to offer. If it's highly customizable, a Remix App UI might be better, but Admin UI extensions offer tighter integration with the Shopify admin.
*   The documentation clearly states the need for `write_discounts` scope. This must be requested during app installation.
