## Feature 1.2: Local Delivery & In-Store Pickup Selector (Part 2: Local Delivery & Checkout UI)

**Source URL:** https://shopify.dev/docs/api/checkout-ui-extensions/2024-10/apis/delivery

**Key Takeaways & Relevance:**

This documentation page, "Delivery API" under Checkout UI Extensions, provides information on how to interact with and customize the presentation of delivery and shipping options during the checkout process. This is highly relevant for the "local delivery ... selector" part of the requirement, especially for influencing how these options are displayed or augmented in the checkout.

1.  **Checkout UI Extensions:** The core concept here is using Checkout UI Extensions to modify the checkout experience. These extensions allow apps to inject custom UI and logic into various parts of the checkout flow.
2.  **Interacting with Delivery Groups:** The API provides access to `deliveryGroups`, which contain information about the delivery of items. Your app can use this data to make decisions or display custom information related to local delivery.
    *   `useDeliveryGroups()`: Hook to get all delivery groups.
    *   `useDeliveryGroup(deliveryGroup)`: Hook to get details of a specific delivery group.
3.  **Modifying Shipping Option Display:** The API allows interaction with shipping options, which is key for a "selector".
    *   Relevant extension targets include:
        *   `purchase.checkout.shipping-option-item.render-after`: To add custom UI after a specific shipping option.
        *   `purchase.checkout.shipping-option-item.details.render`: To render custom details for a shipping option.
        *   `purchase.checkout.shipping-option-list.render-before` / `render-after`: To add UI before or after the entire list of shipping options.
    *   `useShippingOptionTarget()`: Hook to get data about the specific shipping option the extension is attached to.
4.  **Pickup Points/Locations:** The API also has specific objects and hooks for pickup points and locations, which complements the "Local Pickup Delivery Option Generator API" by allowing UI customization for these in checkout.
    *   Extension targets like `purchase.checkout.pickup-point-list.render-after` and `purchase.checkout.pickup-location-list.render-after`.
    *   `usePickupLocationOptionTarget()`: Hook for pickup location options.

**Specific Sections to Focus On:**

*   The introductory warning: "Not all extension targets implement all APIs. Check the documentation for the extension target you are using to see which APIs are available." This is crucial for ensuring compatibility.
*   **StandardApi** section: Specifically the `deliveryGroups` property.
*   Hooks like `useDeliveryGroups`, `useDeliveryGroup`, `useShippingOptionTarget`, `useDeliveryGroupListTarget`, and `usePickupLocationOptionTarget`.
*   The various **extension targets** mentioned (e.g., `purchase.checkout.shipping-option-item.render-after`, `purchase.checkout.pickup-location-list.render-after`). Understanding where your UI can be injected is fundamental.

**Opinion/Further Considerations:**

*   **Complementary to Shopify Functions:** While Shopify Functions (like the Local Pickup Delivery Option Generator) can define *what* delivery/pickup options are available and their logic (e.g., cost, availability), Checkout UI Extensions handle *how* these options are presented and interacted with by the customer during checkout. NextSell will likely need both: Functions to define the delivery/pickup methods and Checkout UI Extensions to create a rich selector experience if the native display isn't sufficient.
*   **User Experience:** These APIs allow for a much more integrated and native-feeling user experience for selecting delivery options directly within the Shopify checkout, which is generally preferred over redirecting the user or using less integrated methods.
*   **Complexity:** Building Checkout UI Extensions requires understanding React and Shopify's specific extension framework. The learning curve might be steeper than simple Admin API interactions.
*   **Local Delivery Logic:** This API primarily deals with the *presentation* and *interaction* within the checkout. The actual *logic* for determining local delivery eligibility (e.g., based on postal codes, distance, cart contents) would typically reside in a Shopify Function (like a custom shipping rate generator) or be configured via the Shopify Admin (for native local delivery settings). The Checkout UI extension would then consume and present these options.
*   The documentation provides React-based examples, indicating that UI extensions are built using this library.

This API is key for building the "selector" for local delivery and in-store pickup directly within the checkout flow, making the experience seamless for the customer.
