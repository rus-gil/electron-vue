## Feature 1.5: Pre-purchase Offers (Popup on Add to Cart - Part 1: Checkout Pre-purchase Offers)

**Source URL:** https://shopify.dev/docs/apps/build/checkout/product-offers/build-a-pre-purchase-offer

**Key Takeaways & Relevance:**

This tutorial, "Build a pre-purchase product offer checkout extension," explains how to create upsell offers that appear to customers *during the checkout process* before they complete their purchase. This is one way to implement "pre-purchase offers," specifically those integrated into the checkout flow.

1.  **Mechanism (Checkout UI Extensions):** The primary method described is using Checkout UI Extensions. These allow apps to add custom UI and logic directly into the Shopify checkout pages.
    *   **Relevance:** This is suitable for presenting offers (like adding an additional product, possibly discounted) once the customer has initiated checkout. The user specifically requested a popup "when user clicks on add to cart button." While this tutorial focuses on offers *within* checkout, the principles of using Checkout UI extensions for offers are relevant. However, triggering a popup *immediately upon an add-to-cart action (before checkout)* might require a different approach, such as Theme App Extensions or JavaScript listeners on the storefront theme.

2.  **Shopify Plus Requirement:** Similar to other advanced checkout customizations, "Checkout UI extensions are available only to Shopify Plus merchants." This is a critical limitation.

3.  **Functionality Covered:**
    *   Generating a checkout UI extension.
    *   Configuring the extension (TOML file).
    *   Querying the Storefront API to get product data for offers.
    *   Using Checkout UI components to build the offer interface.
    *   Using Checkout UI extension APIs to read cart information and apply changes (add offered products to the cart).

4.  **Extension Targets:** The tutorial uses `purchase.checkout.block.render` as a target, which allows merchants to place the extension block using the checkout editor. Static targets can also be used for fixed placement.

**Specific Sections to Focus On:**

*   **"What you'll learn" section:** Provides a good overview of the capabilities.
*   **"Requirements" section:** Highlights the Shopify Plus dependency and the need for the Checkout and Customer Accounts Extensibility developer preview.
*   **"Set up an extension target" section:** Explains how to define where the offer appears in checkout.
*   **"Retrieve product data" and "Retrieve cart data" sections:** Crucial for dynamically populating offers and checking cart contents.
*   **"Build the pre-purchase offer UI" and "Add add-to-cart functionality" sections:** Detail the use of UI components and APIs to present the offer and add items to the cart (`useApplyCartLinesChange` hook).
*   **UX Guidelines:** The document links to "product offer checkout UI extension UX guidelines," which should be reviewed for best practices in designing these offers.

**Opinion/Further Considerations for Pre-purchase Offers (especially "on add to cart popup")**

*   **Checkout vs. Storefront Popups:** This documentation primarily addresses offers *within the checkout*. For a popup that appears *immediately* when a user clicks "Add to Cart" (before reaching checkout), other mechanisms are likely needed:
    *   **Theme App Extensions (App Blocks):** These allow apps to add sections or snippets to theme files. An app block could potentially listen for add-to-cart events (e.g., using JavaScript and Shopify's AJAX Cart API if the theme uses it) and trigger a modal/popup.
    *   **Custom JavaScript in the Theme:** If direct theme modification is an option (less ideal for a public app), JavaScript could be added to intercept add-to-cart actions.
    *   **Cart Page Customization:** Offers could also be presented on the cart page itself using theme app extensions for the cart.
*   **Shopify Plus Limitation:** The Checkout UI Extension approach for pre-purchase offers is limited to Shopify Plus. If NextSell needs to support non-Plus stores for this feature, alternative storefront-based solutions are essential.
*   **Offer Logic:** The app will need a robust system for merchants to define which products trigger offers, what products are offered, any conditions (e.g., cart value, specific items in cart), and any discounts associated with the offer. This configuration would likely be managed within the app's admin interface and stored via metafields or the app's backend.
*   **User Experience:** Popups can be intrusive if not implemented well. The timing, design, and ease of dismissal are critical. The offer should be genuinely valuable to the customer.

**Next Steps for this specific feature part:**
While this document covers pre-purchase offers in checkout, further research is needed for implementing a popup specifically triggered by the "add to cart" button on product or collection pages, likely involving Theme App Extensions and storefront JavaScript APIs.

