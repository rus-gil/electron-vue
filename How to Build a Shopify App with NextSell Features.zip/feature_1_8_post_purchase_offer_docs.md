## Feature 1.8: Post-purchase Offer

**Source URL:** https://shopify.dev/docs/api/checkout-extensions/post-purchase/api

**Key Takeaways & Relevance:**

This documentation page, "Post-purchase extension points API," is the definitive guide for implementing post-purchase offers. These offers are presented to the customer *after* they have completed their payment for the initial order but *before* they see the final order confirmation/status page.

1.  **Mechanism (Post-purchase Checkout Extensions):**
    *   These extensions allow apps to add a new page directly into the Shopify checkout flow, specifically after payment confirmation.
    *   **Relevance:** This is precisely for implementing post-purchase upsells or cross-sells. The customer has already committed to a purchase, making them potentially receptive to a relevant, easy-to-add offer.

2.  **Shopify Plus Requirement:** The documentation states, "Post-purchase checkout extensions allow developers and Plus merchants to add a post-purchase page..."
    *   **Relevance:** This functionality is limited to Shopify Plus merchants. This is a critical constraint for NextSell if it aims to offer this feature to all Shopify users.

3.  **Key Extension Points & APIs:**
    *   `Checkout::PostPurchase::ShouldRender`: This extension point is used to determine *if* the post-purchase page (and thus the offer) should be shown to the customer. It can also be used to pre-cache data needed for the offer page.
        *   Input: `PostPurchaseShouldRenderApi` (includes `inputData` like initial purchase details, and `storage` for app data).
        *   Output: `PostPurchaseShouldRenderResult` (indicates if to render and can pass data to the render step).
    *   `Checkout::PostPurchase::Render`: This extension point is used to actually render the UI of the post-purchase offer page.
        *   Input: `PostPurchaseRenderApi` (includes `inputData`, `storage`, and crucial functions like `calculateChangeset`, `applyChangeset`, and `done`).
        *   `calculateChangeset`: Allows the app to show the customer the financial impact of accepting the offer (e.g., new total, added items) *before* they accept.
        *   `applyChangeset`: If the customer accepts the offer, this function is called to add the new item(s) to their already completed order and charge them for the difference. This is a key feature, enabling one-click post-purchase additions.
        *   `done`: Called when the extension has finished its work, redirecting the customer to the order status page.

4.  **Changesets:** This is a core concept. A changeset represents the modifications (e.g., adding a product variant) to the initial purchase. The API allows calculating the impact of these changes and then applying them.

**Specific Sections to Focus On:**

*   The introductory paragraph explaining the purpose and placement of post-purchase extensions.
*   The descriptions of the `Checkout::PostPurchase::ShouldRender` and `Checkout::PostPurchase::Render` extension points.
*   The details of `PostPurchaseShouldRenderApi` and especially `PostPurchaseRenderApi`, paying close attention to `calculateChangeset`, `applyChangeset`, and `done` methods.
*   The structure of `CalculatedPurchase` to understand what data is available after a changeset calculation.
*   Error handling, as described by `ChangesetError` and the status results of applying changesets.

**Opinion/Further Considerations for Post-purchase Offers:**

*   **One-Click Upsell Power:** The ability to add items to an already paid order with a single click (via `applyChangeset`) is very powerful and can significantly increase Average Order Value (AOV).
*   **Shopify Plus Limitation:** This is a major constraint. For non-Plus stores, true post-purchase upsells integrated into the checkout are not possible with this method. Alternatives might involve email marketing immediately after an order or custom solutions on the thank-you page (which is less integrated than these extensions).
*   **Offer Logic:** The app (NextSell) will need a robust backend to determine which post-purchase offer is most relevant based on the customer's initial order, customer history, etc. This logic will be invoked by the `ShouldRender` extension point.
*   **User Experience:** The offer must be presented clearly, the value proposition must be obvious, and the process of accepting must be seamless. Since the customer has already paid, trust and transparency are paramount. The UX guidelines for these extensions should be carefully followed.
*   **Payment Processing:** The `applyChangeset` handles the additional charge. The app doesn't need to deal directly with payment gateways for the upsell amount; Shopify manages this.
*   **Inventory Management:** The app should ensure that offered products have sufficient inventory before presenting the offer.

Post-purchase extensions offer a highly effective way to increase AOV, but their availability is restricted to Shopify Plus merchants. This is a key piece of information for the user when planning NextSell.
