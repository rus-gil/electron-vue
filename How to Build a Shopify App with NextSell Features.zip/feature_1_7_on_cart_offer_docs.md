## Feature 1.7: On Cart Offer

**Source URL (Primary for Theme App Extensions):** https://shopify.dev/docs/apps/build/online-store/theme-app-extensions

**Key Takeaways & Relevance:**

Similar to displaying offers on the Product Detail Page (PDP), Theme App Extensions are the recommended Shopify-native method for presenting offers directly on the cart page (or in a cart drawer/modal if the theme uses one).

1.  **Mechanism (Theme App Extensions):**
    *   NextSell would provide a theme app extension (likely an **App Block**) that merchants can add to their cart page template via the Shopify theme editor.
    *   This block would render the offer based on the current cart contents and merchant-defined rules.
    *   **Relevance:** This directly addresses the need to display offers on the cart page. Examples include: "Spend $X more to get free shipping," "Add Product Y for a special price with your current order," or volume-based offers like "Add one more of Item Z to get 10% off all Item Zs."

2.  **Accessing Cart Data:** The theme app extension, using Liquid and potentially JavaScript, can access the current cart object (`cart`) to understand its contents (items, total price, item count, etc.). This information is crucial for determining which offer, if any, should be displayed.
    *   `cart.items`: Array of line items in the cart.
    *   `cart.total_price`: Total price of the cart.
    *   Other cart attributes can be used to trigger specific offers.

3.  **Dynamic Offer Display:**
    *   The app block would contain Liquid logic to check conditions (e.g., cart total, presence of specific products, customer tags if accessible) and display the relevant offer.
    *   JavaScript within the app block can be used for more dynamic interactions or to fetch offer details from the app's backend if the logic is too complex for Liquid alone or if real-time checks are needed (e.g., inventory for an offered product).

4.  **Adding Offered Products/Applying Discounts:**
    *   If the offer involves adding a product to the cart, the app block would include an "Add to Cart" button for the offered item. This would typically use Shopify's AJAX Cart API to add the item without a full page reload.
    *   If the offer is a discount that should apply based on cart contents (e.g., a cart-level discount once a spending threshold is met), this might involve:
        *   Displaying information about an *automatic discount* that will apply at checkout (if the discount is configured via Shopify's discount engine and the conditions are met by the cart).
        *   If using Shopify Functions for discounts, the cart page offer could inform the user they are close to or have qualified for a special discount that the Function will apply at checkout.
        *   For more direct cart-level discount application *before* checkout (which is less common for automatic application via APIs directly on the cart page itself), it might involve guiding the user to apply a discount code or using more complex cart transformation techniques if available (though Cart Transforms API is more for checkout).

**Specific Sections from Theme App Extension Docs to Focus On:**

*   **"App blocks"**: As these are ideal for merchants to place content in specific sections of their cart page.
*   **Liquid templating capabilities**: For accessing `cart` object attributes and rendering conditional content.
*   **JavaScript usage within Assets**: For AJAX cart operations and dynamic content fetching.

**Opinion/Further Considerations for On-Cart Offers:**

*   **Clarity of "Cart Offer":** The user mentioned "on cart offer" and then later "cart offer" again. It's important to clarify if these are the same or if the second "cart offer" refers to something more specific like cart-level discounts (which are often applied at checkout or via discount codes rather than dynamically added as an "offer" block in the same way a product upsell might be).
*   **Cart Page vs. Cart Drawer/Modal:** Many themes now use a cart drawer or modal that slides out instead of a dedicated cart page. The theme app extension should ideally be compatible with both. App blocks can usually be added to sections that are part of these drawers/modals if the theme is structured with Online Store 2.0 principles.
*   **Shopify Scripts (Shopify Plus):** For Shopify Plus merchants, Shopify Scripts (specifically line item scripts) could also be used to modify line item prices or add items to the cart based on cart contents. However, Theme App Extensions are a more modern and generally recommended approach for UI-based offers visible on the cart page for all plans.
*   **User Experience:** Offers on the cart page should be clear, concise, and easy to act upon or dismiss. They should not obstruct the primary goal of proceeding to checkout.
*   **Offer Stacking/Priority:** If multiple offers could potentially apply, the app needs a clear logic for which offer takes precedence or if multiple can be shown.

Theme App Extensions provide a flexible and integrated way to present offers on the cart page, leveraging Liquid for data access and JavaScript for dynamic interactions.
