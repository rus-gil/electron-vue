## Feature 1.6: On PDP (Product Detail Page) Offer

**Source URL:** https://shopify.dev/docs/apps/build/online-store/theme-app-extensions

**Key Takeaways & Relevance:**

This documentation page, "About theme app extensions," is highly relevant for implementing offers directly on the Product Detail Page (PDP). Theme app extensions allow apps to add dynamic content and UI elements to Shopify themes without requiring merchants to manually edit theme code.

1.  **Mechanism (Theme App Extensions):** These extensions enable apps to inject content (like an offer display) into specific parts of a theme, including product pages. Merchants can then manage these app-provided sections/blocks through the theme editor.
    *   **Relevance:** This is the primary and recommended way to display custom offers on the PDP. NextSell can create a theme app extension that merchants can add to their product page templates to show relevant offers (e.g., "Buy this and get Product Y at a discount," or "Spend $X more to unlock free shipping").

2.  **Types of Blocks:**
    *   **App Blocks:** These can be added by merchants to sections in their theme. Ideal for offers that should be placed in specific locations on the PDP (e.g., below the product description, near the add-to-cart button).
    *   **App Embed Blocks:** These are automatically active when the app is installed or can be enabled/disabled by the merchant. They are suitable for features that don't need specific placement by the merchant or that modify existing elements globally (e.g., a small banner, or script-based modifications, though for visible offers, app blocks are usually more appropriate for PDP placement).

3.  **Benefits:**
    *   **No Code Editing for Merchants:** Simplifies installation and reduces the risk of breaking themes.
    *   **Theme Editor Integration:** Merchants can configure and place the offer block visually.
    *   **Versioning and CDN Hosting:** Shopify handles deployment and asset serving.

4.  **Technology:** Theme app extensions use Liquid for templating, along with CSS and JavaScript for styling and interactivity. The app can pass data (e.g., offer details fetched from the app's backend or metafields) to the Liquid block for rendering.

**Specific Sections to Focus On:**

*   **Main description:** Understand the purpose and benefits of theme app extensions.
*   **"Theme app extensions resources" section:** Details the components: Blocks (App blocks, App embed blocks), Assets, and Snippets.
*   **"Benefits of using theme app extensions" section:** Reinforces why this is the preferred method.
*   **Links to further resources:** "Get started with theme app extensions," "Review the theme app extensions framework," and "Understand the UX guidelines for theme app extensions" are crucial next steps for implementation details.

**Opinion/Further Considerations for On-PDP Offers:**

*   **Offer Logic & Configuration:** The NextSell app will need an admin interface for merchants to define the rules for these PDP offers: what triggers them (e.g., viewing a specific product, product tags, collections), what the offer is (e.g., discounted related product, bundle offer), and how it should be displayed. This configuration would be stored by the app (metafields or backend) and accessed by the theme app extension.
*   **Dynamic Content:** The theme app extension will need to dynamically fetch and display the correct offer based on the product being viewed and the merchant's settings. This might involve using JavaScript within the extension to call the app's backend or read product/shop metafields.
*   **Adding to Cart:** If the offer involves adding another product to the cart (e.g., an upsell or cross-sell shown on the PDP), the theme app extension will need to include UI elements (like an "Add to Offer" button) and JavaScript to interact with the Shopify AJAX Cart API to add items to the cart without navigating away from the PDP.
*   **Compatibility:** Theme app extensions are designed for Online Store 2.0 themes. While most modern themes support this, it's a consideration.
*   **User Experience:** The offer should be presented clearly and non-intrusively on the PDP. It should not detract from the main product information but rather enhance the shopping experience.

This approach provides a clean, merchant-friendly way to integrate dynamic offers directly onto product detail pages.
