# Shopify App Development: NextSell - Best Practices & Key Considerations Summary

This document summarizes key considerations, best practices, and Shopify platform limitations based on the detailed documentation gathered for the NextSell app features. It aims to provide a high-level overview to guide development decisions.

## 1. Overarching Shopify Plus Limitations

A significant recurring theme is the dependency on the **Shopify Plus plan** for several advanced features that integrate deeply into the checkout process. This is a critical factor for NextSell's target market and feature set.

*   **Local Pickup Delivery Option Generator API (for custom pickup options in checkout):** Shopify Plus exclusive. (Relates to Features 1.2, 1.3, 1.4)
*   **Shopify Functions for certain delivery/pickup customizations integrated into checkout:** Often tied to Shopify Plus capabilities. (Relates to Features 1.2, 1.3, 1.4)
*   **Checkout UI Extensions (for pre-purchase offers *within* checkout & customizing delivery option display):** Shopify Plus exclusive. (Relates to Features 1.2, 1.5)
*   **Post-purchase Checkout Extensions (for one-click post-purchase upsells):** Shopify Plus exclusive. (Relates to Feature 1.8)

**Recommendation:** Clearly define if NextSell will target Shopify Plus merchants exclusively for these advanced checkout-integrated features, or if alternative solutions for non-Plus stores (often using Theme App Extensions with potentially less seamless UX) need to be developed and maintained.

## 2. Key Shopify Technologies & APIs to Leverage

NextSell will utilize a combination of Shopify APIs and extension frameworks:

*   **GraphQL Admin API:** For creating and managing standard discounts (percentage, fixed amount, BOGO, free shipping codes/automatic). Requires `write_discounts` scope. (Feature 1.1)
*   **Shopify Functions:**
    *   **Discount Functions:** For custom discount logic beyond native capabilities (e.g., complex tiered discounts, product-specific rules). (Feature 1.1)
    *   **Local Pickup Delivery Option Generators / Delivery Customization Functions:** To define custom logic for local pickup and delivery options, including potentially managing time slots and off-days. (Features 1.2, 1.3, 1.4 - often Shopify Plus for checkout integration).
*   **Theme App Extensions (Online Store 2.0):** Crucial for features visible on the storefront (PDP, Cart Page, Add-to-Cart popups) and available on all Shopify plans.
    *   **App Blocks:** For merchant-placeable UI elements (e.g., offer displays on PDP/Cart). (Features 1.5 - storefront popup, 1.6, 1.7)
    *   **App Embed Blocks:** For global scripts or features not requiring specific merchant placement (e.g., JavaScript for add-to-cart event listeners). (Feature 1.5 - storefront popup)
    *   Utilize Liquid (accessing `cart`, `product` objects), CSS, and JavaScript (AJAX Cart API for interactions).
*   **Checkout UI Extensions (Shopify Plus):** For modifying the checkout experience.
    *   Displaying custom delivery/pickup option details. (Feature 1.2)
    *   Pre-purchase offers presented *during* checkout. (Feature 1.5)
*   **Post-purchase Checkout Extensions (Shopify Plus):** For one-click upsells after payment. (Feature 1.8)
    *   Key APIs: `ShouldRender` and `Render` extension points, `applyChangeset` for adding to order.

## 3. Feature-Specific Best Practices & Considerations

### 3.1. Discounts (Feature 1.1)
*   Combine GraphQL Admin API for standard discounts and Shopify Functions for complex/custom ones.
*   Clearly define merchant UI for configuring these discounts (Admin UI Extensions or Remix App UI).
*   Be mindful of the 25 automatic app discount limit per store.

### 3.2. Local Delivery & In-Store Pickup Selector (Feature 1.2)
*   **Pickup:** Local Pickup Delivery Option Generator API (Shopify Plus) for integrated checkout options. For non-Plus, consider theme customizations or cart attributes (less ideal).
*   **Delivery:** Shopify Functions for custom delivery rates/logic. Checkout UI Extensions (Shopify Plus) to customize display in checkout.
*   Merchant UI needed for defining zones, rates, pickup locations.

### 3.3. Time Slots & Off-Days for Delivery/Pickup (Features 1.3, 1.4)
*   Leverage Shopify Functions (e.g., modifying local pickup/delivery options) to inject this logic.
*   Requires a robust merchant configuration UI within NextSell to manage schedules, slots, capacity, off-days, lead times. Store this data in app's backend or extensively use metafields.
*   The Function would read this configuration to generate available slots/dates.
*   Shopify Plus likely needed for seamless checkout integration of these options.
*   For UI (e.g., calendar pickers) within checkout, Checkout UI Extensions (Shopify Plus) would be needed.

### 3.4. Pre-purchase Offers (Popup on Add to Cart) (Feature 1.5)
*   **Storefront "Add to Cart" Popup (All Plans):**
    *   Use Theme App Extensions (App Embed Block with JavaScript).
    *   Listen for "add to cart" events (handle AJAX carts).
    *   Trigger a modal/popup built with HTML/CSS/JS.
    *   Use AJAX Cart API to add offered products.
    *   Fetch offer configuration from app backend/metafields.
    *   Prioritize UX: make popups non-intrusive, easy to dismiss. Consider frequency controls.
    *   Theme compatibility for event listening can be challenging.
*   **Pre-purchase Offer *in Checkout* (Shopify Plus):**
    *   Use Checkout UI Extensions.
    *   Follow Shopify UX guidelines for product offers.

### 3.5. On PDP (Product Detail Page) Offer (Feature 1.6)
*   Use Theme App Extensions (App Blocks primarily).
*   Merchants place the block via theme editor.
*   Dynamically display offers based on viewed product and merchant rules (fetched from app backend/metafields).
*   If offer involves adding to cart, use AJAX Cart API.

### 3.6. On Cart Offer (Feature 1.7)
*   Use Theme App Extensions (App Blocks) placed on the cart page/drawer.
*   Access `cart` object in Liquid to determine relevant offers.
*   JavaScript for dynamic interactions or adding items via AJAX Cart API.
*   Consider compatibility with cart drawers/modals.

### 3.7. Post-purchase Offer (Feature 1.8)
*   Use Post-purchase Checkout Extensions (Shopify Plus only).
*   Utilize `ShouldRender` to decide if an offer shows, and `Render` to display it.
*   Key function: `applyChangeset` for one-click additions to the paid order.
*   Offer logic resides in the app backend, fetched by the extension.
*   High importance of clear UX and trust, as customer has already paid.

## 4. General App Development Best Practices

*   **Merchant Experience (Admin UI):** Provide a clear, intuitive interface within NextSell for merchants to configure all features (discounts, delivery rules, time slots, offer conditions, etc.). Consider Shopify's Polaris design system for embedded apps.
*   **Performance:** Optimize any storefront JavaScript (from Theme App Extensions) to minimize impact on page load speed. Efficiently query data.
*   **Error Handling:** Implement robust error handling in functions and extensions (e.g., if offer data can't be fetched, if inventory is unavailable for an offer).
*   **Theme Compatibility:** For Theme App Extensions, strive for broad compatibility but acknowledge that highly customized themes might pose challenges. Provide clear instructions for merchants.
*   **API Versioning:** Keep an eye on Shopify API versions and update the app as needed.
*   **Scopes:** Request only necessary API scopes during app installation.
*   **Security:** Sanitize inputs, protect sensitive data, and follow Shopify's security best practices.
*   **Testing:** Thoroughly test all features on development stores with various themes and scenarios, including edge cases.
*   **Documentation (for Merchants):** Provide clear help documentation for merchants on how to set up and use NextSell's features.

## 5. Clarification on "Cart Offer" (User Item 1.9)

The initial request listed "on cart offer" and a separate "cart offer".
*   "On Cart Offer" (Feature 1.7) has been documented as displaying interactive offers on the cart page using Theme App Extensions.
*   If "Cart Offer" (the second mention) was intended to refer to cart-level *discounts* (e.g., automatic percentage off entire cart if subtotal > $100), these are primarily managed via the Discounts API (GraphQL Admin API or Discount Functions - Feature 1.1). The *application* of such discounts happens at checkout. The cart page can *inform* the user about these potential discounts using Theme App Extensions.

**Recommendation:** Confirm with the user if their understanding of "cart offer" is covered by these two approaches or if there's a distinct third scenario they envisioned.

This summary provides a starting point for architectural decisions and highlights key areas of attention during the development of NextSell.
