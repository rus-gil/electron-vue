## Feature 1.8: Post-purchase Offer - Example Tutorial

**Source URL:** https://shopify.dev/docs/apps/build/checkout/product-offers/build-a-post-purchase-offer

**Tutorial Title:** Build a post-purchase product offer checkout extension

**Relevance to NextSell Feature:** This tutorial is directly relevant to **Feature 1.8 (Post-purchase Offer)**. It details how to create an upsell offer that appears on the post-purchase page (after payment but before the order status page) using Post-purchase Checkout Extensions.

**Key Learnings & Implementation Steps Shown:**

1.  **Post-purchase Checkout Extension Creation:**
    *   Uses Shopify CLI to generate a new post-purchase checkout extension.
    *   Requires the Remix app template as a prerequisite for the app.

2.  **Beta Status & Access:**
    *   The tutorial notes that Post-purchase checkout extensions are in **beta**. They can be used in development stores, but **access needs to be requested** to use them on a live store.
    *   All merchants can install apps from the Shopify App Store that use these extensions, but only Shopify Plus merchants can install *custom apps* using them.

3.  **Development and Testing:**
    *   Shopify CLI `dev` command is used to run the extension locally.
    *   Testing involves using a Shopify browser extension to render local extensions in the checkout, as post-purchase extensions in production are hosted by Shopify.
    *   The extension appears after the payment step and before the order status page.

4.  **Building the Extension UI:**
    *   Uses Shopify-managed UI components for speed, mobile optimization, and Shop Pay integration.
    *   Key extension points: `Checkout::PostPurchase::ShouldRender` (to pre-fetch data and decide if the offer should show) and `Checkout::PostPurchase::Render` (to display the UI).
    *   The API provides helper functions like `calculateChangeset` (for shipping/taxes on the offered item) and `applyChangeset` (to update the order if the offer is accepted).

5.  **Server-Side Logic (Remix App):**
    *   The extension communicates with the app server (built with Remix in this tutorial).
    *   **Fetching Product Data:** The `Checkout::PostPurchase::ShouldRender` handler fetches offer product data from the app server. The tutorial hardcodes this data for simplicity but suggests it could be an API call to Shopify or a custom database.
    *   **Authenticating Requests:** Uses JWT tokens and `authenticate.public` in the Remix app to verify requests from the extension.
    *   **Signing Changesets:** The app server needs an endpoint to sign the order changes (changeset) as a JWT token before `applyChangeset` is called. This verifies to Shopify that the request to edit the order originated from the app.

6.  **Deployment and Release:**
    *   Shopify CLI `deploy` command to create and release an app version.

**How NextSell can use this:**

*   **Implementing Post-Purchase Upsells:** This is the Shopify-approved method for NextSell to offer one-click upsells after the initial payment is complete. This can be a very effective way to increase average order value.
*   **Dynamic Offer Logic:** NextSell would replace the hardcoded product data in the tutorial with dynamic logic. The app server would determine which product(s) to offer based on the original order, customer history, or merchant-defined rules.
*   **Secure Order Modification:** The changeset signing mechanism ensures that order modifications are secure and authenticated.

**Key Considerations from the Tutorial:**

*   **Beta Status & Access Request:** This is a significant hurdle. NextSell needs to be aware of the beta status and the requirement to request access for live stores. The approval process and timelines are important.
*   **Shopify Plus for Custom Apps:** If NextSell is distributed as a custom app, only Plus merchants can use this feature.
*   **Remix Template Prerequisite:** The tutorial assumes the app is built using the Remix template, which handles server-side logic and authentication.
*   **Complexity:** Involves both frontend (extension UI) and backend (Remix server for data and signing) development.
*   **UI Component Limitations:** Similar to other checkout extensions, UI is built using Shopify-provided components.

This tutorial provides a comprehensive guide for NextSell to implement post-purchase offers, a powerful feature for increasing revenue. The beta status and access requirements are the main caveats to consider.
