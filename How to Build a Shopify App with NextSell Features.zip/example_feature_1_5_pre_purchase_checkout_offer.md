## Feature 1.5: Pre-purchase Offers (Checkout UI Extension) - Example Tutorial

**Source URL:** https://shopify.dev/docs/apps/build/checkout/product-offers/build-a-pre-purchase-offer

**Tutorial Title:** Build a pre-purchase product offer checkout extension

**Relevance to NextSell Feature:** This tutorial is directly relevant to **Feature 1.5 (Pre-purchase Offers)**, specifically for implementing offers that appear *within the Shopify checkout process*. It uses Checkout UI Extensions, which are available for Shopify Plus merchants.

**Key Learnings & Implementation Steps Shown:**

1.  **Checkout UI Extension Creation:**
    *   Guides through using Shopify CLI to generate a new Checkout UI extension.
    *   Explains selecting the extension type (`Checkout UI`) and language (JavaScript example provided, React also common).

2.  **Shopify Plus Requirement:**
    *   The tutorial explicitly states: "Checkout UI extensions are available only to **Shopify Plus** merchants." This is a critical constraint for this type of pre-purchase offer.

3.  **Extension Targets:**
    *   Explains how to set up extension targets (e.g., `purchase.checkout.block.render`) in the `Checkout.js` (or similar) script file and reference them in the `shopify.extension.toml` configuration file. Targets determine where the extension renders in the checkout flow.
    *   The `purchase.checkout.block.render` target allows merchants to place the extension using the checkout editor.

4.  **Retrieving Data:**
    *   **Storefront API Access:** Shows how to configure the extension to access the Storefront API (`api_access = true` in `shopify.extension.toml`) to fetch product data (e.g., for the product being offered).
    *   **Querying Products:** Provides an example of querying the Storefront API for products.
    *   **Cart Data:** Demonstrates subscribing to cart data (`lines` property of the `StandardApi` Checkout API object) to make decisions or filter offers (e.g., don't offer a product already in the cart).

5.  **Building the UI:**
    *   Uses components from the Checkout UI component library (e.g., `SkeletonText`, `SkeletonImage` for loading states, `Banner` for errors, and other layout components) to build the offer interface.
    *   Emphasizes that Checkout UI extensions are limited to specific UI components provided by Shopify for security and a consistent merchant/buyer experience.

6.  **Adding to Cart Functionality:**
    *   Shows how to use the `applyCartLinesChange` helper function of the `StandardApi` Checkout API object to add the offered product to the cart if the customer accepts.

7.  **Development and Testing:**
    *   Details how to use Shopify CLI (`shopify app dev`) to build and preview the extension on a development store (which must have the Checkout and Customer Accounts Extensibility developer preview enabled).
    *   Explains how to test the extension's functionality by going through the checkout process.

**How NextSell can use this:**

*   **Implementing In-Checkout Upsells (Shopify Plus):** This tutorial provides the exact methodology for NextSell to offer pre-purchase upsells or cross-sells directly within the checkout flow for Shopify Plus merchants. This is often a high-conversion point.
*   **Dynamic Offer Logic:** NextSell can adapt the data retrieval logic to fetch specific products to offer based on cart contents, customer data, or merchant-defined rules (configured in the NextSell app admin).
*   **UI Customization (within limits):** While restricted to Shopify's Checkout UI components, NextSell can still design an effective and branded offer presentation.

**Key Considerations from the Tutorial:**

*   **Shopify Plus Exclusivity:** This is the most significant limitation. For non-Plus stores, pre-purchase offers *within checkout* are not possible using this method. (Storefront popups on "add to cart" via Theme App Extensions are the alternative for non-Plus, as documented separately).
*   **Checkout and Customer Accounts Extensibility Preview:** Development stores need this enabled.
*   **Limited UI Components:** Adherence to Shopify's provided UI components is mandatory.
*   **API Access Configuration:** Correctly setting `api_access` and potentially `network_access` (if fetching from NextSell's own backend) is crucial.
*   **UX Guidelines:** The tutorial links to and emphasizes following Shopify's UX guidelines for product offers in checkout to ensure a good customer experience.

This tutorial is essential for NextSell if it intends to provide integrated pre-purchase offers within the checkout experience for its Shopify Plus user base.
