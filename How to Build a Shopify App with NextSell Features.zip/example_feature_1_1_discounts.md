## Feature 1.1: Create Discounts - Example Tutorial

**Source URL:** https://shopify.dev/docs/apps/build/discounts/build-product-discount-function

**Tutorial Title:** Build a product discount function

**Relevance to NextSell Feature:** This tutorial directly addresses **Feature 1.1 (Create Discounts)** by providing a step-by-step guide on how to create a custom product discount using Shopify Functions. The example creates a "Volume discount" (10% off when customers purchase more than a minimum quantity), which is a common type of discount that NextSell might want to support.

**Key Learnings & Implementation Steps Shown:**

1.  **Shopify Function Creation:**
    *   Uses Shopify CLI to generate a new Product Discount Function (JavaScript example provided, Rust also an option).
    *   Shows how to define the input for the Function using a `run.graphql` file (e.g., to get cart line details).
    *   Demonstrates writing the core discount logic in `run.js` (or `run.rs`), including iterating through cart lines, identifying eligible lines for the discount, and defining the discount (e.g., percentage off).

2.  **Configuration & Deployment:**
    *   Explains how to update the app's access scopes in `shopify.app.toml` to include `write_discounts` (essential for the app to create discounts).
    *   Guides through deploying the app and updating scope permissions on a development store.

3.  **Activating the Discount Function:**
    *   Shows how to use the Shopify GraphiQL app to find the deployed Function's ID.
    *   Demonstrates creating an actual discount in the store (either automatic or code-based) that links to this Function ID using GraphQL mutations (`discountAutomaticAppCreate` or `discountCodeAppCreate`). This step makes the custom discount logic live.

4.  **Testing:**
    *   Provides steps to test the discount on a development store by adding products to the cart and verifying the discount application.
    *   Shows how to review function execution logs via the Shopify CLI `dev` command and how to use `shopify app function replay` for debugging.

**How NextSell can use this:**

*   **Foundation for Custom Discounts:** This tutorial provides the exact blueprint for NextSell to implement any custom discount logic that goes beyond Shopify's native discount types. For example, complex tiered discounts, product-specific bundle discounts, or discounts based on custom logic can be built using this Shopify Function approach.
*   **Merchant Configuration:** While the tutorial creates the discount via GraphiQL for demonstration, a real app like NextSell would build a user interface (within the app admin, likely using Polaris and Remix/React) where merchants can configure these custom discounts. The app backend would then use the GraphQL Admin API (with the `discountAutomaticAppCreate` or `discountCodeAppCreate` mutations and the relevant Function ID) to create these discounts in the merchant's store based on their settings.
*   **Input Customization:** NextSell can customize the `run.graphql` input query to fetch any additional data needed for its discount logic (e.g., customer tags, metafields associated with products or customers, etc.).

**Key Considerations from the Tutorial:**

*   **Language Choice:** JavaScript and Rust are the primary languages for Shopify Functions. Rust is often recommended for performance.
*   **Access Scopes:** The `write_discounts` scope is mandatory.
*   **GraphQL Mutations:** Activating the function-based discount requires using GraphQL mutations.
*   **Development Workflow:** Shopify CLI is central to creating, developing, deploying, and debugging functions.

This tutorial is a very practical starting point for building the core custom discount capabilities of the NextSell app.
