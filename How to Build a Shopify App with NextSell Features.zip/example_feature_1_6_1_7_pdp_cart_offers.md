## Features 1.6 & 1.7: On PDP (Product Detail Page) Offer & On Cart Offer - Example Tutorial

**Source URL:** https://shopify.dev/docs/apps/build/online-store/theme-app-extensions/build

**Tutorial Title:** Build theme app extensions

**Relevance to NextSell Features:** This tutorial is foundational for **Feature 1.6 (On PDP Offer)** and **Feature 1.7 (On Cart Offer)**. It explains the general process of creating, previewing, testing, and deploying Theme App Extensions. These extensions are the primary Shopify-native way to inject custom UI and logic (like offer displays) into product pages and cart pages for all Shopify plans.

**Key Learnings & Implementation Steps Shown (General for Theme App Extensions):**

1.  **Theme App Extension Creation:**
    *   Uses Shopify CLI to generate a new `Theme app extension`.
    *   The generated extension includes a working example (e.g., product ratings using a metafield), which provides a basic structure: Liquid files for rendering, schema for settings, and potentially CSS/JS assets.

2.  **Structure of a Theme App Extension:**
    *   **Blocks (Liquid files):** These are the entry points for the UI that will be injected. For NextSell, you would create blocks to display offers.
        *   **App Blocks:** Merchants can add these to sections in their theme editor (e.g., adding an offer block to a product page template or cart page template).
    *   **Schema:** Defines settings that merchants can configure for the block in the theme editor (e.g., text for the offer, colors, which offer campaign to use).
    *   **Assets:** CSS for styling the offer, JavaScript for dynamic behavior (e.g., fetching offer details, handling interactions like adding an offered product to the cart via AJAX).

3.  **Development Workflow:**
    *   **Shopify CLI `dev` command:** Starts a local development server with hot reloading, allowing developers to preview changes in real-time on a development store.
    *   **Theme Editor Integration:** The tutorial emphasizes how merchants interact with these extensions. They can add App Blocks to their theme templates (e.g., product page, cart page) and configure the settings defined in the extension's schema.

4.  **Testing:**
    *   Guidance on testing app blocks by adding them to themes, configuring settings, and verifying behavior.
    *   Ensuring app embed blocks (if used, though app blocks are more common for specific offer placements) are positioned correctly.

5.  **Deployment:**
    *   Using Shopify CLI `deploy` command to create an app version and release it.

**How NextSell can use this for PDP & Cart Offers:**

*   **PDP Offers (Feature 1.6):**
    *   NextSell would create a Theme App Extension with an **App Block** designed to display product-specific offers (e.g., upsells, cross-sells, bundle suggestions).
    *   The Liquid file for this block would access the current `product` object to determine context.
    *   JavaScript within the extension could fetch specific offer details from NextSell's backend based on the product and merchant configuration.
    *   Merchants would add this "Offer Block" to their product page templates via the theme editor and configure its settings (e.g., which offer campaign to link, display style).
*   **Cart Offers (Feature 1.7):**
    *   Similarly, NextSell would create another (or a configurable) **App Block** for cart page offers.
    *   The Liquid file would access the `cart` object to evaluate conditions for offers (e.g., cart total, specific items in cart, quantity of items).
    *   JavaScript could be used to make offers more dynamic (e.g., "Spend $X more to get free shipping" with a progress bar) or to handle adding offered items to the cart via AJAX.
    *   Merchants would add this block to their cart page template (or cart drawer sections if the theme supports it) and configure it.

**Key Considerations from the Tutorial:**

*   **Merchant Controllability:** Theme App Extensions empower merchants to place and configure app elements directly in the theme editor, which is a good UX.
*   **No Code Injection:** These extensions don't modify theme code directly, reducing risks of conflicts.
*   **Data Fetching:** For dynamic offers, the extension will need to fetch data. This can be done by passing data from the app to the Liquid template (e.g., via app proxy or metafields accessed by the app backend and then exposed to the extension) or by client-side JavaScript within the extension making calls to the NextSell app's backend.
*   **Styling and Responsiveness:** NextSell will need to provide robust CSS to ensure offers look good across different themes and devices.
*   **Complexity of Offer Logic:** The tutorial provides a basic framework. The actual offer logic (what to show, when, and to whom) will reside in NextSell's backend and be configured by the merchant. The Theme App Extension is the *presentation layer* for these offers on the storefront.

This general tutorial on building Theme App Extensions is crucial as it provides the foundational knowledge for implementing several of NextSell's storefront-facing offer features in a Shopify-approved, merchant-friendly way.
