## Feature 1.5: Pre-purchase Offers (Popup on Add to Cart - Part 2: Storefront "Add to Cart" Popup)

**Source URL (Primary for Theme App Extensions):** https://shopify.dev/docs/apps/build/online-store/theme-app-extensions

**Key Takeaways & Relevance (for Storefront "Add to Cart" Popup):**

While the previous documentation covered pre-purchase offers within the *checkout* (via Checkout UI Extensions, primarily for Shopify Plus), implementing a popup that appears *immediately when a user clicks an "Add to Cart" button on a product page or collection page* (before checkout) requires a storefront-focused approach. Theme App Extensions are the most suitable Shopify-native way to achieve this for broader compatibility, including non-Plus stores.

1.  **Mechanism (Theme App Extensions & JavaScript):**
    *   **Theme App Extensions (App Blocks or App Embed Blocks):** NextSell would provide a theme app extension. An **App Embed Block** is likely more appropriate here as it can include JavaScript that runs globally on the storefront or on specific pages (like product and collection pages).
    *   **JavaScript for Event Listening:** The core of this functionality will be JavaScript included in the theme app extension. This JavaScript will need to:
        *   Identify "Add to Cart" buttons on the page. This might involve selecting buttons based on common theme classes/IDs or providing a way for merchants to specify selectors if themes vary significantly.
        *   Listen for click events on these buttons.
        *   When an "Add to Cart" button is clicked, *before* the default cart submission happens (or immediately after a successful AJAX add to cart), the script would trigger a modal/popup.
    *   **AJAX Cart API:** Many modern themes use Shopify's AJAX Cart API to add products to the cart without a full page reload. The JavaScript in the theme app extension should be aware of this. It might listen for successful AJAX cart additions or attempt to intercept the form submission to show the popup first.
    *   **Popup Content:** The popup itself would be constructed using HTML, CSS, and JavaScript within the theme app extension. It would display the offer (e.g., "Add Product X for $Y more!" or "You've unlocked a special offer!").
    *   **Adding Offered Product:** If the user accepts the offer in the popup, JavaScript will again use the AJAX Cart API to add the offered product to the cart.

2.  **No Shopify Plus Restriction (for Theme App Extensions):** Unlike Checkout UI Extensions, Theme App Extensions are available for stores on all Shopify plans, making this approach more broadly applicable.

3.  **Configuration:**
    *   The merchant would configure the offer rules (trigger products, offered products, discounts) in the NextSell app's admin interface.
    *   The theme app extension (specifically its JavaScript) would need to fetch these configurations. This could be done by:
        *   Embedding configuration data as JSON in a Liquid template rendered by the app block/embed block.
        *   Making an asynchronous call from the storefront JavaScript to an app proxy or a backend endpoint of the NextSell app to get the relevant offer rules for the current product or cart state.

**Specific Sections from Theme App Extension Docs to Focus On:**

*   **"App embed blocks"**: As these are suitable for global scripts or scripts that need to run on specific page types to listen for events.
*   **"Assets - CSS, JavaScript, and other static app content"**: This is where the custom JavaScript for event listening, popup display, and AJAX cart interactions would reside.
*   **UX Guidelines for Theme App Extensions**: Ensure the popup is not overly intrusive and provides a good user experience.

**Opinion/Further Considerations for "Add to Cart" Popup Offers:**

*   **Theme Compatibility:** Reliably identifying and intercepting "Add to Cart" actions across diverse Shopify themes can be challenging. The app might need to provide robust selectors or clear instructions for merchants.
*   **Performance:** The JavaScript should be optimized to avoid impacting storefront loading speed.
*   **User Experience:** Popups triggered on every add-to-cart action could be annoying. Consider options like:
    *   Showing the popup only once per session or for specific products.
    *   Allowing merchants to control the frequency.
    *   Ensuring the popup is easy to dismiss.
*   **Offer Logic Complexity:** The logic for determining *which* offer to show based on the product just added to the cart, current cart contents, or customer history needs to be well-defined in the app's backend and efficiently queried by the storefront script.
*   **Alternative to Popups:** Instead of a modal popup, consider less intrusive UI elements like a slide-out panel or a notification bar that appears after an item is added to the cart.

This approach using Theme App Extensions with custom JavaScript is the most viable path for implementing an "add to cart" triggered offer popup that works across most Shopify stores.
