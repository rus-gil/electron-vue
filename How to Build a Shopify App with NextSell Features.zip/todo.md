# NextSell Shopify App Feature Documentation

This document outlines the steps to gather information and documentation for building the NextSell Shopify app.

## Phase 1: Feature Breakdown and Initial Research

- [x] 1.1. Create Discounts: Identify Shopify APIs and documentation for creating and managing discounts (e.g., percentage, fixed amount, free shipping).
- [x] 1.2. Local Delivery & In-Store Pickup Selector: Research Shopify APIs for managing shipping zones, delivery methods, and pickup options. Investigate UI extension possibilities for the selector. (In-Store Pickup part researched, focusing on Local Delivery next)
- [x] 1.3. Time Slots for Delivery/Pickup: Explore how to implement time slot selection, potentially involving metafields, custom app logic, and third-party calendar integrations if Shopify native options are limited.
- [x] 1.5. Pre-purchase Offers (Popup on Add to Cart): Research Shopify's capabilities for triggering popups on "add to cart" actions (e.g., AJAX cart events, UI Extensions, or theme modifications) and displaying offers. (Checkout pre-purchase researched, focusing on storefront add-to-cart popups next)
- [x] 1.6. On PDP (Product Detail Page) Offer: Identify how to display offers directly on product pages (e.g., theme app extensions, theme liquid modifications).
- [x] 1.7. On Cart Offer: Research methods for displaying offers on the cart page (e.g., theme app extensions, cart scripts if applicable, or UI extensions).
- [x] 1.8. Post-purchase Offer: Investigate Shopify's Post-purchase Checkout Extensions and relevant APIs for implementing post-purchase upsells.

- [ ] 2.1. Identify core Shopify App architecture (e.g., embedded app, Remix, Node.js, Ruby on Rails).
- [ ] 2.2. List key Shopify APIs to be used (Admin API - REST & GraphQL, Storefront API, Checkout UI Extensions, Post-purchase Checkout Extensions, Theme App Extensions).

## Phase 3: Detailed Documentation Gathering

- [ ] 3.1. For each feature (1.1 to 1.8), gather specific Shopify developer documentation links.
- [ ] 3.2. Annotate each link with its relevance to the feature and specific sections to focus on.

## Phase 4: Analysis and Best Practices

- [ ] 4.1. Summarize best practices from the gathered documentation for app development, security, and performance.
- [ ] 4.2. Identify any limitations or challenges for implementing each feature based on Shopify's platform.

## Phase 5: Examples and Tutorials

- [ ] 5.1. Find relevant Shopify example apps, code snippets, or tutorials for similar functionalities.

## Phase 6: Review and Suggestions

- [ ] 6.1. Review the gathered information for completeness.
- [ ] 6.2. Suggest additional features or considerations (e.g., analytics for offer performance, A/B testing for offers, settings panel for the merchant, localization).
- [ ] 6.3. Formulate an opinion on any missed aspects from the user's initial request.

## Phase 7: Compilation and Reporting

- [ ] 7.1. Compile all gathered information, links, annotations, and suggestions into a comprehensive document.
- [ ] 7.2. Prepare a summary report for the user.
- [ ] 7.3. Send the final documentation package and report to the user.
