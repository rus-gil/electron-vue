import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertOfferSchema, offerTypes } from "@shared/schema";
import { ZodError } from "zod";
import { fromZodError } from "zod-validation-error";
import Stripe from "stripe";

// Stripe integration using the provided API key
const STRIPE_ENABLED = process.env.STRIPE_SECRET_KEY !== undefined;

// Initialize Stripe with the provided secret key if available
let stripeClient: Stripe | undefined;
if (STRIPE_ENABLED) {
  stripeClient = new Stripe(process.env.STRIPE_SECRET_KEY as string, {
    apiVersion: "2023-10-16" as any
  });
}

// Handler for subscription operations
const stripeHandler = {
  createSubscription: async (userId: number) => {
    if (!STRIPE_ENABLED || !stripeClient) {
      // Fallback if Stripe is not configured
      await storage.updateUserPremiumStatus(userId, true);
      return { success: true, message: "Subscription activated (demo)" };
    }

    try {
      // Get user information (in a real app, you'd get this from the authenticated user)
      const user = await storage.getUser(userId);
      if (!user) {
        throw new Error("User not found");
      }

      // Create a Stripe customer (in a real app, you might store this ID in a database)
      let customerId = user.stripeCustomerId;
      if (!customerId) {
        const customer = await stripeClient.customers.create({
          name: user.username,
          email: "example@domain.com", // In a real app, this would be the user's email
          metadata: {
            userId: userId.toString()
          }
        });
        customerId = customer.id;
        
        // In a real app, you would store this customer ID with the user
        if (typeof storage.updateStripeCustomerId === 'function') {
          await storage.updateStripeCustomerId(userId, customerId);
        }
      }

      // Create a payment intent for a one-time payment (simplified for demo)
      // In a real app, you would use proper subscription APIs with recurring payments
      const paymentIntent = await stripeClient.paymentIntents.create({
        amount: 1999, // $19.99 in cents
        currency: "usd",
        customer: customerId,
        payment_method_types: ["card"],
        metadata: {
          userId: userId.toString(),
          plan: "premium"
        }
      });

      // Update user's premium status (in a real app, this would happen after payment confirmation)
      await storage.updateUserPremiumStatus(userId, true);
      
      return { 
        success: true, 
        message: "Subscription activated", 
        clientSecret: paymentIntent.client_secret
      };
    } catch (error: any) {
      console.error("Stripe subscription error:", error);
      throw new Error(`Failed to create subscription: ${error.message}`);
    }
  },
  
  cancelSubscription: async (userId: number) => {
    if (!STRIPE_ENABLED || !stripeClient) {
      // Fallback if Stripe is not configured
      await storage.updateUserPremiumStatus(userId, false);
      return { success: true, message: "Subscription canceled (demo)" };
    }

    try {
      // Get user information (in a real app, you'd get this from the authenticated user)
      const user = await storage.getUser(userId);
      if (!user) {
        throw new Error("User not found");
      }

      // In a real app, you would cancel the actual subscription with Stripe
      // For this demo, we'll just update the user's premium status
      await storage.updateUserPremiumStatus(userId, false);
      
      return { success: true, message: "Subscription canceled" };
    } catch (error: any) {
      console.error("Stripe cancellation error:", error);
      throw new Error(`Failed to cancel subscription: ${error.message}`);
    }
  }
};

export async function registerRoutes(app: Express): Promise<Server> {
  // API routes
  
  // Get all offers
  app.get("/api/offers", async (req, res) => {
    try {
      const offerType = req.query.type as string;
      let offers;
      
      if (offerType) {
        offers = await storage.getOffersByType(offerType);
      } else {
        offers = await storage.getOffers();
      }
      
      res.json(offers);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch offers" });
    }
  });
  
  // Get premium status (for demo purposes)
  app.get("/api/premium-status", async (req, res) => {
    try {
      // In production, this would use the user's session to determine their ID
      // For this demo, we'll use the sample user with ID 1
      const user = await storage.getUser(1);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      res.json({ isPremium: user.isPremium });
    } catch (error) {
      res.status(500).json({ message: "Failed to check premium status" });
    }
  });
  
  // Get a single offer
  app.get("/api/offers/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid offer ID" });
      }
      
      const offer = await storage.getOffer(id);
      if (!offer) {
        return res.status(404).json({ message: "Offer not found" });
      }
      
      res.json(offer);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch offer" });
    }
  });
  
  // Create a new offer
  app.post("/api/offers", async (req, res) => {
    try {
      const offerData = insertOfferSchema.parse(req.body);
      const offer = await storage.createOffer(offerData);
      res.status(201).json(offer);
    } catch (error) {
      if (error instanceof ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ message: validationError.message });
      }
      res.status(500).json({ message: "Failed to create offer" });
    }
  });
  
  // Update an offer
  app.patch("/api/offers/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid offer ID" });
      }
      
      // Partial validation of the offer data
      const offerData = insertOfferSchema.partial().parse(req.body);
      
      const updatedOffer = await storage.updateOffer(id, offerData);
      if (!updatedOffer) {
        return res.status(404).json({ message: "Offer not found" });
      }
      
      res.json(updatedOffer);
    } catch (error) {
      if (error instanceof ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ message: validationError.message });
      }
      res.status(500).json({ message: "Failed to update offer" });
    }
  });
  
  // Delete an offer
  app.delete("/api/offers/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid offer ID" });
      }
      
      const success = await storage.deleteOffer(id);
      if (!success) {
        return res.status(404).json({ message: "Offer not found" });
      }
      
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Failed to delete offer" });
    }
  });
  
  // Track offer conversion
  app.post("/api/offers/:id/conversion", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid offer ID" });
      }
      
      const success = await storage.incrementConversion(id);
      if (!success) {
        return res.status(404).json({ message: "Offer not found" });
      }
      
      res.status(200).json({ success: true });
    } catch (error) {
      res.status(500).json({ message: "Failed to track conversion" });
    }
  });
  
  // Track offer display
  app.post("/api/offers/:id/display", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid offer ID" });
      }
      
      const success = await storage.incrementDisplay(id);
      if (!success) {
        return res.status(404).json({ message: "Offer not found" });
      }
      
      res.status(200).json({ success: true });
    } catch (error) {
      res.status(500).json({ message: "Failed to track display" });
    }
  });
  
  // Generate the Shopify script tag to be embedded in the store
  app.get("/api/script", (req, res) => {
    const scriptContent = `
    // Upsell Buddy Script
    (function() {
      // Base URL to the app's API
      const API_URL = "${process.env.APP_URL || req.protocol + '://' + req.get('host')}";
      
      // Find add to cart buttons
      const addToCartButtons = document.querySelectorAll('button[name="add"], input[name="add"], form[action*="/cart/add"] button, form[action*="/cart/add"] input[type="submit"]');
      
      // If no add to cart buttons, exit
      if (addToCartButtons.length === 0) return;
      
      // Create popup container
      const popupContainer = document.createElement('div');
      popupContainer.id = 'upsell-buddy-container';
      popupContainer.style.display = 'none';
      popupContainer.style.position = 'fixed';
      popupContainer.style.top = '0';
      popupContainer.style.left = '0';
      popupContainer.style.width = '100%';
      popupContainer.style.height = '100%';
      popupContainer.style.backgroundColor = 'rgba(0, 0, 0, 0.5)';
      popupContainer.style.zIndex = '9999';
      popupContainer.style.alignItems = 'center';
      popupContainer.style.justifyContent = 'center';
      document.body.appendChild(popupContainer);
      
      // Function to fetch offers based on product
      async function getOffers() {
        try {
          const response = await fetch(API_URL + '/api/offers');
          if (!response.ok) throw new Error('Network response was not ok');
          return await response.json();
        } catch (error) {
          console.error('Error fetching offers:', error);
          return [];
        }
      }
      
      // Function to check if current product matches trigger product
      function isMatch(offer, productTitle) {
        if (offer.triggerProduct === 'All Products') return true;
        return productTitle.toLowerCase().includes(offer.triggerProduct.toLowerCase());
      }
      
      // Function to track offer display
      async function trackDisplay(offerId) {
        try {
          await fetch(API_URL + '/api/offers/' + offerId + '/display', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' }
          });
        } catch (error) {
          console.error('Error tracking display:', error);
        }
      }
      
      // Function to track offer conversion
      async function trackConversion(offerId) {
        try {
          await fetch(API_URL + '/api/offers/' + offerId + '/conversion', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' }
          });
        } catch (error) {
          console.error('Error tracking conversion:', error);
        }
      }
      
      // Function to show offer popup
      function showOffer(offer, productTitle) {
        if (!offer.active) return;
        
        // Track display
        trackDisplay(offer.id);
        
        // Create popup HTML
        const popupHTML = \`
          <div class="upsell-popup" style="background-color: \${offer.backgroundColor}; color: \${offer.textColor}; max-width: 500px; margin: 0 auto; padding: 24px; border-radius: 8px; box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1);">
            <h3 style="font-size: 1.125rem; font-weight: 600; margin-bottom: 0.5rem;">\${offer.title}</h3>
            <div style="display: flex; align-items: center; margin-bottom: 1rem;">
              <div style="width: 80px; height: 80px; flex-shrink: 0; background-color: #f6f6f7; border-radius: 4px; overflow: hidden;"></div>
              <div style="margin-left: 1rem;">
                <h4 style="font-size: 1rem; font-weight: 500;">\${offer.upsellProduct}</h4>
              </div>
            </div>
            <p style="font-size: 0.875rem; margin-bottom: 1rem;">\${offer.description}</p>
            <div style="display: flex; gap: 1rem;">
              <button class="add-upsell-btn" style="flex: 1; background-color: \${offer.buttonColor}; color: \${offer.buttonTextColor}; border: none; border-radius: 4px; padding: 0.5rem 1rem; font-size: 0.875rem; font-weight: 500; cursor: pointer;">Add to Cart</button>
              <button class="decline-upsell-btn" style="flex: 1; background-color: transparent; color: #637381; border: 1px solid #e5e7eb; border-radius: 4px; padding: 0.5rem 1rem; font-size: 0.875rem; font-weight: 500; cursor: pointer;">No Thanks</button>
            </div>
          </div>
        \`;
        
        // Add custom CSS if provided
        if (offer.customCSS) {
          const customStyle = document.createElement('style');
          customStyle.textContent = offer.customCSS;
          document.head.appendChild(customStyle);
        }
        
        // Show popup
        popupContainer.innerHTML = popupHTML;
        popupContainer.style.display = 'flex';
        
        // Add event listeners
        const addBtn = popupContainer.querySelector('.add-upsell-btn');
        const declineBtn = popupContainer.querySelector('.decline-upsell-btn');
        
        addBtn.addEventListener('click', () => {
          // Track conversion
          trackConversion(offer.id);
          
          // Add product to cart
          const formData = {
            items: [{ id: 123, quantity: 1 }] // This would be the actual variant ID
          };
          
          fetch('/cart/add.js', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json'
            },
            body: JSON.stringify(formData)
          })
          .then(response => {
            popupContainer.style.display = 'none';
            if (offer.skipCart) {
              window.location.href = '/checkout';
            }
          })
          .catch(error => {
            console.error('Error adding product to cart:', error);
            popupContainer.style.display = 'none';
          });
        });
        
        declineBtn.addEventListener('click', () => {
          popupContainer.style.display = 'none';
        });
        
        // Execute custom JavaScript if provided
        if (offer.customJS) {
          try {
            eval(offer.customJS);
          } catch (error) {
            console.error('Error executing custom JavaScript:', error);
          }
        }
      }
      
      // Add click event listeners to all add to cart buttons
      addToCartButtons.forEach(button => {
        button.addEventListener('click', async function(e) {
          // Get product title
          const productTitle = document.querySelector('h1, .product-title, .product__title')?.textContent || '';
          
          // Get offers
          const offers = await getOffers();
          
          // Find matching offers
          const matchingOffers = offers.filter(offer => isMatch(offer, productTitle));
          
          // If matching offers found, show the first one
          if (matchingOffers.length > 0) {
            e.preventDefault(); // Prevent default add to cart behavior
            showOffer(matchingOffers[0], productTitle);
          }
        });
      });
    })();
    `;
    
    res.set('Content-Type', 'application/javascript');
    res.send(scriptContent);
  });

  // Endpoint for getting Stripe's public key (needed on the frontend)
  app.get("/api/stripe-public-key", (req, res) => {
    if (!STRIPE_ENABLED || !process.env.VITE_STRIPE_PUBLIC_KEY) {
      return res.status(404).json({ message: "Stripe is not configured" });
    }
    res.json({ publicKey: process.env.VITE_STRIPE_PUBLIC_KEY });
  });

  // Create or activate a premium subscription
  app.post("/api/subscribe", async (req, res) => {
    try {
      // In a real app, this would use the authenticated user
      // For this demo, we'll use the sample user with ID 1
      const userId = 1;
      
      const result = await stripeHandler.createSubscription(userId);
      res.json(result);
    } catch (error: any) {
      res.status(500).json({ 
        message: error.message || "Failed to create subscription" 
      });
    }
  });
  
  // Create a payment intent for checkout
  app.post("/api/create-payment-intent", async (req, res) => {
    try {
      if (!STRIPE_ENABLED || !stripeClient) {
        return res.status(400).json({ message: "Stripe is not configured" });
      }

      // In a real app, this would use the authenticated user
      const userId = 1;
      const user = await storage.getUser(userId);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Create a payment intent for the subscription
      const paymentIntent = await stripeClient.paymentIntents.create({
        amount: 1999, // $19.99 in cents
        currency: "usd",
        payment_method_types: ["card"],
        metadata: {
          userId: userId.toString(),
          plan: "premium"
        }
      });
      
      res.json({
        clientSecret: paymentIntent.client_secret
      });
    } catch (error: any) {
      console.error("Payment intent error:", error);
      res.status(500).json({ 
        message: error.message || "Failed to create payment intent" 
      });
    }
  });
  
  // Handle successful payment
  app.post("/api/payment-success", async (req, res) => {
    try {
      // In a real app, this would verify the payment with Stripe
      // and use the authenticated user
      const userId = 1;
      
      // Update user's premium status
      await storage.updateUserPremiumStatus(userId, true);
      
      res.json({ success: true });
    } catch (error: any) {
      res.status(500).json({ 
        message: error.message || "Failed to process payment success" 
      });
    }
  });
  
  // Cancel a premium subscription
  app.post("/api/cancel-subscription", async (req, res) => {
    try {
      // In a real app, this would use the authenticated user
      // For this demo, we'll use the sample user with ID 1
      const userId = 1;
      
      const result = await stripeHandler.cancelSubscription(userId);
      res.json(result);
    } catch (error: any) {
      res.status(500).json({ 
        message: error.message || "Failed to cancel subscription" 
      });
    }
  });
  
  // Generate the Shopify thank-you page script (for post-purchase offers)
  app.get("/api/post-purchase-script", async (req, res) => {
    try {
      // Check if merchant has premium subscription (using demo user)
      const user = await storage.getUser(1);
      if (!user || !user.isPremium) {
        return res.status(403).json({
          message: "Post-purchase offers require a premium subscription"
        });
      }
      
      const scriptContent = `
      // Upsell Buddy Post-Purchase Script
      (function() {
        // Base URL to the app's API
        const API_URL = "${process.env.APP_URL || req.protocol + '://' + req.get('host')}";
        
        // Function to check if we're on a thank you page
        function isThankYouPage() {
          return window.location.pathname.includes('/thank_you') || 
                window.location.pathname.includes('/checkout/thank-you') ||
                document.querySelector('.checkout-thank-you') !== null;
        }
        
        // If not on thank you page, exit
        if (!isThankYouPage()) return;
        
        // Function to fetch post-purchase offers
        async function getPostPurchaseOffers() {
          try {
            const response = await fetch(API_URL + '/api/offers?type=${offerTypes.POST_PURCHASE}');
            if (!response.ok) throw new Error('Network response was not ok');
            return await response.json();
          } catch (error) {
            console.error('Error fetching post-purchase offers:', error);
            return [];
          }
        }
        
        // Function to show post-purchase offer
        function showPostPurchaseOffer(offer) {
          // Create offer container
          const offerContainer = document.createElement('div');
          offerContainer.className = 'post-purchase-offer';
          offerContainer.style.maxWidth = '500px';
          offerContainer.style.margin = '20px auto';
          offerContainer.style.padding = '20px';
          offerContainer.style.borderRadius = '8px';
          offerContainer.style.backgroundColor = offer.backgroundColor;
          offerContainer.style.color = offer.textColor;
          offerContainer.style.boxShadow = '0 4px 8px rgba(0, 0, 0, 0.1)';
          
          const offerContent = \`
            <h3 style="font-size: 1.25rem; font-weight: 600; margin-bottom: 0.75rem;">\${offer.title}</h3>
            <p style="margin-bottom: 1rem;">\${offer.description}</p>
            <div style="display: flex; justify-content: space-between; gap: 10px;">
              <button class="post-purchase-add" style="flex: 1; background-color: \${offer.buttonColor}; color: \${offer.buttonTextColor}; border: none; border-radius: 4px; padding: 10px; cursor: pointer; font-weight: 500;">Add to Order</button>
              <button class="post-purchase-decline" style="flex: 1; background-color: transparent; border: 1px solid #ddd; border-radius: 4px; padding: 10px; cursor: pointer;">No Thanks</button>
            </div>
          \`;
          
          offerContainer.innerHTML = offerContent;
          
          // Find a good place to insert the offer
          const orderSummary = document.querySelector('.order-summary, .order-summary__section, .checkout-thank-you');
          if (orderSummary) {
            orderSummary.parentNode.insertBefore(offerContainer, orderSummary.nextSibling);
          } else {
            // Fallback option - insert after the main content
            const main = document.querySelector('main') || document.body;
            main.appendChild(offerContainer);
          }
          
          // Add event listeners
          const addButton = offerContainer.querySelector('.post-purchase-add');
          const declineButton = offerContainer.querySelector('.post-purchase-decline');
          
          addButton.addEventListener('click', async () => {
            try {
              // Track conversion
              await fetch(API_URL + '/api/offers/' + offer.id + '/conversion', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' }
              });
              
              // Show confirmation
              offerContainer.innerHTML = '<p style="text-align: center; padding: 20px;">Added to your order! We will process this right away.</p>';
              
              // In a real implementation, this would add the product to their order
              // which would require connection to Shopify's Order API
              
            } catch (error) {
              console.error('Error adding post-purchase product:', error);
            }
          });
          
          declineButton.addEventListener('click', () => {
            offerContainer.remove();
          });
          
          // Track display
          fetch(API_URL + '/api/offers/' + offer.id + '/display', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' }
          }).catch(error => {
            console.error('Error tracking display:', error);
          });
        }
        
        // Initialize - get and show offers
        getPostPurchaseOffers().then(offers => {
          // Filter for active offers
          const activeOffers = offers.filter(offer => offer.active);
          
          if (activeOffers.length > 0) {
            // Show the first active offer
            showPostPurchaseOffer(activeOffers[0]);
          }
        });
      })();
      `;
      
      res.set('Content-Type', 'application/javascript');
      res.send(scriptContent);
    } catch (error) {
      res.status(500).json({ message: "Failed to generate post-purchase script" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
