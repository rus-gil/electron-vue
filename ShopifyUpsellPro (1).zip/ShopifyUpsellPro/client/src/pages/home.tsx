import OffersList from "@/components/OffersList";

export default function Home() {
  return <OffersList />;
}
