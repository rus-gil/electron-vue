import { useState, useEffect } from 'react';
import { loadStripe } from '@stripe/stripe-js';
import { Elements } from '@stripe/react-stripe-js';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import StripeCheckoutForm from './StripeCheckoutForm';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';

interface StripeCheckoutModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
}

export default function StripeCheckoutModal({ isOpen, onClose, onSuccess }: StripeCheckoutModalProps) {
  const [stripePromise, setStripePromise] = useState<any>(null);
  const [clientSecret, setClientSecret] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const { toast } = useToast();

  // Get Stripe public key
  useEffect(() => {
    const getPublicKey = async () => {
      try {
        const response = await apiRequest('GET', '/api/stripe-public-key');
        const { publicKey } = await response.json();
        setStripePromise(loadStripe(publicKey));
      } catch (error) {
        toast({
          title: 'Failed to initialize Stripe',
          description: 'Could not load payment processing. Please try again later.',
          variant: 'destructive',
        });
        onClose();
      }
    };

    if (isOpen) {
      getPublicKey();
    }
  }, [isOpen, toast, onClose]);

  // Create payment intent when the modal opens
  useEffect(() => {
    const createPaymentIntent = async () => {
      setIsLoading(true);
      try {
        const response = await apiRequest('POST', '/api/create-payment-intent');
        const { clientSecret } = await response.json();
        setClientSecret(clientSecret);
      } catch (error) {
        toast({
          title: 'Payment setup failed',
          description: 'Could not prepare payment process. Please try again later.',
          variant: 'destructive',
        });
        onClose();
      } finally {
        setIsLoading(false);
      }
    };

    if (isOpen && stripePromise) {
      createPaymentIntent();
    }
  }, [isOpen, stripePromise, toast, onClose]);

  return (
    <Dialog open={isOpen} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle>Upgrade to Premium</DialogTitle>
          <DialogDescription>
            Complete your payment to unlock post-purchase offers and other premium features.
          </DialogDescription>
        </DialogHeader>

        {isLoading ? (
          <div className="flex items-center justify-center py-10">
            <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full"></div>
          </div>
        ) : clientSecret && stripePromise ? (
          <Elements stripe={stripePromise} options={{ clientSecret }}>
            <StripeCheckoutForm 
              onSuccess={onSuccess} 
              onCancel={onClose} 
            />
          </Elements>
        ) : (
          <div className="text-center py-6 text-red-500">
            Failed to initialize payment form. Please try again later.
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}