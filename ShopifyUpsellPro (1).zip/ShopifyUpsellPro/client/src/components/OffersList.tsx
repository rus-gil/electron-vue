import { useState } from "react";
import { useOffers } from "@/hooks/use-offers";
import { Offer } from "@shared/schema";
import { formatDate, calculateConversionRate, getStatusElement } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Trash2, Pencil, Plus } from "lucide-react";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import CreateOfferModal from "./CreateOfferModal";

export default function OffersList() {
  const { offers, isLoading, deleteOffer } = useOffers();
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [editingOffer, setEditingOffer] = useState<Offer | null>(null);
  const [offerToDelete, setOfferToDelete] = useState<Offer | null>(null);

  const handleEdit = (offer: Offer) => {
    setEditingOffer(offer);
    setIsCreateModalOpen(true);
  };

  const handleDelete = (offer: Offer) => {
    setOfferToDelete(offer);
  };

  const confirmDelete = () => {
    if (offerToDelete) {
      deleteOffer.mutate(offerToDelete.id);
      setOfferToDelete(null);
    }
  };

  return (
    <>
      <header className="bg-white border-b border-gray-200 px-6 py-4">
        <div className="flex justify-between items-center">
          <h1 className="text-xl font-semibold text-shopify-ink">Pre-Purchase Offers</h1>
          <div>
            <Button onClick={() => setIsCreateModalOpen(true)}>
              <Plus className="h-5 w-5 mr-2" />
              Create Offer
            </Button>
          </div>
        </div>
      </header>

      <div className="p-6">
        <Card className="mb-6">
          <CardHeader className="px-6 py-4 border-b border-gray-200">
            <CardTitle>Your Offers</CardTitle>
            <CardDescription>Manage your pre-purchase upsell offers</CardDescription>
          </CardHeader>
          <CardContent className="p-0">
            {isLoading ? (
              <div className="p-6 text-center">Loading offers...</div>
            ) : offers.length === 0 ? (
              <div className="px-6 py-10 text-center">
                <Package className="mx-auto h-12 w-12 text-gray-300" />
                <h3 className="mt-2 text-sm font-medium text-shopify-ink">No offers yet</h3>
                <p className="mt-1 text-sm text-shopify-text">Get started by creating a new offer.</p>
                <div className="mt-6">
                  <Button onClick={() => setIsCreateModalOpen(true)}>
                    <Plus className="h-5 w-5 mr-2" />
                    Create Offer
                  </Button>
                </div>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-gray-200">
                  <thead className="bg-gray-50">
                    <tr>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-shopify-text uppercase tracking-wider">Offer Name</th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-shopify-text uppercase tracking-wider">Status</th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-shopify-text uppercase tracking-wider">Created</th>
                      <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-shopify-text uppercase tracking-wider">Conversions</th>
                      <th scope="col" className="relative px-6 py-3">
                        <span className="sr-only">Actions</span>
                      </th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {offers.map((offer) => {
                      const { label, className } = getStatusElement(offer.active);
                      return (
                        <tr key={offer.id} className="hover:bg-gray-50 cursor-pointer">
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className="text-sm font-medium text-shopify-ink">{offer.name}</div>
                            <div className="text-sm text-shopify-text">Triggered on product: {offer.triggerProduct}</div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${className}`}>
                              {label}
                            </span>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-shopify-text">
                            {formatDate(offer.createdAt)}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-shopify-text">
                            {calculateConversionRate(offer.conversions, offer.displays)}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                            <Button 
                              variant="ghost" 
                              size="sm" 
                              className="text-shopify-purple hover:text-shopify-ink mr-1"
                              onClick={() => handleEdit(offer)}
                            >
                              <Pencil className="h-4 w-4 mr-1" />
                              Edit
                            </Button>
                            <Button 
                              variant="ghost" 
                              size="sm" 
                              className="text-shopify-error hover:text-red-900"
                              onClick={() => handleDelete(offer)}
                            >
                              <Trash2 className="h-4 w-4 mr-1" />
                              Delete
                            </Button>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {isCreateModalOpen && (
        <CreateOfferModal
          isOpen={isCreateModalOpen}
          onClose={() => {
            setIsCreateModalOpen(false);
            setEditingOffer(null);
          }}
          editingOffer={editingOffer}
        />
      )}

      <AlertDialog open={!!offerToDelete} onOpenChange={() => setOfferToDelete(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you sure you want to delete this offer?</AlertDialogTitle>
            <AlertDialogDescription>
              This action cannot be undone. This will permanently delete the offer
              "{offerToDelete?.name}".
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction 
              onClick={confirmDelete}
              className="bg-shopify-error hover:bg-red-700"
            >
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}

function Package(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg 
      xmlns="http://www.w3.org/2000/svg" 
      viewBox="0 0 24 24" 
      fill="none" 
      stroke="currentColor" 
      strokeWidth="1" 
      strokeLinecap="round" 
      strokeLinejoin="round" 
      {...props}
    >
      <path d="M20 7l-8-4-8 4m16 0l-8 4m-8-4l8 4m8 4l-8 4m8-4l-8-4m-8 4l8-4" />
    </svg>
  );
}
