import { useState } from "react";
import { useOffers } from "@/hooks/use-offers";
import { usePremiumStatus } from "@/hooks/use-premium";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { InsertOffer, Offer, insertOfferSchema, offerTypes } from "@shared/schema";
import { displayConditionOptions } from "@/lib/utils";
import OfferPreview from "./OfferPreview";
import { AlertCircle } from "lucide-react";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";

interface CreateOfferModalProps {
  isOpen: boolean;
  onClose: () => void;
  editingOffer?: Offer | null;
}

export default function CreateOfferModal({ isOpen, onClose, editingOffer }: CreateOfferModalProps) {
  const { createOffer, updateOffer } = useOffers();
  const { isPremium } = usePremiumStatus();
  const [activeTab, setActiveTab] = useState("basic");

  const isEditing = !!editingOffer;

  const form = useForm<InsertOffer>({
    resolver: zodResolver(insertOfferSchema),
    defaultValues: {
      name: editingOffer?.name || "",
      offerType: editingOffer?.offerType || offerTypes.PRE_PURCHASE,
      triggerProduct: editingOffer?.triggerProduct || "",
      upsellProduct: editingOffer?.upsellProduct || "",
      title: editingOffer?.title || "",
      description: editingOffer?.description || "",
      active: editingOffer?.active ?? true,
      backgroundColor: editingOffer?.backgroundColor || "#ffffff",
      textColor: editingOffer?.textColor || "#212b36",
      buttonColor: editingOffer?.buttonColor || "#008060",
      buttonTextColor: editingOffer?.buttonTextColor || "#ffffff",
      customCSS: editingOffer?.customCSS || "",
      customJS: editingOffer?.customJS || "",
      displayCondition: editingOffer?.displayCondition || "all",
      limitDisplays: editingOffer?.limitDisplays ?? false,
      skipCart: editingOffer?.skipCart ?? false,
    },
  });

  const formValues = form.watch();

  const onSubmit = (data: InsertOffer) => {
    if (isEditing && editingOffer) {
      updateOffer.mutate({ 
        id: editingOffer.id, 
        data 
      }, {
        onSuccess: () => onClose()
      });
    } else {
      createOffer.mutate(data, {
        onSuccess: () => onClose()
      });
    }
  };

  const products = [
    { value: "Summer T-shirt", label: "Summer T-shirt" },
    { value: "Beach Sandals", label: "Beach Sandals" },
    { value: "Winter Scarf", label: "Winter Scarf" },
    { value: "All Products", label: "All Products" }
  ];

  const upsellProducts = [
    { value: "Beach Hat", label: "Beach Hat" },
    { value: "Sunglasses", label: "Sunglasses" },
    { value: "Sunscreen", label: "Sunscreen" },
    { value: "Gloves", label: "Gloves" }
  ];

  // Watch the offer type to update the dialog title and description
  const offerType = form.watch("offerType");
  
  // Get title and description based on offer type
  const getDialogTitle = () => {
    if (offerType === offerTypes.POST_PURCHASE) {
      return `${isEditing ? "Edit" : "Create"} Post-Purchase Offer`;
    }
    return `${isEditing ? "Edit" : "Create"} Pre-Purchase Offer`;
  };

  const getDialogDescription = () => {
    if (offerType === offerTypes.POST_PURCHASE) {
      return "Configure your post-purchase offer that appears on the thank you page";
    }
    return "Configure your upsell offer to increase average order value";
  };
  
  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-4xl">
        <DialogHeader>
          <DialogTitle>{getDialogTitle()}</DialogTitle>
          <DialogDescription>
            {getDialogDescription()}
          </DialogDescription>
        </DialogHeader>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid grid-cols-3 mb-4">
            <TabsTrigger value="basic">Basic Settings</TabsTrigger>
            <TabsTrigger value="design">Design Customization</TabsTrigger>
            <TabsTrigger value="advanced">Advanced Options</TabsTrigger>
          </TabsList>

          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="md:col-span-2 space-y-8">
                  <TabsContent value="basic" className="space-y-6 mt-0">
                    {/* Offer Type Selection */}
                    <FormField
                      control={form.control}
                      name="offerType"
                      render={({ field }) => (
                        <FormItem className="space-y-3">
                          <FormLabel>Offer Type</FormLabel>
                          <FormControl>
                            <RadioGroup
                              onValueChange={field.onChange}
                              defaultValue={field.value}
                              className="flex flex-col space-y-1"
                            >
                              <FormItem className="flex items-center space-x-3 space-y-0">
                                <FormControl>
                                  <RadioGroupItem value={offerTypes.PRE_PURCHASE} />
                                </FormControl>
                                <FormLabel className="font-normal">
                                  Pre-Purchase Offer (shows when customer adds product to cart)
                                </FormLabel>
                              </FormItem>
                              <FormItem className="flex items-center space-x-3 space-y-0">
                                <FormControl>
                                  <RadioGroupItem 
                                    value={offerTypes.POST_PURCHASE} 
                                    disabled={!isPremium}
                                  />
                                </FormControl>
                                <FormLabel className="font-normal">
                                  Post-Purchase Offer (shows on thank you page)
                                  {!isPremium && <span className="ml-2 text-xs text-amber-600 font-semibold">(Premium Feature)</span>}
                                </FormLabel>
                              </FormItem>
                            </RadioGroup>
                          </FormControl>
                          {field.value === offerTypes.POST_PURCHASE && !isPremium && (
                            <Alert variant="warning" className="mt-2">
                              <AlertCircle className="h-4 w-4" />
                              <AlertTitle>Premium Feature</AlertTitle>
                              <AlertDescription>
                                Post-purchase offers are only available to premium subscribers. 
                                Visit the Settings page to upgrade.
                              </AlertDescription>
                            </Alert>
                          )}
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="name"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Offer Name</FormLabel>
                          <FormControl>
                            <Input 
                              placeholder="Summer Collection Upsell" 
                              {...field} 
                            />
                          </FormControl>
                          <FormDescription>
                            Internal name for your reference
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <div className="grid grid-cols-1 gap-6 sm:grid-cols-2">
                      <FormField
                        control={form.control}
                        name="triggerProduct"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Trigger Product</FormLabel>
                            <Select 
                              onValueChange={field.onChange} 
                              defaultValue={field.value}
                            >
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select a product" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                {products.map((product) => (
                                  <SelectItem key={product.value} value={product.value}>
                                    {product.label}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                            <FormDescription>
                              When this product is added to cart, your offer will appear
                            </FormDescription>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="upsellProduct"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Upsell Product</FormLabel>
                            <Select 
                              onValueChange={field.onChange} 
                              defaultValue={field.value}
                            >
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select a product" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                {upsellProducts.map((product) => (
                                  <SelectItem key={product.value} value={product.value}>
                                    {product.label}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                            <FormDescription>
                              Product to offer as the upsell
                            </FormDescription>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>

                    <FormField
                      control={form.control}
                      name="title"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Offer Title</FormLabel>
                          <FormControl>
                            <Input 
                              placeholder="Complete your beach look!" 
                              {...field} 
                            />
                          </FormControl>
                          <FormDescription>
                            Main heading displayed on the offer popup
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="description"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Offer Description</FormLabel>
                          <FormControl>
                            <Textarea 
                              placeholder="Add our bestselling beach hat to your order for just $19.99 (20% off)!" 
                              {...field}
                              rows={3}
                            />
                          </FormControl>
                          <FormDescription>
                            Persuasive text that convinces customers to add the upsell product
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="active"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-start space-x-3 space-y-0 rounded-md p-4 border">
                          <FormControl>
                            <Checkbox
                              checked={field.value}
                              onCheckedChange={field.onChange}
                            />
                          </FormControl>
                          <div className="space-y-1 leading-none">
                            <FormLabel>Activate offer</FormLabel>
                            <FormDescription>
                              When checked, this offer will be live on your store
                            </FormDescription>
                          </div>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </TabsContent>

                  <TabsContent value="design" className="space-y-6 mt-0">
                    <div className="grid grid-cols-1 gap-6 sm:grid-cols-2">
                      <FormField
                        control={form.control}
                        name="backgroundColor"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Background Color</FormLabel>
                            <div className="flex">
                              <span className="inline-flex items-center px-3 rounded-l-md border border-r-0 border-gray-300 bg-gray-50 text-gray-500 sm:text-sm">
                                #
                              </span>
                              <FormControl>
                                <Input 
                                  className="rounded-l-none"
                                  {...field}
                                  value={field.value.replace('#', '')}
                                  onChange={e => field.onChange(`#${e.target.value}`)}
                                />
                              </FormControl>
                            </div>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="textColor"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Text Color</FormLabel>
                            <div className="flex">
                              <span className="inline-flex items-center px-3 rounded-l-md border border-r-0 border-gray-300 bg-gray-50 text-gray-500 sm:text-sm">
                                #
                              </span>
                              <FormControl>
                                <Input 
                                  className="rounded-l-none"
                                  {...field}
                                  value={field.value.replace('#', '')}
                                  onChange={e => field.onChange(`#${e.target.value}`)}
                                />
                              </FormControl>
                            </div>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>

                    <div className="grid grid-cols-1 gap-6 sm:grid-cols-2">
                      <FormField
                        control={form.control}
                        name="buttonColor"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Button Color</FormLabel>
                            <div className="flex">
                              <span className="inline-flex items-center px-3 rounded-l-md border border-r-0 border-gray-300 bg-gray-50 text-gray-500 sm:text-sm">
                                #
                              </span>
                              <FormControl>
                                <Input 
                                  className="rounded-l-none"
                                  {...field}
                                  value={field.value.replace('#', '')}
                                  onChange={e => field.onChange(`#${e.target.value}`)}
                                />
                              </FormControl>
                            </div>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="buttonTextColor"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Button Text Color</FormLabel>
                            <div className="flex">
                              <span className="inline-flex items-center px-3 rounded-l-md border border-r-0 border-gray-300 bg-gray-50 text-gray-500 sm:text-sm">
                                #
                              </span>
                              <FormControl>
                                <Input 
                                  className="rounded-l-none"
                                  {...field}
                                  value={field.value.replace('#', '')}
                                  onChange={e => field.onChange(`#${e.target.value}`)}
                                />
                              </FormControl>
                            </div>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>

                    <FormField
                      control={form.control}
                      name="customCSS"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Custom CSS</FormLabel>
                          <FormControl>
                            <Textarea 
                              placeholder=".upsell-popup {
  border-radius: 8px;
  box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1);
}"
                              {...field}
                              rows={6}
                              className="font-mono"
                            />
                          </FormControl>
                          <FormDescription>
                            Add custom CSS to further style your popup
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </TabsContent>

                  <TabsContent value="advanced" className="space-y-6 mt-0">
                    <FormField
                      control={form.control}
                      name="customJS"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Custom JavaScript</FormLabel>
                          <FormControl>
                            <Textarea 
                              placeholder="// Add your custom JavaScript here
document.addEventListener('DOMContentLoaded', function() {
  // Your code here
});"
                              {...field}
                              rows={6}
                              className="font-mono"
                            />
                          </FormControl>
                          <FormDescription>
                            Advanced users can add custom JavaScript for additional functionality
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="displayCondition"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Display Conditions</FormLabel>
                          <Select 
                            onValueChange={field.onChange} 
                            defaultValue={field.value}
                          >
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Select display condition" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              {displayConditionOptions.map((option) => (
                                <SelectItem key={option.value} value={option.value}>
                                  {option.label}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="limitDisplays"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-start space-x-3 space-y-0 rounded-md p-4 border">
                          <FormControl>
                            <Checkbox
                              checked={field.value}
                              onCheckedChange={field.onChange}
                            />
                          </FormControl>
                          <div className="space-y-1 leading-none">
                            <FormLabel>Limit displays per session</FormLabel>
                            <FormDescription>
                              Limit how many times a customer sees this offer in a single session
                            </FormDescription>
                          </div>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="skipCart"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-start space-x-3 space-y-0 rounded-md p-4 border">
                          <FormControl>
                            <Checkbox
                              checked={field.value}
                              onCheckedChange={field.onChange}
                            />
                          </FormControl>
                          <div className="space-y-1 leading-none">
                            <FormLabel>Skip cart and go to checkout</FormLabel>
                            <FormDescription>
                              When customers accept the offer, skip the cart page and go directly to checkout
                            </FormDescription>
                          </div>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </TabsContent>
                </div>

                <div className="space-y-4">
                  <h4 className="text-sm font-medium text-shopify-ink">Preview</h4>
                  <div className="bg-gray-50 p-4 rounded border border-gray-200">
                    <OfferPreview offer={formValues} />
                  </div>
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-4 border-t">
                <Button type="button" variant="outline" onClick={onClose}>
                  Cancel
                </Button>
                <Button type="submit" className="bg-shopify-green hover:bg-shopify-green/90">
                  {isEditing ? "Update" : "Save"} Offer
                </Button>
              </div>
            </form>
          </Form>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}
