import { pgTable, text, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  isPremium: boolean("is_premium").default(false),
  stripeCustomerId: text("stripe_customer_id"),
  stripeSubscriptionId: text("stripe_subscription_id"),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  isPremium: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

// Offer types
export const offerTypes = {
  PRE_PURCHASE: "pre_purchase",
  POST_PURCHASE: "post_purchase",
} as const;

export type OfferType = typeof offerTypes[keyof typeof offerTypes];

// Offer schema
export const offers = pgTable("offers", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  offerType: text("offer_type").default(offerTypes.PRE_PURCHASE),
  triggerProduct: text("trigger_product").notNull(),
  upsellProduct: text("upsell_product").notNull(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  active: boolean("active").default(true),
  backgroundColor: text("background_color").default("#ffffff"),
  textColor: text("text_color").default("#212b36"),
  buttonColor: text("button_color").default("#008060"),
  buttonTextColor: text("button_text_color").default("#ffffff"),
  customCSS: text("custom_css").default(""),
  customJS: text("custom_js").default(""),
  displayCondition: text("display_condition").default("all"),
  limitDisplays: boolean("limit_displays").default(false),
  skipCart: boolean("skip_cart").default(false),
  createdAt: timestamp("created_at").defaultNow(),
  conversions: integer("conversions").default(0),
  displays: integer("displays").default(0),
});

export const insertOfferSchema = createInsertSchema(offers).omit({
  id: true,
  createdAt: true,
  conversions: true,
  displays: true,
});

export type InsertOffer = z.infer<typeof insertOfferSchema>;
export type Offer = typeof offers.$inferSelect;
