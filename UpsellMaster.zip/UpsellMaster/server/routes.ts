import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { z } from "zod";
import { 
  insertUserSchema, 
  insertUpsellOfferSchema,
  insertActivityLogSchema
} from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Users routes
  app.get("/api/user", async (req, res) => {
    // In a real app, this would be from session/auth
    const userId = 1; 
    const user = await storage.getUser(userId);
    
    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }
    
    // Don't send the password back
    const { password, ...userWithoutPassword } = user;
    res.json(userWithoutPassword);
  });

  app.patch("/api/user", async (req, res) => {
    const userId = 1; // From session in a real app
    
    try {
      const updateSchema = z.object({
        shopName: z.string().optional(),
        isPremium: z.boolean().optional(),
        apiKey: z.string().optional(),
        monthlyOrders: z.number().optional(),
      });
      
      const userData = updateSchema.parse(req.body);
      const updatedUser = await storage.updateUser(userId, userData);
      
      if (!updatedUser) {
        return res.status(404).json({ message: "User not found" });
      }
      
      const { password, ...userWithoutPassword } = updatedUser;
      res.json(userWithoutPassword);
    } catch (error) {
      res.status(400).json({ message: "Invalid user data", error });
    }
  });

  // Upsell offers routes
  app.get("/api/offers", async (req, res) => {
    const userId = 1; // From session in a real app
    const offers = await storage.getUpsellOffers(userId);
    res.json(offers);
  });

  app.get("/api/offers/:id", async (req, res) => {
    const offerId = parseInt(req.params.id);
    
    if (isNaN(offerId)) {
      return res.status(400).json({ message: "Invalid offer ID" });
    }
    
    const offer = await storage.getUpsellOffer(offerId);
    
    if (!offer) {
      return res.status(404).json({ message: "Offer not found" });
    }
    
    // In a real app, we would check if the offer belongs to the logged-in user
    res.json(offer);
  });

  app.post("/api/offers", async (req, res) => {
    const userId = 1; // From session in a real app
    
    try {
      const offerData = insertUpsellOfferSchema.parse({
        ...req.body,
        userId
      });
      
      // Check if it's a premium feature (checkout or post-purchase)
      const user = await storage.getUser(userId);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      if (!user.isPremium && 
          (offerData.type === "checkout" || offerData.type === "post-purchase")) {
        return res.status(403).json({ 
          message: "This offer type requires a premium subscription" 
        });
      }
      
      const newOffer = await storage.createUpsellOffer(offerData);
      res.status(201).json(newOffer);
    } catch (error) {
      res.status(400).json({ message: "Invalid offer data", error });
    }
  });

  app.patch("/api/offers/:id", async (req, res) => {
    const offerId = parseInt(req.params.id);
    
    if (isNaN(offerId)) {
      return res.status(400).json({ message: "Invalid offer ID" });
    }
    
    try {
      const offer = await storage.getUpsellOffer(offerId);
      
      if (!offer) {
        return res.status(404).json({ message: "Offer not found" });
      }
      
      // In a real app, we would check if the offer belongs to the logged-in user
      
      // Validate the update data (partial validation)
      const updateSchema = z.object({
        name: z.string().optional(),
        enabled: z.boolean().optional(),
        headline: z.string().optional(),
        description: z.string().optional(),
        buttonText: z.string().optional(),
        declineText: z.string().optional(),
        displayMode: z.string().optional(),
        customCss: z.string().optional(),
        customJs: z.string().optional(),
        triggerProducts: z.any().optional(),
        upsellProducts: z.any().optional(),
        discountEnabled: z.boolean().optional(),
        discountType: z.string().optional(),
        discountValue: z.number().optional(),
      });
      
      const offerData = updateSchema.parse(req.body);
      const updatedOffer = await storage.updateUpsellOffer(offerId, offerData);
      
      res.json(updatedOffer);
    } catch (error) {
      res.status(400).json({ message: "Invalid offer data", error });
    }
  });

  app.delete("/api/offers/:id", async (req, res) => {
    const offerId = parseInt(req.params.id);
    
    if (isNaN(offerId)) {
      return res.status(400).json({ message: "Invalid offer ID" });
    }
    
    const offer = await storage.getUpsellOffer(offerId);
    
    if (!offer) {
      return res.status(404).json({ message: "Offer not found" });
    }
    
    // In a real app, we would check if the offer belongs to the logged-in user
    
    const success = await storage.deleteUpsellOffer(offerId);
    
    if (success) {
      res.status(204).send();
    } else {
      res.status(500).json({ message: "Failed to delete offer" });
    }
  });

  // Analytics routes
  app.get("/api/analytics", async (req, res) => {
    const userId = 1; // From session in a real app
    
    let offerId: number | undefined = undefined;
    if (req.query.offerId && typeof req.query.offerId === "string") {
      offerId = parseInt(req.query.offerId);
      if (isNaN(offerId)) {
        return res.status(400).json({ message: "Invalid offer ID" });
      }
    }
    
    const analytics = await storage.getAnalytics(userId, offerId);
    res.json(analytics);
  });

  app.post("/api/analytics/track", async (req, res) => {
    const userId = 1; // From session in a real app
    
    try {
      const trackSchema = z.object({
        offerId: z.number(),
        action: z.enum(["impression", "click", "conversion"]),
        revenue: z.number().optional(),
      });
      
      const { offerId, action, revenue = 0 } = trackSchema.parse(req.body);
      
      // Ensure the offer exists and belongs to the user
      const offer = await storage.getUpsellOffer(offerId);
      if (!offer || offer.userId !== userId) {
        return res.status(404).json({ message: "Offer not found" });
      }
      
      // Check the monthly order limit for non-premium users
      if (action === "conversion") {
        const user = await storage.getUser(userId);
        if (!user) {
          return res.status(404).json({ message: "User not found" });
        }
        
        if (!user.isPremium && user.monthlyOrders >= 100) {
          return res.status(403).json({ 
            message: "You have reached the monthly order limit for the free plan" 
          });
        }
        
        // Increment the monthly orders count
        await storage.updateUser(userId, { monthlyOrders: (user.monthlyOrders || 0) + 1 });
      }
      
      // Track the action
      switch (action) {
        case "impression":
          await storage.trackImpression(userId, offerId);
          break;
        case "click":
          await storage.trackClick(userId, offerId);
          break;
        case "conversion":
          await storage.trackConversion(userId, offerId, revenue);
          break;
      }
      
      res.json({ success: true });
    } catch (error) {
      res.status(400).json({ message: "Invalid tracking data", error });
    }
  });

  // Activity logs routes
  app.get("/api/activity", async (req, res) => {
    const userId = 1; // From session in a real app
    
    let limit = 10;
    if (req.query.limit && typeof req.query.limit === "string") {
      const parsedLimit = parseInt(req.query.limit);
      if (!isNaN(parsedLimit)) {
        limit = parsedLimit;
      }
    }
    
    const activities = await storage.getRecentActivity(userId, limit);
    res.json(activities);
  });

  app.post("/api/activity", async (req, res) => {
    const userId = 1; // From session in a real app
    
    try {
      const activityData = insertActivityLogSchema.parse({
        ...req.body,
        userId
      });
      
      const activity = await storage.logActivity(activityData);
      res.status(201).json(activity);
    } catch (error) {
      res.status(400).json({ message: "Invalid activity data", error });
    }
  });

  // Create and return the HTTP server
  const httpServer = createServer(app);
  return httpServer;
}
