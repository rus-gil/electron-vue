import { 
  users, type User, type InsertUser, 
  upsellOffers, type UpsellOffer, type InsertUpsellOffer,
  analytics, type Analytics, type InsertAnalytics,
  activityLogs, type ActivityLog, type InsertActivityLog
} from "@shared/schema";

export interface IStorage {
  // User management
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, user: Partial<User>): Promise<User | undefined>;

  // Upsell offers
  getUpsellOffers(userId: number): Promise<UpsellOffer[]>;
  getUpsellOffer(id: number): Promise<UpsellOffer | undefined>;
  createUpsellOffer(offer: InsertUpsellOffer): Promise<UpsellOffer>;
  updateUpsellOffer(id: number, offer: Partial<UpsellOffer>): Promise<UpsellOffer | undefined>;
  deleteUpsellOffer(id: number): Promise<boolean>;

  // Analytics
  getAnalytics(userId: number, offerId?: number): Promise<Analytics[]>;
  trackImpression(userId: number, offerId: number): Promise<void>;
  trackClick(userId: number, offerId: number): Promise<void>;
  trackConversion(userId: number, offerId: number, revenue: number): Promise<void>;

  // Activity logs
  getRecentActivity(userId: number, limit?: number): Promise<ActivityLog[]>;
  logActivity(activity: InsertActivityLog): Promise<ActivityLog>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private upsellOffers: Map<number, UpsellOffer>;
  private analytics: Map<number, Analytics>;
  private activityLogs: Map<number, ActivityLog>;
  
  private userId: number;
  private offerId: number;
  private analyticsId: number;
  private activityLogId: number;

  constructor() {
    this.users = new Map();
    this.upsellOffers = new Map();
    this.analytics = new Map();
    this.activityLogs = new Map();
    
    this.userId = 1;
    this.offerId = 1;
    this.analyticsId = 1;
    this.activityLogId = 1;

    // Create a demo user
    this.createUser({
      username: "shopify_demo",
      password: "password123",
      shopName: "Jane's Shop",
      isPremium: false,
      apiKey: "demo_api_key",
      monthlyOrders: 37
    });

    // Create some demo offers
    this.createUpsellOffer({
      userId: 1,
      name: "Summer T-Shirt Bundle Offer",
      type: "pre-purchase",
      enabled: true,
      headline: "Complete Your Look!",
      description: "Add this matching accessory to your order and save 15%!",
      buttonText: "Yes, Add This Item",
      declineText: "No, Thanks",
      displayMode: "selected",
      triggerProducts: [{ id: "123", name: "Organic Cotton T-shirt", price: 2999 }, { id: "456", name: "Premium Denim Jacket", price: 8999 }],
      upsellProducts: [{ id: "789", name: "Matching Wristband", price: 1499 }],
      discountEnabled: true,
      discountType: "percentage",
      discountValue: 15
    });

    this.createUpsellOffer({
      userId: 1,
      name: "Product Page Accessories Offer",
      type: "product-page",
      enabled: true,
      headline: "Enhance Your Purchase!",
      description: "These items go great with your selection.",
      buttonText: "Add to Cart",
      declineText: "No, Thanks",
      displayMode: "all",
      triggerProducts: [],
      upsellProducts: [{ id: "789", name: "Matching Wristband", price: 1499 }],
      discountEnabled: true,
      discountType: "percentage",
      discountValue: 10
    });

    this.createUpsellOffer({
      userId: 1,
      name: "Cart Drawer Offer",
      type: "cart-drawer",
      enabled: false,
      headline: "Wait! Don't miss this deal!",
      description: "Add this item to your cart before checkout.",
      buttonText: "Add Now",
      declineText: "Continue to Checkout",
      displayMode: "all",
      triggerProducts: [],
      upsellProducts: [{ id: "101", name: "Water Bottle", price: 1999 }],
      discountEnabled: false,
      discountType: "percentage",
      discountValue: 0
    });

    // Add some analytics data
    this.analytics.set(this.analyticsId++, {
      id: 1,
      userId: 1,
      offerId: 1,
      impressions: 874,
      clicks: 216,
      conversions: 54,
      revenue: 124789, // $1,247.89
      date: new Date()
    });

    this.analytics.set(this.analyticsId++, {
      id: 2,
      userId: 1,
      offerId: 2,
      impressions: 1243,
      clicks: 187,
      conversions: 28,
      revenue: 41972, // $419.72
      date: new Date()
    });

    // Add some activity logs
    this.logActivity({
      userId: 1,
      offerId: 1,
      action: "conversion",
      productId: "789",
      productName: "Matching Wristband",
      amount: 1274 // $12.74 (with 15% discount)
    });

    this.logActivity({
      userId: 1,
      offerId: 2,
      action: "conversion",
      productId: "789",
      productName: "Matching Wristband",
      amount: 1349 // $13.49 (with 10% discount)
    });

    this.logActivity({
      userId: 1,
      offerId: 1,
      action: "decline",
      productId: "101",
      productName: "Water Bottle",
      amount: 0
    });
  }

  // User management
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userId++;
    const user: User = { ...insertUser, id, createdAt: new Date() };
    this.users.set(id, user);
    return user;
  }

  async updateUser(id: number, userData: Partial<User>): Promise<User | undefined> {
    const user = this.users.get(id);
    if (!user) return undefined;
    
    const updatedUser = { ...user, ...userData };
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  // Upsell offers
  async getUpsellOffers(userId: number): Promise<UpsellOffer[]> {
    return Array.from(this.upsellOffers.values()).filter(
      (offer) => offer.userId === userId
    );
  }

  async getUpsellOffer(id: number): Promise<UpsellOffer | undefined> {
    return this.upsellOffers.get(id);
  }

  async createUpsellOffer(insertOffer: InsertUpsellOffer): Promise<UpsellOffer> {
    const id = this.offerId++;
    const now = new Date();
    const offer: UpsellOffer = { ...insertOffer, id, createdAt: now, updatedAt: now };
    this.upsellOffers.set(id, offer);
    return offer;
  }

  async updateUpsellOffer(id: number, offerData: Partial<UpsellOffer>): Promise<UpsellOffer | undefined> {
    const offer = this.upsellOffers.get(id);
    if (!offer) return undefined;
    
    const updatedOffer = { ...offer, ...offerData, updatedAt: new Date() };
    this.upsellOffers.set(id, updatedOffer);
    return updatedOffer;
  }

  async deleteUpsellOffer(id: number): Promise<boolean> {
    return this.upsellOffers.delete(id);
  }

  // Analytics
  async getAnalytics(userId: number, offerId?: number): Promise<Analytics[]> {
    return Array.from(this.analytics.values()).filter(
      (analytics) => 
        analytics.userId === userId && 
        (offerId === undefined || analytics.offerId === offerId)
    );
  }

  async trackImpression(userId: number, offerId: number): Promise<void> {
    const existingAnalytics = Array.from(this.analytics.values()).find(
      a => a.userId === userId && a.offerId === offerId
    );

    if (existingAnalytics) {
      existingAnalytics.impressions += 1;
      this.analytics.set(existingAnalytics.id, existingAnalytics);
    } else {
      this.analytics.set(this.analyticsId++, {
        id: this.analyticsId,
        userId,
        offerId,
        impressions: 1,
        clicks: 0,
        conversions: 0,
        revenue: 0,
        date: new Date()
      });
    }
  }

  async trackClick(userId: number, offerId: number): Promise<void> {
    const existingAnalytics = Array.from(this.analytics.values()).find(
      a => a.userId === userId && a.offerId === offerId
    );

    if (existingAnalytics) {
      existingAnalytics.clicks += 1;
      this.analytics.set(existingAnalytics.id, existingAnalytics);
    } else {
      this.analytics.set(this.analyticsId++, {
        id: this.analyticsId,
        userId,
        offerId,
        impressions: 0,
        clicks: 1,
        conversions: 0,
        revenue: 0,
        date: new Date()
      });
    }
  }

  async trackConversion(userId: number, offerId: number, revenue: number): Promise<void> {
    const existingAnalytics = Array.from(this.analytics.values()).find(
      a => a.userId === userId && a.offerId === offerId
    );

    if (existingAnalytics) {
      existingAnalytics.conversions += 1;
      existingAnalytics.revenue += revenue;
      this.analytics.set(existingAnalytics.id, existingAnalytics);
    } else {
      this.analytics.set(this.analyticsId++, {
        id: this.analyticsId,
        userId,
        offerId,
        impressions: 0,
        clicks: 0,
        conversions: 1,
        revenue,
        date: new Date()
      });
    }
  }

  // Activity logs
  async getRecentActivity(userId: number, limit: number = 10): Promise<ActivityLog[]> {
    return Array.from(this.activityLogs.values())
      .filter(log => log.userId === userId)
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime())
      .slice(0, limit);
  }

  async logActivity(insertActivity: InsertActivityLog): Promise<ActivityLog> {
    const id = this.activityLogId++;
    const activity: ActivityLog = { ...insertActivity, id, createdAt: new Date() };
    this.activityLogs.set(id, activity);
    return activity;
  }
}

export const storage = new MemStorage();
