import { Switch, Route } from "wouter";
import Dashboard from "@/pages/dashboard";
import OfferEditor from "@/pages/offer-editor";
import Analytics from "@/pages/analytics";
import Settings from "@/pages/settings";
import NotFound from "@/pages/not-found";
import AppContainer from "@/components/AppContainer";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Dashboard} />
      <Route path="/offers/new" component={OfferEditor} />
      <Route path="/offers/:id" component={OfferEditor} />
      <Route path="/analytics" component={Analytics} />
      <Route path="/settings" component={Settings} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <AppContainer>
      <Router />
    </AppContainer>
  );
}

export default App;
