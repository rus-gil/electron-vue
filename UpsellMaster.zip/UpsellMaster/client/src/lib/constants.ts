export const UPSELL_TYPES = [
  {
    id: 'pre-purchase',
    name: 'Pre-purchase Offer',
    description: 'Triggered on Add to Cart',
    icon: 'shopping-cart-2-line',
    isPremium: false,
    bgColorClass: 'bg-shopify-green',
    textColorClass: 'text-shopify-green',
  },
  {
    id: 'product-page',
    name: 'Product Page Offer',
    description: 'Shows on product pages',
    icon: 'shopping-bag-line',
    isPremium: false,
    bgColorClass: 'bg-shopify-purple',
    textColorClass: 'text-shopify-purple',
  },
  {
    id: 'cart-drawer',
    name: 'Cart Drawer Offer',
    description: 'Shows in cart sidebar',
    icon: 'shopping-cart-line',
    isPremium: false,
    bgColorClass: 'bg-shopify-text-secondary',
    textColorClass: 'text-shopify-text-secondary',
  },
  {
    id: 'checkout',
    name: 'Checkout Offer',
    description: 'Shows during checkout',
    icon: 'secure-payment-line',
    isPremium: true,
    bgColorClass: 'bg-gray-200',
    textColorClass: 'text-gray-400',
  },
  {
    id: 'post-purchase',
    name: 'Post-purchase Offer',
    description: 'Shows after purchase',
    icon: 'gift-line',
    isPremium: true,
    bgColorClass: 'bg-gray-200',
    textColorClass: 'text-gray-400',
  },
];

export const PREMIUM_FEATURES = [
  'Unlimited monthly orders',
  'Checkout page upsell offers',
  'Post-purchase upsell offers',
  'Advanced analytics and reporting',
  'Priority support',
];

export const DISCOUNT_TYPES = [
  { value: 'percentage', label: 'Percentage' },
  { value: 'fixed', label: 'Fixed amount' },
];

export const DISPLAY_MODES = [
  { value: 'all', label: 'All products' },
  { value: 'selected', label: 'Selected products' },
  { value: 'collections', label: 'Collections' },
];
