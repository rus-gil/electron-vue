export interface Product {
  id: string;
  name: string;
  price: number;
  image?: string;
}

export interface UpsellOffer {
  id: number;
  userId: number;
  name: string;
  type: 'pre-purchase' | 'product-page' | 'cart-drawer' | 'checkout' | 'post-purchase';
  enabled: boolean;
  headline: string;
  description: string;
  buttonText: string;
  declineText: string;
  displayMode: 'all' | 'selected' | 'collections';
  customCss?: string;
  customJs?: string;
  triggerProducts: Product[];
  upsellProducts: Product[];
  discountEnabled: boolean;
  discountType: 'percentage' | 'fixed';
  discountValue: number;
  createdAt: Date;
  updatedAt: Date;
}

export interface User {
  id: number;
  username: string;
  shopName?: string;
  isPremium: boolean;
  apiKey?: string;
  monthlyOrders: number;
  createdAt: Date;
}

export interface Analytics {
  id: number;
  userId: number;
  offerId: number;
  impressions: number;
  clicks: number;
  conversions: number;
  revenue: number;
  date: Date;
}

export interface ActivityLog {
  id: number;
  userId: number;
  offerId?: number;
  action: 'impression' | 'click' | 'conversion' | 'decline';
  productId?: string;
  productName?: string;
  amount: number;
  createdAt: Date;
}

export interface OfferSummary {
  id: number;
  name: string;
  type: UpsellOffer['type'];
  enabled: boolean;
  analytics: {
    impressions: number;
    clicks: number;
    conversions: number;
    conversionRate: string;
  };
}
