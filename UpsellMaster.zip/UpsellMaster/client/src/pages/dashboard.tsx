import { useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import UsageSummary from "@/components/UsageSummary";
import UpsellOffersGrid from "@/components/UpsellOffersGrid";
import RecentActivity from "@/components/RecentActivity";
import PremiumBanner from "@/components/PremiumBanner";

const Dashboard = () => {
  const [, navigate] = useLocation();
  
  const { data: user } = useQuery({
    queryKey: ['/api/user'],
  });
  
  return (
    <div className="py-6">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 md:px-8 flex justify-between items-center">
        <h1 className="text-2xl font-semibold text-shopify-text">Dashboard</h1>
        {!user?.isPremium && (
          <Button className="bg-shopify-green hover:bg-shopify-green" onClick={() => navigate("/settings")}>
            <i className="ri-rocket-line mr-2"></i>
            Upgrade to Premium
          </Button>
        )}
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 md:px-8">
        <UsageSummary />
        <UpsellOffersGrid />
        <RecentActivity />
        {!user?.isPremium && <PremiumBanner />}
      </div>
    </div>
  );
};

export default Dashboard;
