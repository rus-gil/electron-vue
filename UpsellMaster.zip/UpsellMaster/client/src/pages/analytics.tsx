import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts";
import { formatCurrency, calculateConversionRate } from "@/lib/utils";
import { UPSELL_TYPES } from "@/lib/constants";

const Analytics = () => {
  const { data: analytics = [] } = useQuery({
    queryKey: ['/api/analytics'],
  });
  
  const { data: offers = [] } = useQuery({
    queryKey: ['/api/offers'],
  });
  
  // Create data for the chart
  const barChartData = offers.map(offer => {
    const offerAnalytics = analytics.find(a => a.offerId === offer.id) || { 
      impressions: 0, 
      clicks: 0, 
      conversions: 0,
      revenue: 0
    };
    
    const typeConfig = UPSELL_TYPES.find(t => t.id === offer.type);
    
    return {
      name: offer.name,
      type: typeConfig?.name || offer.type,
      impressions: offerAnalytics.impressions,
      clicks: offerAnalytics.clicks,
      conversions: offerAnalytics.conversions,
      revenue: offerAnalytics.revenue / 100, // Convert cents to dollars for chart
      conversionRate: calculateConversionRate(offerAnalytics.clicks, offerAnalytics.conversions)
    };
  });
  
  // Calculate totals
  const totalImpressions = analytics.reduce((sum, item) => sum + item.impressions, 0);
  const totalClicks = analytics.reduce((sum, item) => sum + item.clicks, 0);
  const totalConversions = analytics.reduce((sum, item) => sum + item.conversions, 0);
  const totalRevenue = analytics.reduce((sum, item) => sum + item.revenue, 0);
  const overallConversionRate = totalClicks > 0 ? (totalConversions / totalClicks) * 100 : 0;
  
  return (
    <div className="py-6">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 md:px-8">
        <h1 className="text-2xl font-semibold text-shopify-text mb-6">Analytics</h1>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm text-shopify-text-secondary">Total Impressions</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-3xl font-semibold">{totalImpressions.toLocaleString()}</p>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm text-shopify-text-secondary">Total Clicks</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-3xl font-semibold">{totalClicks.toLocaleString()}</p>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm text-shopify-text-secondary">Conversion Rate</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-3xl font-semibold">{overallConversionRate.toFixed(1)}%</p>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm text-shopify-text-secondary">Total Revenue</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-3xl font-semibold">{formatCurrency(totalRevenue)}</p>
            </CardContent>
          </Card>
        </div>
        
        <Card className="mb-6">
          <CardHeader>
            <CardTitle>Performance by Offer</CardTitle>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="impressions">
              <TabsList className="mb-4">
                <TabsTrigger value="impressions">Impressions</TabsTrigger>
                <TabsTrigger value="clicks">Clicks</TabsTrigger>
                <TabsTrigger value="conversions">Conversions</TabsTrigger>
                <TabsTrigger value="revenue">Revenue</TabsTrigger>
                <TabsTrigger value="conversion-rate">Conversion Rate</TabsTrigger>
              </TabsList>
              
              <TabsContent value="impressions">
                <div className="h-96">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={barChartData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="name" />
                      <YAxis />
                      <Tooltip />
                      <Legend />
                      <Bar dataKey="impressions" name="Impressions" fill="hsl(var(--chart-1))" />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </TabsContent>
              
              <TabsContent value="clicks">
                <div className="h-96">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={barChartData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="name" />
                      <YAxis />
                      <Tooltip />
                      <Legend />
                      <Bar dataKey="clicks" name="Clicks" fill="hsl(var(--chart-2))" />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </TabsContent>
              
              <TabsContent value="conversions">
                <div className="h-96">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={barChartData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="name" />
                      <YAxis />
                      <Tooltip />
                      <Legend />
                      <Bar dataKey="conversions" name="Conversions" fill="hsl(var(--chart-3))" />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </TabsContent>
              
              <TabsContent value="revenue">
                <div className="h-96">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={barChartData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="name" />
                      <YAxis />
                      <Tooltip formatter={(value) => [`$${value}`, 'Revenue']} />
                      <Legend />
                      <Bar dataKey="revenue" name="Revenue ($)" fill="hsl(var(--chart-4))" />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </TabsContent>
              
              <TabsContent value="conversion-rate">
                <div className="h-96">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={barChartData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="name" />
                      <YAxis />
                      <Tooltip formatter={(value) => [`${value}`, 'Conversion Rate']} />
                      <Legend />
                      <Bar dataKey="conversionRate" name="Conversion Rate (%)" fill="hsl(var(--chart-5))" />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader>
            <CardTitle>Detailed Metrics</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="w-full text-left">
                <thead>
                  <tr>
                    <th className="p-3 border-b font-medium">Offer Name</th>
                    <th className="p-3 border-b font-medium">Type</th>
                    <th className="p-3 border-b font-medium text-right">Impressions</th>
                    <th className="p-3 border-b font-medium text-right">Clicks</th>
                    <th className="p-3 border-b font-medium text-right">Conversions</th>
                    <th className="p-3 border-b font-medium text-right">Conv. Rate</th>
                    <th className="p-3 border-b font-medium text-right">Revenue</th>
                  </tr>
                </thead>
                <tbody>
                  {barChartData.map((offer, index) => (
                    <tr key={index} className="hover:bg-gray-50">
                      <td className="p-3 border-b">{offer.name}</td>
                      <td className="p-3 border-b">{offer.type}</td>
                      <td className="p-3 border-b text-right">{offer.impressions.toLocaleString()}</td>
                      <td className="p-3 border-b text-right">{offer.clicks.toLocaleString()}</td>
                      <td className="p-3 border-b text-right">{offer.conversions.toLocaleString()}</td>
                      <td className="p-3 border-b text-right">{offer.conversionRate}</td>
                      <td className="p-3 border-b text-right">{formatCurrency(offer.revenue * 100)}</td>
                    </tr>
                  ))}
                </tbody>
                <tfoot>
                  <tr className="font-medium">
                    <td className="p-3 border-t">Total</td>
                    <td className="p-3 border-t"></td>
                    <td className="p-3 border-t text-right">{totalImpressions.toLocaleString()}</td>
                    <td className="p-3 border-t text-right">{totalClicks.toLocaleString()}</td>
                    <td className="p-3 border-t text-right">{totalConversions.toLocaleString()}</td>
                    <td className="p-3 border-t text-right">{overallConversionRate.toFixed(1)}%</td>
                    <td className="p-3 border-t text-right">{formatCurrency(totalRevenue)}</td>
                  </tr>
                </tfoot>
              </table>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default Analytics;
