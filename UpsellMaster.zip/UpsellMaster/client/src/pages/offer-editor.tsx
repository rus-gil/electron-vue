import { useLocation } from "wouter";
import OfferEditor from "@/components/OfferEditor";

const OfferEditorPage = () => {
  const [location] = useLocation();
  
  // Parse offerId from URL if it exists
  const offerId = location.startsWith('/offers/') 
    ? location.split('/').pop() 
    : undefined;
  
  // Parse offer type from query string if creating a new offer
  const searchParams = new URLSearchParams(window.location.search);
  const offerType = searchParams.get('type') || 'pre-purchase';
  
  // Make sure it's not a numeric ID (which would be an edit page)
  const defaultType = !isNaN(Number(offerType)) ? 'pre-purchase' : offerType;
  
  return <OfferEditor offerId={offerId} defaultType={defaultType} />;
};

export default OfferEditorPage;
