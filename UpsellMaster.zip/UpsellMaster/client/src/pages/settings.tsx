import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Switch } from "@/components/ui/switch";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { PREMIUM_FEATURES } from "@/lib/constants";

const Settings = () => {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [apiKey, setApiKey] = useState("");
  
  const { data: user } = useQuery({
    queryKey: ['/api/user'],
  });
  
  const updateUserMutation = useMutation({
    mutationFn: async (userData: any) => {
      return apiRequest("PATCH", "/api/user", userData);
    },
    onSuccess: () => {
      toast({
        title: "Settings updated",
        description: "Your changes have been saved.",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/user'] });
    },
    onError: (error) => {
      toast({
        title: "Error updating settings",
        description: error.message || "Something went wrong. Please try again.",
        variant: "destructive",
      });
    }
  });
  
  const togglePremium = () => {
    // In a real app, this would redirect to a payment page or process
    updateUserMutation.mutate({ isPremium: !user?.isPremium });
  };
  
  const saveApiKey = () => {
    if (!apiKey.trim()) {
      toast({
        title: "Error",
        description: "API key cannot be empty",
        variant: "destructive",
      });
      return;
    }
    
    updateUserMutation.mutate({ apiKey });
  };
  
  const resetMonthlyOrders = () => {
    updateUserMutation.mutate({ monthlyOrders: 0 });
  };
  
  return (
    <div className="py-6">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 md:px-8">
        <h1 className="text-2xl font-semibold text-shopify-text mb-6">Settings</h1>
        
        <Tabs defaultValue="account">
          <TabsList className="mb-6">
            <TabsTrigger value="account">Account</TabsTrigger>
            <TabsTrigger value="subscription">Subscription</TabsTrigger>
            <TabsTrigger value="api">API</TabsTrigger>
          </TabsList>
          
          <TabsContent value="account">
            <Card>
              <CardHeader>
                <CardTitle>Account Information</CardTitle>
                <CardDescription>
                  Manage your account settings and preferences
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-2">
                  <Label htmlFor="shopName">Shop Name</Label>
                  <Input 
                    id="shopName" 
                    value={user?.shopName || ""}
                    onChange={(e) => updateUserMutation.mutate({ shopName: e.target.value })}
                    placeholder="Your Shop Name"
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="username">Username</Label>
                  <Input 
                    id="username" 
                    value={user?.username || ""}
                    disabled
                    className="bg-gray-50"
                  />
                  <p className="text-xs text-shopify-text-secondary">
                    Username cannot be changed
                  </p>
                </div>
                
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <Label>Monthly Orders</Label>
                    <Button 
                      variant="outline" 
                      size="sm" 
                      onClick={resetMonthlyOrders}
                      disabled={user?.monthlyOrders === 0}
                    >
                      Reset
                    </Button>
                  </div>
                  <div className="h-2 w-full bg-gray-200 rounded-full overflow-hidden">
                    <div 
                      className="h-full bg-shopify-green" 
                      style={{ 
                        width: `${Math.min((user?.monthlyOrders || 0) / (user?.isPremium ? 1000 : 100) * 100, 100)}%` 
                      }}
                    ></div>
                  </div>
                  <div className="flex justify-between text-xs text-shopify-text-secondary">
                    <span>{user?.monthlyOrders || 0} orders used this month</span>
                    <span>{user?.isPremium ? 'Unlimited' : '100'} orders limit</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="subscription">
            <Card>
              <CardHeader>
                <CardTitle>Subscription Plan</CardTitle>
                <CardDescription>
                  Manage your subscription and billing
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex justify-between items-center mb-6">
                  <div>
                    <h3 className="text-lg font-medium text-shopify-text">
                      {user?.isPremium ? "Premium Plan" : "Free Plan"}
                    </h3>
                    <p className="text-sm text-shopify-text-secondary">
                      {user?.isPremium 
                        ? "You have access to all premium features" 
                        : "Upgrade to unlock premium features"}
                    </p>
                  </div>
                  <Switch 
                    checked={!!user?.isPremium}
                    onCheckedChange={togglePremium}
                  />
                </div>
                
                <div className="border rounded-lg p-4 mb-6">
                  <h4 className="text-base font-medium mb-3 flex items-center">
                    <i className={`ri-vip-crown-line ${user?.isPremium ? 'text-shopify-gold' : 'text-shopify-text-secondary'} mr-2`}></i>
                    Premium Features
                  </h4>
                  <ul className="space-y-2">
                    {PREMIUM_FEATURES.map((feature, index) => (
                      <li key={index} className="flex items-center text-sm">
                        <i className={`ri-check-line ${user?.isPremium ? 'text-shopify-success' : 'text-shopify-text-secondary'} mr-2`}></i>
                        {feature}
                      </li>
                    ))}
                  </ul>
                </div>
                
                <div className="space-y-4">
                  <h4 className="text-base font-medium">Plan Comparison</h4>
                  <div className="overflow-x-auto">
                    <table className="w-full text-sm">
                      <thead>
                        <tr className="border-b">
                          <th className="text-left pb-2 font-medium">Feature</th>
                          <th className="text-center pb-2 font-medium">Free</th>
                          <th className="text-center pb-2 font-medium">Premium</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr className="border-b">
                          <td className="py-3">Monthly Order Limit</td>
                          <td className="text-center py-3">100</td>
                          <td className="text-center py-3">Unlimited</td>
                        </tr>
                        <tr className="border-b">
                          <td className="py-3">Pre-purchase Upsell</td>
                          <td className="text-center py-3"><i className="ri-check-line text-shopify-success"></i></td>
                          <td className="text-center py-3"><i className="ri-check-line text-shopify-success"></i></td>
                        </tr>
                        <tr className="border-b">
                          <td className="py-3">Product Page Upsell</td>
                          <td className="text-center py-3"><i className="ri-check-line text-shopify-success"></i></td>
                          <td className="text-center py-3"><i className="ri-check-line text-shopify-success"></i></td>
                        </tr>
                        <tr className="border-b">
                          <td className="py-3">Cart Drawer Upsell</td>
                          <td className="text-center py-3"><i className="ri-check-line text-shopify-success"></i></td>
                          <td className="text-center py-3"><i className="ri-check-line text-shopify-success"></i></td>
                        </tr>
                        <tr className="border-b">
                          <td className="py-3">Checkout Upsell</td>
                          <td className="text-center py-3"><i className="ri-close-line text-shopify-error"></i></td>
                          <td className="text-center py-3"><i className="ri-check-line text-shopify-success"></i></td>
                        </tr>
                        <tr className="border-b">
                          <td className="py-3">Post-purchase Upsell</td>
                          <td className="text-center py-3"><i className="ri-close-line text-shopify-error"></i></td>
                          <td className="text-center py-3"><i className="ri-check-line text-shopify-success"></i></td>
                        </tr>
                        <tr className="border-b">
                          <td className="py-3">Advanced Analytics</td>
                          <td className="text-center py-3"><i className="ri-close-line text-shopify-error"></i></td>
                          <td className="text-center py-3"><i className="ri-check-line text-shopify-success"></i></td>
                        </tr>
                        <tr className="border-b">
                          <td className="py-3">Priority Support</td>
                          <td className="text-center py-3"><i className="ri-close-line text-shopify-error"></i></td>
                          <td className="text-center py-3"><i className="ri-check-line text-shopify-success"></i></td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div>
                
                <div className="mt-6">
                  <Button 
                    className={`w-full ${user?.isPremium ? 'bg-shopify-error hover:bg-shopify-error' : 'bg-shopify-green hover:bg-shopify-green'}`}
                    onClick={togglePremium}
                  >
                    {user?.isPremium ? "Cancel Premium Subscription" : "Upgrade to Premium"}
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="api">
            <Card>
              <CardHeader>
                <CardTitle>API Configuration</CardTitle>
                <CardDescription>
                  Manage API settings and authentication
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-2">
                  <Label htmlFor="apiKey">Shopify API Key</Label>
                  <div className="flex">
                    <Input 
                      id="apiKey" 
                      value={apiKey}
                      onChange={(e) => setApiKey(e.target.value)}
                      placeholder={user?.apiKey ? "••••••••••••••••" : "Enter your Shopify API key"}
                      className="flex-1 rounded-r-none"
                    />
                    <Button 
                      onClick={saveApiKey} 
                      className="rounded-l-none"
                      disabled={updateUserMutation.isPending}
                    >
                      Save Key
                    </Button>
                  </div>
                  <p className="text-xs text-shopify-text-secondary">
                    {user?.apiKey 
                      ? "API key is set. Enter a new one to update."
                      : "API key is required to connect with your Shopify store."}
                  </p>
                </div>
                
                <div className="p-4 bg-yellow-50 border border-yellow-200 rounded-md">
                  <h4 className="text-base font-medium text-shopify-text flex items-center mb-2">
                    <i className="ri-information-line text-shopify-gold mr-2"></i>
                    API Instructions
                  </h4>
                  <p className="text-sm text-shopify-text-secondary mb-3">
                    Follow these steps to get your Shopify API key:
                  </p>
                  <ol className="list-decimal list-inside text-sm text-shopify-text-secondary space-y-1">
                    <li>Go to your Shopify Admin Panel</li>
                    <li>Navigate to Apps &gt; App and Sales Channel Settings</li>
                    <li>Click "Develop apps for your store"</li>
                    <li>Create a new app and copy the API key</li>
                    <li>Paste the API key here and save</li>
                  </ol>
                </div>
                
                <div className="space-y-2">
                  <Label>Webhooks</Label>
                  <div className="p-4 border rounded-md">
                    <p className="text-sm mb-3">Configure the following webhook endpoints in your Shopify Admin:</p>
                    <div className="space-y-2">
                      <div className="p-2 bg-gray-50 rounded border text-sm font-mono">
                        https://your-app-url.com/api/webhooks/orders/create
                      </div>
                      <div className="p-2 bg-gray-50 rounded border text-sm font-mono">
                        https://your-app-url.com/api/webhooks/app/uninstalled
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default Settings;
