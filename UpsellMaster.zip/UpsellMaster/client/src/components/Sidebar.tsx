import { useLocation, Link } from "wouter";
import { cn } from "@/lib/utils";
import { UPSELL_TYPES } from "@/lib/constants";
import { useQuery } from "@tanstack/react-query";

const Sidebar = () => {
  const [location] = useLocation();
  
  const { data: user } = useQuery({
    queryKey: ['/api/user'],
  });

  return (
    <div className="hidden md:flex md:flex-shrink-0">
      <div className="flex flex-col w-64 border-r border-gray-200 bg-white">
        <div className="flex items-center h-16 px-4 border-b border-gray-200">
          <div className="flex items-center space-x-2">
            <i className="ri-shopping-bag-3-line text-shopify-green text-xl"></i>
            <span className="text-lg font-semibold">Upsell Master</span>
          </div>
        </div>
        <nav className="flex-1 px-2 py-4 space-y-1">
          <Link href="/">
            <a className={cn(
              "flex items-center px-3 py-2 text-sm font-medium rounded-md",
              location === "/" 
                ? "bg-shopify-green text-white" 
                : "text-shopify-text hover:bg-gray-100"
            )}>
              <i className="ri-dashboard-line mr-3 text-lg"></i>
              Dashboard
            </a>
          </Link>
          <Link href="/settings">
            <a className={cn(
              "flex items-center px-3 py-2 text-sm font-medium rounded-md",
              location === "/settings" 
                ? "bg-shopify-green text-white" 
                : "text-shopify-text hover:bg-gray-100"
            )}>
              <i className="ri-settings-line mr-3 text-lg"></i>
              Settings
            </a>
          </Link>
          <Link href="/analytics">
            <a className={cn(
              "flex items-center px-3 py-2 text-sm font-medium rounded-md",
              location === "/analytics" 
                ? "bg-shopify-green text-white" 
                : "text-shopify-text hover:bg-gray-100"
            )}>
              <i className="ri-line-chart-line mr-3 text-lg"></i>
              Analytics
            </a>
          </Link>
          <div className="pt-4 mt-4 border-t border-gray-200">
            <h3 className="px-3 text-xs font-semibold text-shopify-text-secondary uppercase tracking-wider">
              Upsell Offers
            </h3>
            <div className="mt-2 space-y-1">
              {UPSELL_TYPES.map((type) => (
                <Link key={type.id} href={`/offers/new?type=${type.id}`}>
                  <a className={cn(
                    "flex items-center px-3 py-2 text-sm font-medium rounded-md",
                    location.startsWith(`/offers`) && location.includes(type.id)
                      ? "bg-shopify-green text-white" 
                      : type.isPremium && !user?.isPremium
                        ? "text-shopify-text-secondary hover:bg-gray-100"
                        : "text-shopify-text hover:bg-gray-100"
                  )}>
                    <i className={`ri-${type.icon} mr-3 text-lg`}></i>
                    {type.name}
                    {type.isPremium && !user?.isPremium && (
                      <span className="ml-auto inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-shopify-gold text-shopify-text">
                        Premium
                      </span>
                    )}
                  </a>
                </Link>
              ))}
            </div>
          </div>
        </nav>
        <div className="flex-shrink-0 p-4 border-t border-gray-200">
          <div className="flex items-center">
            <div className="flex-shrink-0">
              <div className="h-8 w-8 rounded-full bg-shopify-purple flex items-center justify-center text-white">
                <span className="text-sm font-medium">
                  {user?.shopName ? user.shopName.charAt(0) : "U"}
                </span>
              </div>
            </div>
            <div className="ml-3">
              <p className="text-sm font-medium">{user?.shopName || "Shop Name"}</p>
              <p className="text-xs text-shopify-text-secondary">
                {user?.isPremium ? "Premium Plan" : "Free Plan"}
              </p>
            </div>
            <div className="ml-auto">
              <button className="text-shopify-text-secondary hover:text-shopify-text">
                <i className="ri-logout-box-r-line"></i>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Sidebar;
