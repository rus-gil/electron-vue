import { useQuery } from "@tanstack/react-query";
import { formatCurrency } from "@/lib/utils";

const UsageSummary = () => {
  const { data: user } = useQuery({
    queryKey: ['/api/user'],
  });
  
  const { data: analytics } = useQuery({
    queryKey: ['/api/analytics'],
  });
  
  const totalRevenue = analytics?.reduce((sum, item) => sum + item.revenue, 0) || 0;
  const totalImpressions = analytics?.reduce((sum, item) => sum + item.impressions, 0) || 0;
  const totalClicks = analytics?.reduce((sum, item) => sum + item.clicks, 0) || 0;
  const conversionRate = totalClicks > 0 
    ? ((analytics?.reduce((sum, item) => sum + item.conversions, 0) || 0) / totalClicks) * 100 
    : 0;
  
  const usagePercentage = user?.monthlyOrders 
    ? Math.min(Math.round((user.monthlyOrders / 100) * 100), 100) 
    : 0;
  
  return (
    <div className="my-6 bg-white shadow rounded-lg overflow-hidden border border-gray-200">
      <div className="px-4 py-5 sm:p-6">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div>
            <h3 className="text-lg leading-6 font-medium text-shopify-text">Orders This Month</h3>
            <div className="mt-2 flex items-baseline">
              <p className="text-3xl font-semibold text-shopify-text">{user?.monthlyOrders || 0}</p>
              <p className="ml-2 text-sm text-shopify-text-secondary">
                / 100 <span className="text-xs">(Free Plan)</span>
              </p>
            </div>
            <div className="mt-1">
              <div className="relative pt-1">
                <div className="overflow-hidden h-2 text-xs flex rounded bg-gray-200">
                  <div 
                    style={{ width: `${usagePercentage}%` }} 
                    className="shadow-none flex flex-col text-center whitespace-nowrap text-white justify-center bg-shopify-green"
                  ></div>
                </div>
              </div>
            </div>
          </div>
          <div>
            <h3 className="text-lg leading-6 font-medium text-shopify-text">Upsell Revenue</h3>
            <div className="mt-2 flex items-baseline">
              <p className="text-3xl font-semibold text-shopify-text">{formatCurrency(totalRevenue)}</p>
              <span className="ml-2 text-sm text-shopify-success flex items-center">
                <i className="ri-arrow-up-line mr-1"></i>
                24.3%
              </span>
            </div>
            <p className="mt-1 text-sm text-shopify-text-secondary">Compared to last month</p>
          </div>
          <div>
            <h3 className="text-lg leading-6 font-medium text-shopify-text">Conversion Rate</h3>
            <div className="mt-2 flex items-baseline">
              <p className="text-3xl font-semibold text-shopify-text">{conversionRate.toFixed(1)}%</p>
              <span className="ml-2 text-sm text-shopify-success flex items-center">
                <i className="ri-arrow-up-line mr-1"></i>
                2.1%
              </span>
            </div>
            <p className="mt-1 text-sm text-shopify-text-secondary">Across all upsell offers</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default UsageSummary;
