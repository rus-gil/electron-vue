import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { formatCurrency } from "@/lib/utils";

// Mock product data for demo
const MOCK_PRODUCTS = [
  { id: "123", name: "Organic Cotton T-shirt", price: 2999, image: "" },
  { id: "456", name: "Premium Denim Jacket", price: 8999, image: "" },
  { id: "789", name: "Matching Wristband", price: 1499, image: "" },
  { id: "101", name: "Water Bottle", price: 1999, image: "" },
  { id: "102", name: "Eco-friendly Tote Bag", price: 1299, image: "" },
  { id: "103", name: "Beanie Hat", price: 2499, image: "" },
  { id: "104", name: "Sunglasses", price: 3499, image: "" },
  { id: "105", name: "Phone Case", price: 1799, image: "" },
];

interface ProductSelectorProps {
  products: any[];
  setProducts: (products: any[]) => void;
}

const ProductSelector = ({ products, setProducts }: ProductSelectorProps) => {
  const [dialogOpen, setDialogOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedProducts, setSelectedProducts] = useState<any[]>(products);
  
  const filteredProducts = MOCK_PRODUCTS.filter(product => 
    product.name.toLowerCase().includes(searchTerm.toLowerCase())
  );
  
  const handleAddProducts = () => {
    setProducts(selectedProducts);
    setDialogOpen(false);
  };
  
  const handleRemoveProduct = (productId: string) => {
    setProducts(products.filter(p => p.id !== productId));
    setSelectedProducts(selectedProducts.filter(p => p.id !== productId));
  };
  
  const toggleProductSelection = (product: any) => {
    const isSelected = selectedProducts.some(p => p.id === product.id);
    
    if (isSelected) {
      setSelectedProducts(selectedProducts.filter(p => p.id !== product.id));
    } else {
      setSelectedProducts([...selectedProducts, product]);
    }
  };
  
  return (
    <div>
      <div className="flex mb-3">
        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogTrigger asChild>
            <Button variant="outline">Select Products</Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[600px]">
            <DialogHeader>
              <DialogTitle>Select Products</DialogTitle>
            </DialogHeader>
            <div className="py-4">
              <Input
                placeholder="Search products..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="mb-4"
              />
              
              <div className="max-h-[300px] overflow-y-auto border rounded-md">
                {filteredProducts.length === 0 ? (
                  <p className="p-4 text-center text-shopify-text-secondary">No products found</p>
                ) : (
                  <div className="divide-y">
                    {filteredProducts.map(product => {
                      const isSelected = selectedProducts.some(p => p.id === product.id);
                      
                      return (
                        <div 
                          key={product.id}
                          className={`flex items-center justify-between p-3 cursor-pointer ${isSelected ? 'bg-blue-50' : ''}`}
                          onClick={() => toggleProductSelection(product)}
                        >
                          <div className="flex items-center">
                            <div className="h-10 w-10 rounded border border-gray-200 bg-gray-100 flex items-center justify-center text-xs text-gray-500">
                              IMG
                            </div>
                            <div className="ml-3">
                              <p className="text-sm font-medium text-shopify-text">{product.name}</p>
                              <p className="text-xs text-shopify-text-secondary">{formatCurrency(product.price)}</p>
                            </div>
                          </div>
                          <div className="flex items-center">
                            <input
                              type="checkbox"
                              checked={isSelected}
                              onChange={() => {}}
                              className="h-4 w-4 text-shopify-green rounded focus:ring-shopify-green"
                              onClick={(e) => e.stopPropagation()}
                            />
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
              
              <div className="flex justify-between items-center mt-4">
                <p className="text-sm text-shopify-text-secondary">
                  {selectedProducts.length} product{selectedProducts.length !== 1 ? 's' : ''} selected
                </p>
                <div className="flex space-x-2">
                  <Button variant="outline" onClick={() => setDialogOpen(false)}>
                    Cancel
                  </Button>
                  <Button onClick={handleAddProducts}>
                    Add Products
                  </Button>
                </div>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>
      
      <div className="p-2 border border-gray-200 rounded-md bg-gray-50">
        {products.length === 0 ? (
          <p className="p-3 text-center text-shopify-text-secondary">No products selected</p>
        ) : (
          <div className="space-y-2">
            {products.map(product => (
              <div key={product.id} className="flex items-center justify-between p-2 bg-white rounded shadow-sm">
                <div className="flex items-center">
                  <div className="h-10 w-10 rounded border border-gray-200 bg-gray-100 flex items-center justify-center text-xs text-gray-500">
                    IMG
                  </div>
                  <div className="ml-3">
                    <p className="text-sm font-medium text-shopify-text">{product.name}</p>
                    <p className="text-xs text-shopify-text-secondary">{formatCurrency(product.price)}</p>
                  </div>
                </div>
                <button 
                  className="text-shopify-text-secondary hover:text-shopify-text"
                  onClick={() => handleRemoveProduct(product.id)}
                >
                  <i className="ri-delete-bin-line"></i>
                </button>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default ProductSelector;
