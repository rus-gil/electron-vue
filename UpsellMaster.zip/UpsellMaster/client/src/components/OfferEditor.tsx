import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { useToast } from "@/hooks/use-toast";
import { UPSELL_TYPES, DISCOUNT_TYPES, DISPLAY_MODES } from "@/lib/constants";
import { UpsellOffer } from "@/lib/upsellTypes";
import { isPremiumOffer } from "@/lib/utils";
import ProductSelector from "./ProductSelector";
import CodeEditor from "./CodeEditor";

interface OfferEditorProps {
  offerId?: string;
  defaultType?: string;
}

const formSchema = z.object({
  name: z.string().min(1, "Name is required"),
  type: z.string(),
  enabled: z.boolean().default(true),
  headline: z.string().min(1, "Headline is required"),
  description: z.string().min(1, "Description is required"),
  buttonText: z.string().min(1, "Button text is required"),
  declineText: z.string().min(1, "Decline text is required"),
  displayMode: z.string(),
  customCss: z.string().optional(),
  customJs: z.string().optional(),
  discountEnabled: z.boolean().default(false),
  discountType: z.string(),
  discountValue: z.number().min(0)
});

type FormValues = z.infer<typeof formSchema>;

const OfferEditor = ({ offerId, defaultType = "pre-purchase" }: OfferEditorProps) => {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [, navigate] = useLocation();
  const [activeTab, setActiveTab] = useState("general");
  const [triggerProducts, setTriggerProducts] = useState<any[]>([]);
  const [upsellProducts, setUpsellProducts] = useState<any[]>([]);
  
  const isEdit = !!offerId;
  const id = offerId ? parseInt(offerId) : undefined;
  
  // Get user to check premium status
  const { data: user } = useQuery({
    queryKey: ['/api/user'],
  });
  
  // Fetch offer data if editing
  const { data: offer, isLoading } = useQuery<UpsellOffer>({
    queryKey: [`/api/offers/${id}`],
    enabled: isEdit && !!id
  });
  
  // Set up form with either existing data or defaults
  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: "",
      type: defaultType,
      enabled: true,
      headline: "",
      description: "",
      buttonText: "Add to Cart",
      declineText: "No, thanks",
      displayMode: "all",
      customCss: "",
      customJs: "",
      discountEnabled: false,
      discountType: "percentage",
      discountValue: 0
    }
  });
  
  // Update form values when offer data is loaded
  useEffect(() => {
    if (offer) {
      form.reset({
        name: offer.name,
        type: offer.type,
        enabled: offer.enabled,
        headline: offer.headline,
        description: offer.description,
        buttonText: offer.buttonText,
        declineText: offer.declineText,
        displayMode: offer.displayMode,
        customCss: offer.customCss || "",
        customJs: offer.customJs || "",
        discountEnabled: offer.discountEnabled,
        discountType: offer.discountType,
        discountValue: offer.discountValue
      });
      setTriggerProducts(offer.triggerProducts || []);
      setUpsellProducts(offer.upsellProducts || []);
    }
  }, [offer, form]);
  
  // Update form values when defaultType changes
  useEffect(() => {
    if (!isEdit) {
      form.setValue("type", defaultType);
    }
  }, [defaultType, form, isEdit]);
  
  // Check if the selected offer type is a premium feature
  const selectedType = form.watch("type");
  const isPremiumType = isPremiumOffer(selectedType);
  const isPremiumUser = !!user?.isPremium;
  const isPremiumRestricted = isPremiumType && !isPremiumUser;
  
  // Save/update offer mutation
  const saveMutation = useMutation({
    mutationFn: async (data: FormValues) => {
      // Add products to the data
      const offerData = {
        ...data,
        triggerProducts,
        upsellProducts
      };
      
      if (isEdit && id) {
        return apiRequest("PATCH", `/api/offers/${id}`, offerData);
      } else {
        return apiRequest("POST", "/api/offers", offerData);
      }
    },
    onSuccess: () => {
      toast({
        title: `Offer ${isEdit ? "updated" : "created"} successfully`,
        description: "Your changes have been saved.",
        variant: "default"
      });
      queryClient.invalidateQueries({ queryKey: ['/api/offers'] });
      navigate("/");
    },
    onError: (error) => {
      toast({
        title: "Error saving offer",
        description: error.message || "Something went wrong. Please try again.",
        variant: "destructive"
      });
    }
  });
  
  const onSubmit = (data: FormValues) => {
    if (isPremiumRestricted) {
      toast({
        title: "Premium Feature",
        description: "Please upgrade to premium to use this offer type.",
        variant: "destructive"
      });
      return;
    }
    
    if (upsellProducts.length === 0) {
      toast({
        title: "Missing products",
        description: "Please add at least one upsell product.",
        variant: "destructive"
      });
      return;
    }
    
    saveMutation.mutate(data);
  };
  
  if (isLoading) {
    return (
      <div className="py-6">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 md:px-8">
          <h1 className="text-2xl font-semibold text-shopify-text">Loading offer details...</h1>
        </div>
      </div>
    );
  }
  
  const offerType = UPSELL_TYPES.find(type => type.id === selectedType);
  
  return (
    <div className="py-6">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 md:px-8">
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-2xl font-semibold text-shopify-text">
            {isEdit ? "Edit" : "Create"} {offerType?.name || "Upsell Offer"}
          </h1>
          <div className="flex space-x-3">
            <Button variant="outline" onClick={() => navigate("/")}>
              Cancel
            </Button>
            <Button 
              onClick={form.handleSubmit(onSubmit)} 
              disabled={saveMutation.isPending || isPremiumRestricted}
            >
              {saveMutation.isPending ? "Saving..." : "Save Offer"}
            </Button>
          </div>
        </div>
        
        {isPremiumRestricted && (
          <Alert className="mb-6 bg-shopify-gold bg-opacity-10 border-shopify-gold">
            <AlertDescription className="flex items-center">
              <i className="ri-vip-crown-line text-shopify-gold mr-2 text-lg"></i>
              <span>
                This is a premium feature. Please <a href="#" className="font-medium underline">upgrade to premium</a> to use this offer type.
              </span>
            </AlertDescription>
          </Alert>
        )}
        
        <Tabs defaultValue="general" value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="mb-6">
            <TabsTrigger value="general">General</TabsTrigger>
            <TabsTrigger value="products">Products</TabsTrigger>
            <TabsTrigger value="discount">Discount</TabsTrigger>
            <TabsTrigger value="appearance">Appearance</TabsTrigger>
            <TabsTrigger value="custom-code">Custom Code</TabsTrigger>
            <TabsTrigger value="preview">Preview</TabsTrigger>
          </TabsList>
          
          <TabsContent value="general">
            <Card>
              <CardContent className="pt-6">
                <div className="space-y-4">
                  <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
                    <div className="space-y-2">
                      <Label htmlFor="name">Offer Name</Label>
                      <Input 
                        id="name" 
                        {...form.register("name")} 
                        placeholder="e.g. Summer T-Shirt Bundle Offer" 
                      />
                      {form.formState.errors.name && (
                        <p className="text-sm text-shopify-error">{form.formState.errors.name.message}</p>
                      )}
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="type">Offer Type</Label>
                      <Select 
                        value={selectedType} 
                        onValueChange={value => form.setValue("type", value)}
                        disabled={isEdit} // Can't change type after creation
                      >
                        <SelectTrigger id="type">
                          <SelectValue placeholder="Select offer type" />
                        </SelectTrigger>
                        <SelectContent>
                          {UPSELL_TYPES.map(type => (
                            <SelectItem 
                              key={type.id} 
                              value={type.id}
                              disabled={type.isPremium && !isPremiumUser}
                            >
                              <div className="flex items-center">
                                <span>{type.name}</span>
                                {type.isPremium && !isPremiumUser && (
                                  <span className="ml-2 text-xs bg-shopify-gold text-shopify-text px-1 rounded">
                                    Premium
                                  </span>
                                )}
                              </div>
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <p className="text-xs text-shopify-text-secondary">{offerType?.description}</p>
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="headline">Offer Headline</Label>
                    <Input 
                      id="headline" 
                      {...form.register("headline")} 
                      placeholder="e.g. Complete Your Look!" 
                    />
                    {form.formState.errors.headline && (
                      <p className="text-sm text-shopify-error">{form.formState.errors.headline.message}</p>
                    )}
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="description">Offer Description</Label>
                    <Textarea 
                      id="description" 
                      {...form.register("description")} 
                      placeholder="e.g. Add this matching accessory to your order and save 15%!" 
                      rows={3}
                    />
                    {form.formState.errors.description && (
                      <p className="text-sm text-shopify-error">{form.formState.errors.description.message}</p>
                    )}
                  </div>
                  
                  <div className="flex items-center space-x-2">
                    <Switch 
                      id="enabled" 
                      checked={form.watch("enabled")} 
                      onCheckedChange={value => form.setValue("enabled", value)}
                    />
                    <Label htmlFor="enabled">Enable this offer</Label>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="products">
            <Card>
              <CardContent className="pt-6">
                <div className="space-y-6">
                  <div className="space-y-2">
                    <Label htmlFor="displayMode">Display Mode</Label>
                    <Select 
                      value={form.watch("displayMode")} 
                      onValueChange={value => form.setValue("displayMode", value)}
                    >
                      <SelectTrigger id="displayMode">
                        <SelectValue placeholder="Select display mode" />
                      </SelectTrigger>
                      <SelectContent>
                        {DISPLAY_MODES.map(mode => (
                          <SelectItem key={mode.value} value={mode.value}>
                            {mode.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  
                  {form.watch("displayMode") !== "all" && (
                    <div className="space-y-2">
                      <Label>Trigger Products</Label>
                      <p className="text-sm text-shopify-text-secondary mb-2">
                        These products will trigger the upsell offer when added to cart or viewed
                      </p>
                      <ProductSelector 
                        products={triggerProducts} 
                        setProducts={setTriggerProducts}
                      />
                    </div>
                  )}
                  
                  <div className="space-y-2">
                    <Label>Upsell Products</Label>
                    <p className="text-sm text-shopify-text-secondary mb-2">
                      These products will be offered as upsells
                    </p>
                    <ProductSelector 
                      products={upsellProducts} 
                      setProducts={setUpsellProducts}
                    />
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="discount">
            <Card>
              <CardContent className="pt-6">
                <div className="space-y-4">
                  <div className="flex items-center space-x-2">
                    <Switch 
                      id="discountEnabled" 
                      checked={form.watch("discountEnabled")} 
                      onCheckedChange={value => form.setValue("discountEnabled", value)}
                    />
                    <Label htmlFor="discountEnabled">Apply discount to upsell product</Label>
                  </div>
                  
                  {form.watch("discountEnabled") && (
                    <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
                      <div className="space-y-2">
                        <Label htmlFor="discountType">Discount Type</Label>
                        <Select 
                          value={form.watch("discountType")} 
                          onValueChange={value => form.setValue("discountType", value)}
                        >
                          <SelectTrigger id="discountType">
                            <SelectValue placeholder="Select discount type" />
                          </SelectTrigger>
                          <SelectContent>
                            {DISCOUNT_TYPES.map(type => (
                              <SelectItem key={type.value} value={type.value}>
                                {type.label}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      
                      <div className="space-y-2">
                        <Label htmlFor="discountValue">
                          Discount Value 
                          {form.watch("discountType") === "percentage" ? " (%)" : " ($)"}
                        </Label>
                        <Input 
                          id="discountValue" 
                          type="number"
                          min="0"
                          step={form.watch("discountType") === "percentage" ? "1" : "0.01"}
                          {...form.register("discountValue", { 
                            valueAsNumber: true 
                          })} 
                        />
                      </div>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="appearance">
            <Card>
              <CardContent className="pt-6">
                <div className="space-y-4">
                  <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
                    <div className="space-y-2">
                      <Label htmlFor="buttonText">Accept Button Text</Label>
                      <Input 
                        id="buttonText" 
                        {...form.register("buttonText")} 
                        placeholder="e.g. Yes, Add This Item" 
                      />
                      {form.formState.errors.buttonText && (
                        <p className="text-sm text-shopify-error">{form.formState.errors.buttonText.message}</p>
                      )}
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor="declineText">Decline Button Text</Label>
                      <Input 
                        id="declineText" 
                        {...form.register("declineText")} 
                        placeholder="e.g. No, Thanks" 
                      />
                      {form.formState.errors.declineText && (
                        <p className="text-sm text-shopify-error">{form.formState.errors.declineText.message}</p>
                      )}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="custom-code">
            <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
              <Card>
                <CardContent className="pt-6">
                  <div className="space-y-2">
                    <Label htmlFor="customCss">Custom CSS</Label>
                    <p className="text-xs text-shopify-text-secondary">
                      Add custom CSS to style your upsell offer
                    </p>
                    <CodeEditor
                      value={form.watch("customCss") || ""}
                      onChange={value => form.setValue("customCss", value)}
                      language="css"
                      height="200px"
                    />
                  </div>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="pt-6">
                  <div className="space-y-2">
                    <Label htmlFor="customJs">Custom JavaScript</Label>
                    <p className="text-xs text-shopify-text-secondary">
                      Add custom JavaScript to enhance your upsell offer
                    </p>
                    <CodeEditor
                      value={form.watch("customJs") || ""}
                      onChange={value => form.setValue("customJs", value)}
                      language="javascript"
                      height="200px"
                    />
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
          
          <TabsContent value="preview">
            <Card>
              <CardContent className="pt-6">
                <h3 className="text-lg font-medium text-shopify-text mb-4">Offer Preview</h3>
                <div className="border border-gray-200 rounded-lg p-4 bg-gray-50">
                  <div className="bg-white rounded-lg shadow-md p-4 border border-gray-200">
                    <div className="mb-3">
                      <h5 className="text-lg font-semibold text-shopify-text">
                        {form.watch("headline") || "Complete Your Look!"}
                      </h5>
                      <p className="text-sm text-shopify-text-secondary mt-1">
                        {form.watch("description") || "Add this matching accessory to your order and save 15%!"}
                      </p>
                    </div>
                    <div className="flex items-center py-3 border-t border-b border-gray-200">
                      <div className="flex-shrink-0 h-16 w-16 bg-gray-100 rounded-md flex items-center justify-center">
                        <span className="text-xs text-gray-500">Product<br/>Image</span>
                      </div>
                      <div className="ml-3 flex-1">
                        <h6 className="text-sm font-medium text-shopify-text">
                          {upsellProducts.length > 0 ? upsellProducts[0].name : "Product Name"}
                        </h6>
                        <div className="flex items-center mt-1">
                          {form.watch("discountEnabled") && (
                            <>
                              <span className="text-xs line-through text-shopify-text-secondary">
                                {upsellProducts.length > 0 
                                  ? `$${(upsellProducts[0].price / 100).toFixed(2)}` 
                                  : "$14.99"}
                              </span>
                              <span className="ml-2 text-sm font-medium text-shopify-green">
                                {upsellProducts.length > 0 && form.watch("discountEnabled")
                                  ? form.watch("discountType") === "percentage"
                                    ? `$${((upsellProducts[0].price * (100 - form.watch("discountValue")) / 100) / 100).toFixed(2)}`
                                    : `$${((upsellProducts[0].price - form.watch("discountValue") * 100) / 100).toFixed(2)}`
                                  : "$12.74"}
                              </span>
                              <span className="ml-2 text-xs text-white bg-shopify-green rounded px-1.5 py-0.5">
                                {form.watch("discountType") === "percentage"
                                  ? `Save ${form.watch("discountValue")}%`
                                  : `Save $${form.watch("discountValue")}`}
                              </span>
                            </>
                          )}
                          {!form.watch("discountEnabled") && (
                            <span className="text-sm font-medium text-shopify-text">
                              {upsellProducts.length > 0 
                                ? `$${(upsellProducts[0].price / 100).toFixed(2)}` 
                                : "$14.99"}
                            </span>
                          )}
                        </div>
                      </div>
                    </div>
                    <div className="mt-4 flex space-x-3">
                      <Button className="flex-1 bg-shopify-green text-white py-2 px-4 rounded-md text-sm font-medium">
                        {form.watch("buttonText") || "Yes, Add This Item"}
                      </Button>
                      <Button variant="outline" className="flex-shrink-0 border border-gray-300 text-shopify-text-secondary py-2 px-4 rounded-md text-sm">
                        {form.watch("declineText") || "No, Thanks"}
                      </Button>
                    </div>
                  </div>
                </div>
                
                <div className="mt-6">
                  <p className="text-sm text-shopify-text-secondary">
                    This is a preview of how your upsell offer will look. The actual appearance may 
                    vary slightly depending on your store's theme and any custom CSS you've added.
                  </p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default OfferEditor;
