import { useState } from "react";
import { useLocation } from "wouter";
import { Switch } from "@/components/ui/switch";
import { Button } from "@/components/ui/button";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { UPSELL_TYPES } from "@/lib/constants";
import { isPremiumOffer, calculateConversionRate } from "@/lib/utils";
import { Analytics, UpsellOffer } from "@/lib/upsellTypes";

interface UpsellOfferCardProps {
  offer: UpsellOffer;
  analytics: Partial<Analytics>;
  isPremiumUser: boolean;
  isPlaceholder?: boolean;
}

const UpsellOfferCard = ({ 
  offer, 
  analytics, 
  isPremiumUser, 
  isPlaceholder = false 
}: UpsellOfferCardProps) => {
  const [, navigate] = useLocation();
  const queryClient = useQueryClient();
  
  const isPremium = isPremiumOffer(offer.type);
  const isLocked = isPremium && !isPremiumUser;
  
  // Get the type configuration
  const typeConfig = UPSELL_TYPES.find(t => t.id === offer.type) || {
    icon: 'shopping-cart-line',
    bgColorClass: 'bg-shopify-text-secondary',
    textColorClass: 'text-shopify-text-secondary'
  };
  
  const toggleMutation = useMutation({
    mutationFn: async () => {
      if (isLocked || isPlaceholder) return;
      return apiRequest("PATCH", `/api/offers/${offer.id}`, { enabled: !offer.enabled });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/offers'] });
    }
  });
  
  const handleToggle = () => {
    if (!isLocked && !isPlaceholder) {
      toggleMutation.mutate();
    }
  };
  
  const handleEditClick = () => {
    if (isPlaceholder) {
      navigate(`/offers/new?type=${offer.type}`);
    } else if (!isLocked) {
      navigate(`/offers/${offer.id}`);
    }
  };
  
  return (
    <div className="bg-white shadow rounded-lg overflow-hidden border border-gray-200 relative">
      {/* Premium overlay for locked features */}
      {isLocked && (
        <div className="absolute inset-0 bg-gray-100 bg-opacity-50 backdrop-filter backdrop-blur-sm flex items-center justify-center z-10">
          <div className="bg-white rounded-lg shadow-lg p-4 text-center">
            <span className="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-shopify-gold text-shopify-text mb-3">
              <i className="ri-vip-crown-line mr-1"></i>
              Premium Feature
            </span>
            <h4 className="font-medium text-shopify-text mb-2">{offer.name}</h4>
            <p className="text-shopify-text-secondary text-sm mb-3">
              Unlock this feature by upgrading to Premium
            </p>
            <button className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-shopify-green hover:bg-shopify-green focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-shopify-green">
              Upgrade Now
            </button>
          </div>
        </div>
      )}
      
      <div className="px-4 py-5 sm:p-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center">
            <div className={`flex-shrink-0 ${typeConfig.bgColorClass} bg-opacity-10 rounded-md p-3`}>
              <i className={`ri-${typeConfig.icon} text-xl ${typeConfig.textColorClass}`}></i>
            </div>
            <div className="ml-4">
              <h3 className="text-lg font-medium text-shopify-text">{offer.name}</h3>
              <p className="text-sm text-shopify-text-secondary">{offer.description}</p>
            </div>
          </div>
          <div className="flex items-center">
            <Switch
              checked={offer.enabled}
              onCheckedChange={handleToggle}
              className={`mr-3 ${isLocked || isPlaceholder ? 'opacity-50 cursor-not-allowed' : ''}`}
              disabled={isLocked || isPlaceholder || toggleMutation.isPending}
              aria-label="Toggle offer"
            />
            <button 
              onClick={handleEditClick}
              className={`text-shopify-text-secondary hover:text-shopify-text ${isLocked ? 'cursor-not-allowed opacity-50' : ''}`}
              disabled={isLocked}
              aria-label="Edit offer"
            >
              <i className="ri-settings-3-line text-xl"></i>
            </button>
          </div>
        </div>
        <div className="mt-6 grid grid-cols-3 gap-4">
          <div className="border rounded-md p-3 text-center">
            <p className="text-xs text-shopify-text-secondary">Impressions</p>
            <p className={`text-lg font-semibold ${isPlaceholder || isLocked ? 'text-shopify-text-secondary' : 'text-shopify-text'} mt-1`}>
              {isPlaceholder || isLocked ? (isLocked ? '--' : '0') : analytics.impressions || 0}
            </p>
          </div>
          <div className="border rounded-md p-3 text-center">
            <p className="text-xs text-shopify-text-secondary">Clicks</p>
            <p className={`text-lg font-semibold ${isPlaceholder || isLocked ? 'text-shopify-text-secondary' : 'text-shopify-text'} mt-1`}>
              {isPlaceholder || isLocked ? (isLocked ? '--' : '0') : analytics.clicks || 0}
            </p>
          </div>
          <div className="border rounded-md p-3 text-center">
            <p className="text-xs text-shopify-text-secondary">Conversion</p>
            <p className={`text-lg font-semibold ${isPlaceholder || isLocked ? 'text-shopify-text-secondary' : 'text-shopify-text'} mt-1`}>
              {isPlaceholder || isLocked 
                ? (isLocked ? '--%' : '0.0%') 
                : calculateConversionRate(analytics.clicks || 0, analytics.conversions || 0)}
            </p>
          </div>
        </div>
        <div className="mt-6">
          <Button
            variant="outline"
            className="w-full flex justify-center py-2 px-4"
            onClick={handleEditClick}
            disabled={isLocked}
          >
            <i className={`ri-${isPlaceholder ? 'add-line' : 'edit-line'} mr-2`}></i>
            {isPlaceholder ? 'Setup Offer' : 'Edit Offer'}
          </Button>
        </div>
      </div>
    </div>
  );
};

export default UpsellOfferCard;
