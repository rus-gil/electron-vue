import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import UpsellOfferCard from "./UpsellOfferCard";
import { UpsellOffer } from "@/lib/upsellTypes";
import { UPSELL_TYPES } from "@/lib/constants";
import { isPremiumOffer } from "@/lib/utils";

const UpsellOffersGrid = () => {
  const { data: offers = [] } = useQuery<UpsellOffer[]>({
    queryKey: ['/api/offers'],
  });
  
  const { data: user } = useQuery({
    queryKey: ['/api/user'],
  });
  
  const { data: analytics = [] } = useQuery({
    queryKey: ['/api/analytics'],
  });
  
  // Group analytics by offerId for easier access
  const analyticsByOfferId = analytics.reduce((acc, item) => {
    acc[item.offerId] = item;
    return acc;
  }, {} as Record<number, typeof analytics[0]>);
  
  // For creating new offers, ensure we have all offer types in the grid
  const upsellTypeIds = UPSELL_TYPES.map(type => type.id);
  const existingOfferTypes = offers.map(offer => offer.type);
  
  // Add placeholder offers for types that don't exist yet
  const missingTypes = upsellTypeIds.filter(type => !existingOfferTypes.includes(type as UpsellOffer['type']));
  
  return (
    <div className="mb-6">
      <h2 className="text-lg font-medium text-shopify-text mb-4">Upsell Offers</h2>
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        {/* Existing offers */}
        {offers.map(offer => {
          const offerAnalytics = analyticsByOfferId[offer.id] || {
            impressions: 0,
            clicks: 0,
            conversions: 0
          };
          
          return (
            <UpsellOfferCard
              key={offer.id}
              offer={offer}
              analytics={offerAnalytics}
              isPremiumUser={!!user?.isPremium}
            />
          );
        })}
        
        {/* Placeholder offers for types that don't exist yet */}
        {missingTypes.map(type => {
          const typeConfig = UPSELL_TYPES.find(t => t.id === type);
          if (!typeConfig) return null;
          
          const isPremiumType = isPremiumOffer(type);
          const placeholderOffer = {
            id: -1,
            type: type as UpsellOffer['type'],
            name: typeConfig.name,
            enabled: false,
            description: typeConfig.description,
            icon: typeConfig.icon,
            bgColorClass: typeConfig.bgColorClass,
            textColorClass: typeConfig.textColorClass
          };
          
          return (
            <UpsellOfferCard
              key={type}
              offer={placeholderOffer as any}
              analytics={{ impressions: 0, clicks: 0, conversions: 0 }}
              isPremiumUser={!!user?.isPremium}
              isPlaceholder={true}
            />
          );
        })}
      </div>
    </div>
  );
};

export default UpsellOffersGrid;
