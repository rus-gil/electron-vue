import { useEffect, useRef } from 'react';

interface CodeEditorProps {
  value: string;
  onChange: (value: string) => void;
  language: string;
  height?: string;
}

const CodeEditor = ({ value, onChange, language, height = '200px' }: CodeEditorProps) => {
  const editorRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    // In a real implementation, this would use a proper code editor like CodeMirror
    if (editorRef.current) {
      editorRef.current.value = value;
    }
  }, [value]);

  return (
    <textarea
      ref={editorRef}
      className="w-full p-3 font-mono text-sm border border-gray-300 rounded-md focus:ring-shopify-purple focus:border-shopify-purple"
      style={{ 
        height, 
        resize: 'vertical',
        tabSize: 2,
        lineHeight: 1.5,
      }}
      value={value}
      onChange={(e) => onChange(e.target.value)}
      spellCheck="false"
      data-language={language}
      placeholder={language === 'css' 
        ? `.upsell-popup {\n  background: #f8f9fa;\n  border-radius: 8px;\n}` 
        : `document.addEventListener('DOMContentLoaded', function() {\n  // Your custom code here\n});`
      }
    />
  );
};

export default CodeEditor;
