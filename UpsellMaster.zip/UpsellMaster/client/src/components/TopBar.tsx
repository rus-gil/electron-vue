import { useState } from "react";
import { useQuery } from "@tanstack/react-query";

const TopBar = () => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  
  const { data: user } = useQuery({
    queryKey: ['/api/user'],
  });

  return (
    <div className="relative z-10 flex-shrink-0 flex h-16 bg-white border-b border-gray-200">
      <button 
        className="md:hidden px-4 border-r border-gray-200 text-gray-500 focus:outline-none focus:bg-gray-100"
        onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
      >
        <i className="ri-menu-line text-xl"></i>
      </button>
      <div className="flex-1 px-4 flex justify-between">
        <div className="flex-1 flex items-center">
          <div className="max-w-lg w-full lg:max-w-xs">
            <label htmlFor="search" className="sr-only">Search</label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <i className="ri-search-line text-shopify-text-secondary"></i>
              </div>
              <input 
                id="search" 
                className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md leading-5 bg-white placeholder-shopify-text-secondary focus:outline-none focus:placeholder-gray-400 focus:border-shopify-purple focus:ring-1 focus:ring-shopify-purple sm:text-sm" 
                placeholder="Search" 
                type="search"
              />
            </div>
          </div>
        </div>
        <div className="ml-4 flex items-center md:ml-6">
          <button className="p-1 rounded-full text-shopify-text-secondary hover:text-shopify-text focus:outline-none">
            <i className="ri-notification-3-line text-xl"></i>
          </button>
          <button className="ml-3 p-1 rounded-full text-shopify-text-secondary hover:text-shopify-text focus:outline-none">
            <i className="ri-question-line text-xl"></i>
          </button>
          {/* Profile dropdown */}
          <div className="ml-3 relative">
            <div>
              <button className="max-w-xs flex items-center text-sm rounded-full focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-shopify-purple">
                <div className="h-8 w-8 rounded-full bg-shopify-purple flex items-center justify-center text-white">
                  <span className="text-sm font-medium">
                    {user?.shopName ? user.shopName.charAt(0) : "U"}
                  </span>
                </div>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TopBar;
