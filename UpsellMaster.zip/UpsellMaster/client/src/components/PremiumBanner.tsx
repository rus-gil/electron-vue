import { PREMIUM_FEATURES } from "@/lib/constants";

const PremiumBanner = () => {
  return (
    <div className="bg-shopify-gold bg-opacity-10 rounded-lg overflow-hidden mb-6">
      <div className="px-4 py-5 sm:p-6">
        <div className="flex flex-col md:flex-row">
          <div className="flex-1">
            <div className="flex items-center">
              <i className="ri-vip-crown-line text-shopify-gold text-2xl"></i>
              <h3 className="ml-2 text-lg font-medium text-shopify-text">Upgrade to Premium</h3>
            </div>
            <p className="mt-2 text-sm text-shopify-text-secondary">
              Unlock advanced features and remove the monthly order limit.
            </p>
            <ul className="mt-4 space-y-2">
              {PREMIUM_FEATURES.map((feature, index) => (
                <li key={index} className="flex items-center text-sm text-shopify-text">
                  <i className="ri-check-line text-shopify-success mr-2"></i>
                  {feature}
                </li>
              ))}
            </ul>
          </div>
          <div className="mt-6 md:mt-0 md:ml-6 flex items-center">
            <button className="w-full inline-flex items-center justify-center px-4 py-2 border border-transparent text-base font-medium rounded-md shadow-sm text-white bg-shopify-green hover:bg-shopify-green focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-shopify-green">
              Upgrade Now
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PremiumBanner;
