import { useQuery } from "@tanstack/react-query";
import { formatCurrency, timeAgo } from "@/lib/utils";
import { ActivityLog } from "@/lib/upsellTypes";

const RecentActivity = () => {
  const { data: activities = [] } = useQuery<ActivityLog[]>({
    queryKey: ['/api/activity'],
  });
  
  if (activities.length === 0) {
    return (
      <div className="bg-white shadow rounded-lg overflow-hidden border border-gray-200 mb-6">
        <div className="px-4 py-5 sm:px-6 flex justify-between items-center">
          <h3 className="text-lg leading-6 font-medium text-shopify-text">Recent Activity</h3>
        </div>
        <div className="border-t border-gray-200 p-6 text-center">
          <p className="text-shopify-text-secondary">No recent activity.</p>
        </div>
      </div>
    );
  }
  
  return (
    <div className="bg-white shadow rounded-lg overflow-hidden border border-gray-200 mb-6">
      <div className="px-4 py-5 sm:px-6 flex justify-between items-center">
        <h3 className="text-lg leading-6 font-medium text-shopify-text">Recent Activity</h3>
        <button className="text-sm text-shopify-purple flex items-center">
          View all
          <i className="ri-arrow-right-line ml-1"></i>
        </button>
      </div>
      <div className="border-t border-gray-200 divide-y divide-gray-200">
        {activities.map((activity) => {
          let iconClass = "";
          let iconBgClass = "";
          let title = "";
          
          switch (activity.action) {
            case "conversion":
              iconClass = activity.offerId === 1 
                ? "ri-shopping-cart-2-line text-shopify-green" 
                : "ri-shopping-bag-line text-shopify-purple";
              iconBgClass = activity.offerId === 1 
                ? "bg-shopify-green bg-opacity-10" 
                : "bg-shopify-purple bg-opacity-10";
              title = activity.offerId === 1 
                ? "Pre-purchase offer accepted" 
                : "Product page offer accepted";
              break;
            case "decline":
              iconClass = "ri-close-circle-line text-shopify-text-secondary";
              iconBgClass = "bg-shopify-text-secondary bg-opacity-10";
              title = "Offer declined";
              break;
            case "impression":
              iconClass = "ri-eye-line text-shopify-text-secondary";
              iconBgClass = "bg-shopify-text-secondary bg-opacity-10";
              title = "Offer viewed";
              break;
            case "click":
              iconClass = "ri-cursor-line text-shopify-text-secondary";
              iconBgClass = "bg-shopify-text-secondary bg-opacity-10";
              title = "Offer clicked";
              break;
          }
          
          return (
            <div key={activity.id} className="px-4 py-4 sm:px-6">
              <div className="flex items-center">
                <div className={`flex-shrink-0 h-10 w-10 rounded-full ${iconBgClass} flex items-center justify-center`}>
                  <i className={iconClass}></i>
                </div>
                <div className="ml-4 flex-1">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-shopify-text">{title}</p>
                      <p className="text-sm text-shopify-text-secondary">
                        {activity.productName ? `Customer ${activity.action === "conversion" ? "added" : "declined"} "${activity.productName}"` : "Customer interaction"}
                      </p>
                    </div>
                    <div className="ml-2 flex-shrink-0 flex">
                      <p className="text-sm text-shopify-text-secondary">
                        {timeAgo(new Date(activity.createdAt))}
                      </p>
                    </div>
                  </div>
                  {activity.amount > 0 && (
                    <div className="mt-2 text-sm">
                      <span className="px-2 py-1 text-xs rounded-full bg-shopify-success bg-opacity-10 text-shopify-success">
                        +{formatCurrency(activity.amount)}
                      </span>
                    </div>
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default RecentActivity;
