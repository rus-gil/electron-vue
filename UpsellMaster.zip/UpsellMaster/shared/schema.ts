import { pgTable, text, serial, integer, boolean, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// User model
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  shopName: text("shop_name"),
  isPremium: boolean("is_premium").default(false),
  apiKey: text("api_key"),
  monthlyOrders: integer("monthly_orders").default(0),
  createdAt: timestamp("created_at").defaultNow(),
});

// Upsell offer model
export const upsellOffers = pgTable("upsell_offers", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  name: text("name").notNull(),
  type: text("type").notNull(), // pre-purchase, product-page, cart-drawer, checkout, post-purchase
  enabled: boolean("enabled").default(true),
  headline: text("headline"),
  description: text("description"),
  buttonText: text("button_text").default("Add to Cart"),
  declineText: text("decline_text").default("No, thanks"),
  displayMode: text("display_mode").default("all"), // all, selected
  customCss: text("custom_css"),
  customJs: text("custom_js"),
  triggerProducts: jsonb("trigger_products"), // array of product ids or collections
  upsellProducts: jsonb("upsell_products"), // array of product ids or collections
  discountEnabled: boolean("discount_enabled").default(false),
  discountType: text("discount_type").default("percentage"), // percentage, fixed
  discountValue: integer("discount_value").default(0),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Analytics model
export const analytics = pgTable("analytics", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  offerId: integer("offer_id").notNull(),
  impressions: integer("impressions").default(0),
  clicks: integer("clicks").default(0),
  conversions: integer("conversions").default(0),
  revenue: integer("revenue").default(0), // Stored in cents
  date: timestamp("date").defaultNow(),
});

// Activity log model
export const activityLogs = pgTable("activity_logs", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  offerId: integer("offer_id"),
  action: text("action").notNull(), // impression, click, conversion, decline
  productId: text("product_id"),
  productName: text("product_name"),
  amount: integer("amount").default(0), // Stored in cents
  createdAt: timestamp("created_at").defaultNow(),
});

// Insert schemas
export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
});

export const insertUpsellOfferSchema = createInsertSchema(upsellOffers).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertAnalyticsSchema = createInsertSchema(analytics).omit({
  id: true,
  date: true,
});

export const insertActivityLogSchema = createInsertSchema(activityLogs).omit({
  id: true,
  createdAt: true,
});

// Types
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertUpsellOffer = z.infer<typeof insertUpsellOfferSchema>;
export type UpsellOffer = typeof upsellOffers.$inferSelect;

export type InsertAnalytics = z.infer<typeof insertAnalyticsSchema>;
export type Analytics = typeof analytics.$inferSelect;

export type InsertActivityLog = z.infer<typeof insertActivityLogSchema>;
export type ActivityLog = typeof activityLogs.$inferSelect;
