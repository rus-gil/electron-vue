import { users, type User, type InsertUser, offers, type Offer, type InsertOffer } from "@shared/schema";
import { format } from 'date-fns';

// Storage interface for CRUD operations
export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Offer methods
  getOffers(): Promise<Offer[]>;
  getOffer(id: number): Promise<Offer | undefined>;
  createOffer(offer: InsertOffer): Promise<Offer>;
  updateOffer(id: number, offer: Partial<InsertOffer>): Promise<Offer | undefined>;
  deleteOffer(id: number): Promise<boolean>;
  incrementConversion(id: number): Promise<boolean>;
  incrementDisplay(id: number): Promise<boolean>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private offerStore: Map<number, Offer>;
  private currentUserId: number;
  private currentOfferId: number;

  constructor() {
    this.users = new Map();
    this.offerStore = new Map();
    this.currentUserId = 1;
    this.currentOfferId = 1;
    
    // Add sample offers for development
    this.createOffer({
      name: "Summer Collection Upsell",
      triggerProduct: "Summer T-shirt",
      upsellProduct: "Beach Hat",
      title: "Complete your beach look!",
      description: "Add our bestselling beach hat to your order for just $19.99 (20% off)!",
      active: true,
      backgroundColor: "#ffffff",
      textColor: "#212b36",
      buttonColor: "#008060",
      buttonTextColor: "#ffffff",
      customCSS: "",
      customJS: "",
      displayCondition: "all",
      limitDisplays: false,
      skipCart: false,
    });
    
    this.createOffer({
      name: "Holiday Bundle",
      triggerProduct: "Winter Scarf",
      upsellProduct: "Gloves",
      title: "Complete your winter set!",
      description: "Add our matching gloves to your scarf for just $14.99 (30% off)!",
      active: false,
      backgroundColor: "#ffffff",
      textColor: "#212b36",
      buttonColor: "#008060",
      buttonTextColor: "#ffffff",
      customCSS: "",
      customJS: "",
      displayCondition: "all",
      limitDisplays: false,
      skipCart: false,
    });
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }
  
  // Offer methods
  async getOffers(): Promise<Offer[]> {
    return Array.from(this.offerStore.values());
  }
  
  async getOffer(id: number): Promise<Offer | undefined> {
    return this.offerStore.get(id);
  }
  
  async createOffer(insertOffer: InsertOffer): Promise<Offer> {
    const id = this.currentOfferId++;
    const now = new Date();
    const offer: Offer = { 
      ...insertOffer, 
      id, 
      createdAt: now,
      conversions: 0,
      displays: 0
    };
    this.offerStore.set(id, offer);
    return offer;
  }
  
  async updateOffer(id: number, offerUpdate: Partial<InsertOffer>): Promise<Offer | undefined> {
    const existingOffer = this.offerStore.get(id);
    if (!existingOffer) return undefined;
    
    const updatedOffer: Offer = {
      ...existingOffer,
      ...offerUpdate
    };
    
    this.offerStore.set(id, updatedOffer);
    return updatedOffer;
  }
  
  async deleteOffer(id: number): Promise<boolean> {
    return this.offerStore.delete(id);
  }
  
  async incrementConversion(id: number): Promise<boolean> {
    const offer = this.offerStore.get(id);
    if (!offer) return false;
    
    offer.conversions += 1;
    this.offerStore.set(id, offer);
    return true;
  }
  
  async incrementDisplay(id: number): Promise<boolean> {
    const offer = this.offerStore.get(id);
    if (!offer) return false;
    
    offer.displays += 1;
    this.offerStore.set(id, offer);
    return true;
  }
}

export const storage = new MemStorage();
