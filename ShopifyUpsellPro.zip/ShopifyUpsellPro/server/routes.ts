import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertOfferSchema } from "@shared/schema";
import { ZodError } from "zod";
import { fromZodError } from "zod-validation-error";

export async function registerRoutes(app: Express): Promise<Server> {
  // API routes
  
  // Get all offers
  app.get("/api/offers", async (req, res) => {
    try {
      const offers = await storage.getOffers();
      res.json(offers);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch offers" });
    }
  });
  
  // Get a single offer
  app.get("/api/offers/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid offer ID" });
      }
      
      const offer = await storage.getOffer(id);
      if (!offer) {
        return res.status(404).json({ message: "Offer not found" });
      }
      
      res.json(offer);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch offer" });
    }
  });
  
  // Create a new offer
  app.post("/api/offers", async (req, res) => {
    try {
      const offerData = insertOfferSchema.parse(req.body);
      const offer = await storage.createOffer(offerData);
      res.status(201).json(offer);
    } catch (error) {
      if (error instanceof ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ message: validationError.message });
      }
      res.status(500).json({ message: "Failed to create offer" });
    }
  });
  
  // Update an offer
  app.patch("/api/offers/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid offer ID" });
      }
      
      // Partial validation of the offer data
      const offerData = insertOfferSchema.partial().parse(req.body);
      
      const updatedOffer = await storage.updateOffer(id, offerData);
      if (!updatedOffer) {
        return res.status(404).json({ message: "Offer not found" });
      }
      
      res.json(updatedOffer);
    } catch (error) {
      if (error instanceof ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ message: validationError.message });
      }
      res.status(500).json({ message: "Failed to update offer" });
    }
  });
  
  // Delete an offer
  app.delete("/api/offers/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid offer ID" });
      }
      
      const success = await storage.deleteOffer(id);
      if (!success) {
        return res.status(404).json({ message: "Offer not found" });
      }
      
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ message: "Failed to delete offer" });
    }
  });
  
  // Track offer conversion
  app.post("/api/offers/:id/conversion", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid offer ID" });
      }
      
      const success = await storage.incrementConversion(id);
      if (!success) {
        return res.status(404).json({ message: "Offer not found" });
      }
      
      res.status(200).json({ success: true });
    } catch (error) {
      res.status(500).json({ message: "Failed to track conversion" });
    }
  });
  
  // Track offer display
  app.post("/api/offers/:id/display", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid offer ID" });
      }
      
      const success = await storage.incrementDisplay(id);
      if (!success) {
        return res.status(404).json({ message: "Offer not found" });
      }
      
      res.status(200).json({ success: true });
    } catch (error) {
      res.status(500).json({ message: "Failed to track display" });
    }
  });
  
  // Generate the Shopify script tag to be embedded in the store
  app.get("/api/script", (req, res) => {
    const scriptContent = `
    // Upsell Buddy Script
    (function() {
      // Base URL to the app's API
      const API_URL = "${process.env.APP_URL || req.protocol + '://' + req.get('host')}";
      
      // Find add to cart buttons
      const addToCartButtons = document.querySelectorAll('button[name="add"], input[name="add"], form[action*="/cart/add"] button, form[action*="/cart/add"] input[type="submit"]');
      
      // If no add to cart buttons, exit
      if (addToCartButtons.length === 0) return;
      
      // Create popup container
      const popupContainer = document.createElement('div');
      popupContainer.id = 'upsell-buddy-container';
      popupContainer.style.display = 'none';
      popupContainer.style.position = 'fixed';
      popupContainer.style.top = '0';
      popupContainer.style.left = '0';
      popupContainer.style.width = '100%';
      popupContainer.style.height = '100%';
      popupContainer.style.backgroundColor = 'rgba(0, 0, 0, 0.5)';
      popupContainer.style.zIndex = '9999';
      popupContainer.style.alignItems = 'center';
      popupContainer.style.justifyContent = 'center';
      document.body.appendChild(popupContainer);
      
      // Function to fetch offers based on product
      async function getOffers() {
        try {
          const response = await fetch(API_URL + '/api/offers');
          if (!response.ok) throw new Error('Network response was not ok');
          return await response.json();
        } catch (error) {
          console.error('Error fetching offers:', error);
          return [];
        }
      }
      
      // Function to check if current product matches trigger product
      function isMatch(offer, productTitle) {
        if (offer.triggerProduct === 'All Products') return true;
        return productTitle.toLowerCase().includes(offer.triggerProduct.toLowerCase());
      }
      
      // Function to track offer display
      async function trackDisplay(offerId) {
        try {
          await fetch(API_URL + '/api/offers/' + offerId + '/display', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' }
          });
        } catch (error) {
          console.error('Error tracking display:', error);
        }
      }
      
      // Function to track offer conversion
      async function trackConversion(offerId) {
        try {
          await fetch(API_URL + '/api/offers/' + offerId + '/conversion', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' }
          });
        } catch (error) {
          console.error('Error tracking conversion:', error);
        }
      }
      
      // Function to show offer popup
      function showOffer(offer, productTitle) {
        if (!offer.active) return;
        
        // Track display
        trackDisplay(offer.id);
        
        // Create popup HTML
        const popupHTML = \`
          <div class="upsell-popup" style="background-color: \${offer.backgroundColor}; color: \${offer.textColor}; max-width: 500px; margin: 0 auto; padding: 24px; border-radius: 8px; box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1);">
            <h3 style="font-size: 1.125rem; font-weight: 600; margin-bottom: 0.5rem;">\${offer.title}</h3>
            <div style="display: flex; align-items: center; margin-bottom: 1rem;">
              <div style="width: 80px; height: 80px; flex-shrink: 0; background-color: #f6f6f7; border-radius: 4px; overflow: hidden;"></div>
              <div style="margin-left: 1rem;">
                <h4 style="font-size: 1rem; font-weight: 500;">\${offer.upsellProduct}</h4>
              </div>
            </div>
            <p style="font-size: 0.875rem; margin-bottom: 1rem;">\${offer.description}</p>
            <div style="display: flex; gap: 1rem;">
              <button class="add-upsell-btn" style="flex: 1; background-color: \${offer.buttonColor}; color: \${offer.buttonTextColor}; border: none; border-radius: 4px; padding: 0.5rem 1rem; font-size: 0.875rem; font-weight: 500; cursor: pointer;">Add to Cart</button>
              <button class="decline-upsell-btn" style="flex: 1; background-color: transparent; color: #637381; border: 1px solid #e5e7eb; border-radius: 4px; padding: 0.5rem 1rem; font-size: 0.875rem; font-weight: 500; cursor: pointer;">No Thanks</button>
            </div>
          </div>
        \`;
        
        // Add custom CSS if provided
        if (offer.customCSS) {
          const customStyle = document.createElement('style');
          customStyle.textContent = offer.customCSS;
          document.head.appendChild(customStyle);
        }
        
        // Show popup
        popupContainer.innerHTML = popupHTML;
        popupContainer.style.display = 'flex';
        
        // Add event listeners
        const addBtn = popupContainer.querySelector('.add-upsell-btn');
        const declineBtn = popupContainer.querySelector('.decline-upsell-btn');
        
        addBtn.addEventListener('click', () => {
          // Track conversion
          trackConversion(offer.id);
          
          // Add product to cart
          const formData = {
            items: [{ id: 123, quantity: 1 }] // This would be the actual variant ID
          };
          
          fetch('/cart/add.js', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json'
            },
            body: JSON.stringify(formData)
          })
          .then(response => {
            popupContainer.style.display = 'none';
            if (offer.skipCart) {
              window.location.href = '/checkout';
            }
          })
          .catch(error => {
            console.error('Error adding product to cart:', error);
            popupContainer.style.display = 'none';
          });
        });
        
        declineBtn.addEventListener('click', () => {
          popupContainer.style.display = 'none';
        });
        
        // Execute custom JavaScript if provided
        if (offer.customJS) {
          try {
            eval(offer.customJS);
          } catch (error) {
            console.error('Error executing custom JavaScript:', error);
          }
        }
      }
      
      // Add click event listeners to all add to cart buttons
      addToCartButtons.forEach(button => {
        button.addEventListener('click', async function(e) {
          // Get product title
          const productTitle = document.querySelector('h1, .product-title, .product__title')?.textContent || '';
          
          // Get offers
          const offers = await getOffers();
          
          // Find matching offers
          const matchingOffers = offers.filter(offer => isMatch(offer, productTitle));
          
          // If matching offers found, show the first one
          if (matchingOffers.length > 0) {
            e.preventDefault(); // Prevent default add to cart behavior
            showOffer(matchingOffers[0], productTitle);
          }
        });
      });
    })();
    `;
    
    res.set('Content-Type', 'application/javascript');
    res.send(scriptContent);
  });

  const httpServer = createServer(app);
  return httpServer;
}
