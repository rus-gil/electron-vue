import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Offer, InsertOffer } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";

export function useOffers() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  // Fetch all offers
  const { data: offers = [], isLoading, error } = useQuery<Offer[]>({
    queryKey: ['/api/offers'],
  });

  // Create a new offer
  const createOffer = useMutation({
    mutationFn: async (offer: InsertOffer) => {
      const res = await apiRequest('POST', '/api/offers', offer);
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/offers'] });
      toast({
        title: "Success",
        description: "Offer created successfully",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: `Failed to create offer: ${error.message}`,
        variant: "destructive",
      });
    }
  });

  // Update an offer
  const updateOffer = useMutation({
    mutationFn: async ({ id, data }: { id: number, data: Partial<InsertOffer> }) => {
      const res = await apiRequest('PATCH', `/api/offers/${id}`, data);
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/offers'] });
      toast({
        title: "Success",
        description: "Offer updated successfully",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: `Failed to update offer: ${error.message}`,
        variant: "destructive",
      });
    }
  });

  // Delete an offer
  const deleteOffer = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest('DELETE', `/api/offers/${id}`);
      return id;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/offers'] });
      toast({
        title: "Success",
        description: "Offer deleted successfully",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: `Failed to delete offer: ${error.message}`,
        variant: "destructive",
      });
    }
  });

  return {
    offers,
    isLoading,
    error,
    createOffer,
    updateOffer,
    deleteOffer
  };
}
