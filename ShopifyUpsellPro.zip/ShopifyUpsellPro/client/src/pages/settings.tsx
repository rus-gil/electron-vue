import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Copy } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function Settings() {
  const { toast } = useToast();

  const handleCopyScript = () => {
    const scriptTag = `<script src="${window.location.origin}/api/script"></script>`;
    navigator.clipboard.writeText(scriptTag).then(() => {
      toast({
        title: "Copied!",
        description: "Script tag copied to clipboard",
      });
    });
  };
  
  return (
    <>
      <header className="bg-white border-b border-gray-200 px-6 py-4">
        <div className="flex justify-between items-center">
          <h1 className="text-xl font-semibold text-shopify-ink">Settings</h1>
        </div>
      </header>
      
      <div className="p-6">
        <Tabs defaultValue="installation" className="w-full">
          <TabsList className="grid w-full grid-cols-3 mb-6">
            <TabsTrigger value="installation">Installation</TabsTrigger>
            <TabsTrigger value="appearance">Appearance</TabsTrigger>
            <TabsTrigger value="notifications">Notifications</TabsTrigger>
          </TabsList>
          
          <TabsContent value="installation">
            <Card>
              <CardHeader>
                <CardTitle>Install Upsell Buddy</CardTitle>
                <CardDescription>
                  Add this script to your Shopify theme to enable pre-purchase upsells
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-2">
                  <Label htmlFor="script-tag">Script Tag</Label>
                  <div className="flex">
                    <Input 
                      id="script-tag" 
                      value={`<script src="${window.location.origin}/api/script"></script>`} 
                      readOnly 
                      className="font-mono text-sm rounded-r-none"
                    />
                    <Button 
                      onClick={handleCopyScript}
                      className="rounded-l-none"
                      variant="secondary"
                    >
                      <Copy className="h-4 w-4 mr-2" />
                      Copy
                    </Button>
                  </div>
                </div>
                
                <div className="space-y-2">
                  <h3 className="text-sm font-medium">Installation Instructions</h3>
                  <ol className="list-decimal list-inside space-y-2 text-sm">
                    <li>Go to your Shopify admin panel</li>
                    <li>Navigate to Online Store &gt; Themes</li>
                    <li>Click "Actions" and then "Edit code"</li>
                    <li>Find the theme.liquid file under Layout</li>
                    <li>Paste the script tag just before the closing &lt;/head&gt; tag</li>
                    <li>Save the changes</li>
                  </ol>
                </div>
                
                <div className="bg-yellow-50 border-l-4 border-yellow-400 p-4 rounded">
                  <div className="flex">
                    <div className="flex-shrink-0">
                      <svg className="h-5 w-5 text-yellow-400" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
                        <path fillRule="evenodd" d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
                      </svg>
                    </div>
                    <div className="ml-3">
                      <p className="text-sm text-yellow-700">
                        After installation, create and publish an offer to start showing upsells to your customers.
                      </p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="appearance">
            <Card>
              <CardHeader>
                <CardTitle>Default Appearance</CardTitle>
                <CardDescription>
                  Set default styles for your upsell popups
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-1 gap-6 sm:grid-cols-2">
                  <div className="space-y-2">
                    <Label htmlFor="background-color">Default Background Color</Label>
                    <div className="flex">
                      <span className="inline-flex items-center px-3 rounded-l-md border border-r-0 border-gray-300 bg-gray-50 text-gray-500 sm:text-sm">
                        #
                      </span>
                      <Input id="background-color" defaultValue="ffffff" className="rounded-l-none" />
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="text-color">Default Text Color</Label>
                    <div className="flex">
                      <span className="inline-flex items-center px-3 rounded-l-md border border-r-0 border-gray-300 bg-gray-50 text-gray-500 sm:text-sm">
                        #
                      </span>
                      <Input id="text-color" defaultValue="212b36" className="rounded-l-none" />
                    </div>
                  </div>
                </div>
                
                <div className="grid grid-cols-1 gap-6 sm:grid-cols-2">
                  <div className="space-y-2">
                    <Label htmlFor="button-color">Default Button Color</Label>
                    <div className="flex">
                      <span className="inline-flex items-center px-3 rounded-l-md border border-r-0 border-gray-300 bg-gray-50 text-gray-500 sm:text-sm">
                        #
                      </span>
                      <Input id="button-color" defaultValue="008060" className="rounded-l-none" />
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="button-text-color">Default Button Text Color</Label>
                    <div className="flex">
                      <span className="inline-flex items-center px-3 rounded-l-md border border-r-0 border-gray-300 bg-gray-50 text-gray-500 sm:text-sm">
                        #
                      </span>
                      <Input id="button-text-color" defaultValue="ffffff" className="rounded-l-none" />
                    </div>
                  </div>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="global-css">Global CSS</Label>
                  <Textarea 
                    id="global-css" 
                    placeholder=".upsell-popup {
  border-radius: 8px;
  box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1);
}"
                    rows={6}
                    className="font-mono"
                  />
                </div>
                
                <Button className="bg-shopify-green hover:bg-shopify-green/90">
                  Save Default Settings
                </Button>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="notifications">
            <Card>
              <CardHeader>
                <CardTitle>Notification Settings</CardTitle>
                <CardDescription>
                  Configure notification preferences for offer events
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label htmlFor="email-conversions">Email on conversions</Label>
                      <p className="text-sm text-shopify-text">Receive an email when a customer accepts an upsell offer</p>
                    </div>
                    <Switch id="email-conversions" />
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label htmlFor="email-summary">Weekly performance summary</Label>
                      <p className="text-sm text-shopify-text">Receive a weekly email with performance data for your offers</p>
                    </div>
                    <Switch id="email-summary" defaultChecked />
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div className="space-y-0.5">
                      <Label htmlFor="low-conversion">Low conversion alerts</Label>
                      <p className="text-sm text-shopify-text">Get notified when an offer's conversion rate drops below 5%</p>
                    </div>
                    <Switch id="low-conversion" defaultChecked />
                  </div>
                </div>
                
                <div className="space-y-2 pt-4">
                  <Label htmlFor="notification-email">Notification Email</Label>
                  <Input id="notification-email" type="email" placeholder="store@example.com" />
                </div>
                
                <Button className="bg-shopify-green hover:bg-shopify-green/90">
                  Save Notification Settings
                </Button>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </>
  );
}
