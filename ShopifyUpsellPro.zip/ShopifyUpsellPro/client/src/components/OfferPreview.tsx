import { Offer } from "@shared/schema";

interface OfferPreviewProps {
  offer: Partial<Offer>;
}

export default function OfferPreview({ offer }: OfferPreviewProps) {
  const {
    title = "Complete your beach look!",
    upsellProduct = "Beach Hat",
    description = "Add our bestselling beach hat to your order for just $19.99 (20% off)!",
    backgroundColor = "#ffffff",
    textColor = "#212b36",
    buttonColor = "#008060",
    buttonTextColor = "#ffffff"
  } = offer;

  return (
    <div className="max-w-md mx-auto">
      <div 
        style={{ 
          backgroundColor, 
          color: textColor,
          borderColor: 'rgba(0, 0, 0, 0.1)'
        }} 
        className="p-6 rounded-lg shadow-lg border"
      >
        <h3 className="text-lg font-semibold mb-2" style={{ color: textColor }}>{title}</h3>
        <div className="flex items-center mb-4">
          <div className="flex-shrink-0 h-20 w-20 bg-gray-200 rounded overflow-hidden">
            {/* Placeholder for product image */}
          </div>
          <div className="ml-4">
            <h4 className="text-md font-medium" style={{ color: textColor }}>{upsellProduct}</h4>
            <div className="flex items-center">
              <span className="text-md font-bold" style={{ color: '#008060' }}>$19.99</span>
              <span className="ml-2 text-sm line-through text-shopify-text">$24.99</span>
            </div>
            <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-red-100 text-red-800">
              Save 20%
            </span>
          </div>
        </div>
        <p className="text-sm mb-4" style={{ color: textColor }}>{description}</p>
        <div className="flex space-x-4">
          <button 
            type="button" 
            className="flex-1 rounded-md py-2 px-4 flex items-center justify-center text-sm font-medium focus:outline-none focus:ring-2 focus:ring-offset-2"
            style={{ 
              backgroundColor: buttonColor, 
              color: buttonTextColor,
              borderColor: 'transparent'
            }}
          >
            Add to Cart
          </button>
          <button 
            type="button" 
            className="flex-1 bg-white border border-gray-300 rounded-md py-2 px-4 flex items-center justify-center text-sm font-medium text-shopify-text hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2"
          >
            No Thanks
          </button>
        </div>
      </div>
    </div>
  );
}
