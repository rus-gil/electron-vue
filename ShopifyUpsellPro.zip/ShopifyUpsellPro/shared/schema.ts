import { pgTable, text, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

// Offer schema
export const offers = pgTable("offers", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  triggerProduct: text("trigger_product").notNull(),
  upsellProduct: text("upsell_product").notNull(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  active: boolean("active").default(true),
  backgroundColor: text("background_color").default("#ffffff"),
  textColor: text("text_color").default("#212b36"),
  buttonColor: text("button_color").default("#008060"),
  buttonTextColor: text("button_text_color").default("#ffffff"),
  customCSS: text("custom_css").default(""),
  customJS: text("custom_js").default(""),
  displayCondition: text("display_condition").default("all"),
  limitDisplays: boolean("limit_displays").default(false),
  skipCart: boolean("skip_cart").default(false),
  createdAt: timestamp("created_at").defaultNow(),
  conversions: integer("conversions").default(0),
  displays: integer("displays").default(0),
});

export const insertOfferSchema = createInsertSchema(offers).omit({
  id: true,
  createdAt: true,
  conversions: true,
  displays: true,
});

export type InsertOffer = z.infer<typeof insertOfferSchema>;
export type Offer = typeof offers.$inferSelect;
