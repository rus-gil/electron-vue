import '@shopify/shopify-api/adapters/node';
import { shopifyApi, LATEST_API_VERSION, ApiVersion } from '@shopify/shopify-api';
import { restResources } from '@shopify/shopify-api/rest/admin/2023-10';
import { Express, Request, Response, NextFunction } from 'express';

// Load environment variables
const {
  SHOPIFY_API_KEY,
  SHOPIFY_API_SECRET,
  SHOPIFY_API_SCOPES,
  SHOPIFY_APP_URL,
  SHOPIFY_WEBHOOK_SECRET
} = process.env;

// Initialize Shopify API
export const shopify = shopifyApi({
  apiKey: SHOPIFY_API_KEY || 'placeholder_api_key',
  apiSecretKey: SHOPIFY_API_SECRET || 'placeholder_api_secret',
  scopes: (SHOPIFY_API_SCOPES || 'write_products,read_orders,read_customers,write_script_tags').split(','),
  hostName: SHOPIFY_APP_URL ? new URL(SHOPIFY_APP_URL).hostname : 'localhost:5000',
  apiVersion: ApiVersion.October23,
  isEmbeddedApp: true,
  restResources
});

/**
 * Middleware to check if the request is authenticated
 */
export const shopifyAuth = async (req: Request, res: Response, next: NextFunction) => {
  // Skip auth for certain public endpoints
  const publicPaths = ['/auth', '/auth/callback', '/api/script', '/api/post-purchase-script'];
  if (publicPaths.some(path => req.path.startsWith(path))) {
    return next();
  }

  // DEVELOPMENT MODE: Skip authentication for all requests during development
  // In a production environment, this would be replaced with proper Shopify authentication
  if (process.env.NODE_ENV === 'development') {
    console.log('DEV MODE: Skipping authentication for', req.path);
    return next();
  }

  try {
    // Check for session token in headers
    const sessionId = req.headers['x-shopify-session-id'] as string;
    if (!sessionId) {
      return res.status(401).json({ message: 'Authentication required' });
    }

    // Validate session (in a real app, you would load the session from a database)
    // For this demo version, we'll allow all authenticated requests
    next();
  } catch (error) {
    console.error('Authentication error:', error);
    res.status(401).json({ message: 'Authentication failed' });
  }
};

/**
 * Configure Shopify auth routes
 */
export const setupShopifyAuth = (app: Express) => {
  // Auth route - redirects to Shopify OAuth page
  app.get('/auth', async (req, res) => {
    // In a real app, you would generate an OAuth URL using the Shopify API
    const shop = req.query.shop as string;
    if (!shop) {
      return res.status(400).json({ message: 'Missing shop parameter' });
    }

    try {
      // Generate auth URL
      const authUrl = await shopify.auth.beginAuth({
        shop,
        callbackPath: '/auth/callback',
        isOnline: false,
      });
      
      res.redirect(authUrl);
    } catch (error) {
      console.error('Auth error:', error);
      res.status(500).json({ message: 'Failed to authenticate with Shopify' });
    }
  });

  // Auth callback route - handles the OAuth callback from Shopify
  app.get('/auth/callback', async (req, res) => {
    try {
      // In a real app, you would exchange the auth code for a token
      // and store the session in a database
      const shop = req.query.shop as string;
      
      // Complete auth process
      const session = await shopify.auth.validateAuthCallback({
        rawRequest: req,
        rawResponse: res,
      });
      
      // Store session in database here
      
      // Redirect to app
      res.redirect(`/?shop=${shop}`);
    } catch (error) {
      console.error('Auth callback error:', error);
      res.status(500).json({ message: 'Failed to complete authentication' });
    }
  });
};

/**
 * Configure webhook handlers
 */
export const setupShopifyWebhooks = (app: Express) => {
  // Webhook route for app uninstallation
  app.post('/webhooks/app/uninstalled', async (req, res) => {
    // Verify webhook (in a real app, you would use shopify.webhooks.validate)
    try {
      // Process webhook
      console.log('App uninstalled webhook received');
      
      // Clean up user data here
      
      res.status(200).send();
    } catch (error) {
      console.error('Webhook error:', error);
      res.status(401).send('Webhook verification failed');
    }
  });

  // Webhook route for orders
  app.post('/webhooks/orders/create', async (req, res) => {
    try {
      // Process webhook
      console.log('Order created webhook received');
      
      // Process order data here
      
      res.status(200).send();
    } catch (error) {
      console.error('Webhook error:', error);
      res.status(401).send('Webhook verification failed');
    }
  });
};

/**
 * Register webhooks with Shopify
 */
export const registerWebhooks = async (shop: string, accessToken: string) => {
  try {
    // In a real app, you would use the Shopify API to register webhooks
    console.log(`Registering webhooks for ${shop}`);
    
    // Register app uninstalled webhook
    await shopify.webhooks.addHandlers({
      APP_UNINSTALLED: {
        deliveryMethod: shopify.webhooks.DeliveryMethod.Http,
        callbackUrl: '/webhooks/app/uninstalled',
      },
      ORDERS_CREATE: {
        deliveryMethod: shopify.webhooks.DeliveryMethod.Http,
        callbackUrl: '/webhooks/orders/create',
      },
    });
    
    console.log('Webhooks registered successfully');
  } catch (error) {
    console.error('Failed to register webhooks:', error);
  }
};