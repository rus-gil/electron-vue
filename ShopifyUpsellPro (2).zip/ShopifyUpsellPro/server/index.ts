import express, { type Request, Response, NextFunction } from "express";
import { registerRoutes } from "./routes";
import { setupVite, serveStatic, log } from "./vite";
import { shopifyAuth, setupShopifyAuth, setupShopifyWebhooks } from "./shopify";
import cors from "cors";

const app = express();

// Configure CORS for Shopify domains
app.use(cors({
  origin: (origin, callback) => {
    // Allow requests with no origin (like mobile apps or curl requests)
    if (!origin) return callback(null, true);
    
    // Allow all myshopify.com domains, Replit domains, and local development
    const allowedOrigins = [
      /\.myshopify\.com$/,
      /^https:\/\/admin\.shopify\.com/,
      /^http:\/\/localhost/,
      /\.replit\.app$/,
      /\.repl\.co$/
    ];
    
    // In development mode, allow all origins for testing
    if (process.env.NODE_ENV === 'development') {
      return callback(null, true);
    }
    
    const allowed = allowedOrigins.some(pattern => pattern.test(origin));
    if (allowed) {
      callback(null, true);
    } else {
      callback(new Error("Not allowed by CORS"));
    }
  },
  credentials: true
}));

app.use(express.json());
app.use(express.urlencoded({ extended: false }));

// Add Shopify authentication middleware
app.use(shopifyAuth);

app.use((req, res, next) => {
  const start = Date.now();
  const path = req.path;
  let capturedJsonResponse: Record<string, any> | undefined = undefined;

  const originalResJson = res.json;
  res.json = function (bodyJson, ...args) {
    capturedJsonResponse = bodyJson;
    return originalResJson.apply(res, [bodyJson, ...args]);
  };

  res.on("finish", () => {
    const duration = Date.now() - start;
    if (path.startsWith("/api")) {
      let logLine = `${req.method} ${path} ${res.statusCode} in ${duration}ms`;
      if (capturedJsonResponse) {
        logLine += ` :: ${JSON.stringify(capturedJsonResponse)}`;
      }

      if (logLine.length > 80) {
        logLine = logLine.slice(0, 79) + "…";
      }

      log(logLine);
    }
  });

  next();
});

(async () => {
  // Set up Shopify auth routes and webhooks first
  setupShopifyAuth(app);
  setupShopifyWebhooks(app);
  
  // Then register our API routes
  const server = await registerRoutes(app);

  app.use((err: any, _req: Request, res: Response, _next: NextFunction) => {
    const status = err.status || err.statusCode || 500;
    const message = err.message || "Internal Server Error";

    res.status(status).json({ message });
    console.error(err);
  });

  // importantly only setup vite in development and after
  // setting up all the other routes so the catch-all route
  // doesn't interfere with the other routes
  if (app.get("env") === "development") {
    await setupVite(app, server);
  } else {
    serveStatic(app);
  }

  // ALWAYS serve the app on port 5000
  // this serves both the API and the client.
  // It is the only port that is not firewalled.
  const port = 5000;
  server.listen({
    port,
    host: "0.0.0.0",
    reusePort: true,
  }, () => {
    log(`serving on port ${port}`);
    log(`Shopify app is running at http://localhost:${port}`);
    log(`To test with Shopify, create a tunnel to this URL and set it in your Shopify app settings`);
  });
})();
