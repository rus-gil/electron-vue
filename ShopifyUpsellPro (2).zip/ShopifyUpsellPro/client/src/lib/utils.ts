import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function formatDate(date: Date): string {
  const options: Intl.DateTimeFormatOptions = { 
    year: 'numeric', 
    month: 'long', 
    day: 'numeric' 
  };
  return new Date(date).toLocaleDateString(undefined, options);
}

export function calculateConversionRate(conversions: number, displays: number): string {
  if (displays === 0) return '0%';
  const rate = (conversions / displays) * 100;
  return `${rate.toFixed(0)}% (${conversions}/${displays})`;
}

export function truncateText(text: string, maxLength: number): string {
  if (text.length <= maxLength) return text;
  return text.slice(0, maxLength) + '...';
}

export function getStatusElement(isActive: boolean) {
  return {
    label: isActive ? 'Active' : 'Inactive',
    className: isActive 
      ? 'bg-shopify-success bg-opacity-20 text-shopify-green' 
      : 'bg-gray-100 text-gray-500'
  };
}

export const displayConditionOptions = [
  { value: 'all', label: 'Show to all customers' },
  { value: 'new', label: 'Show to new customers only' },
  { value: 'returning', label: 'Show to returning customers only' },
  { value: 'cart', label: 'Show based on cart value' }
];
