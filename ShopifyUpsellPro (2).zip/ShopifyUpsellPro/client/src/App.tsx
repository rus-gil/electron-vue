import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import Layout from "./components/Layout";
import Home from "./pages/home";
import Analytics from "./pages/analytics";
import Settings from "./pages/settings";
import NotFound from "./pages/not-found";
import { ShopifyProvider, AuthRedirector } from "./components/ShopifyProvider";

function Router() {
  return (
    <Layout>
      <Switch>
        <Route path="/" component={Home} />
        <Route path="/analytics" component={Analytics} />
        <Route path="/settings" component={Settings} />
        <Route component={NotFound} />
      </Switch>
    </Layout>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <ShopifyProvider>
        <TooltipProvider>
          <Toaster />
          {/* Add AuthRedirector to handle Shopify authentication redirects */}
          <AuthRedirector />
          <Router />
        </TooltipProvider>
      </ShopifyProvider>
    </QueryClientProvider>
  );
}

export default App;
