import React, { useEffect, useState, createContext, useContext } from 'react';
import { useLocation, useRoute } from 'wouter';

// Create the context to hold Shopify-related state
type ShopifyContextType = {
  shop: string | null;
  isLoading: boolean;
  isEmbedded: boolean;
  isAuthenticated: boolean;
};

const ShopifyContext = createContext<ShopifyContextType>({
  shop: null,
  isLoading: true,
  isEmbedded: false,
  isAuthenticated: false,
});

/**
 * A component that provides the Shopify app context
 */
export function ShopifyProvider({ children }: { children: React.ReactNode }) {
  const [shop, setShop] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isEmbedded, setIsEmbedded] = useState(false);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  
  const [location] = useLocation();
  const [match, params] = useRoute('/?:shop');

  useEffect(() => {
    // Function to extract the shop from URL parameters
    function getShopFromQuery() {
      const params = new URLSearchParams(window.location.search);
      return params.get('shop');
    }

    // Initialize shop information
    const shopParam = params?.shop || getShopFromQuery();
    if (shopParam) {
      setShop(shopParam);
      
      // Check if we're embedded in Shopify
      const embedded = window.top !== window.self;
      setIsEmbedded(embedded);
      
      // Check if we have an auth session
      // In a real implementation, this would be a server-side check
      // In development, we'll also pass the shop as a query parameter to make testing easier
      const url = `/api/shop-info?shop=${encodeURIComponent(shopParam)}`;
      
      fetch(url, {
        headers: {
          'Accept': 'application/json',
          'X-Shop-Domain': shopParam
        }
      })
        .then(response => {
          if (response.ok) {
            return response.json();
          }
          throw new Error('Not authenticated');
        })
        .then((data) => {
          setIsAuthenticated(data.isAuthenticated);
        })
        .catch((err) => {
          console.log('Authentication error:', err);
          setIsAuthenticated(false);
        })
        .finally(() => {
          setIsLoading(false);
        });
    } else {
      setIsLoading(false);
    }
  }, [location, params]);

  // Provide context value
  const contextValue = {
    shop,
    isLoading,
    isEmbedded,
    isAuthenticated
  };

  return (
    <ShopifyContext.Provider value={contextValue}>
      {children}
    </ShopifyContext.Provider>
  );
}

/**
 * A hook to use Shopify context
 */
export function useShopify() {
  return useContext(ShopifyContext);
}

/**
 * A component to handle authentication redirections
 */
export function AuthRedirector() {
  const { shop, isAuthenticated, isLoading } = useShopify();

  useEffect(() => {
    // Only redirect if we have loaded auth state and determined we're not authenticated
    if (!isLoading && shop && !isAuthenticated) {
      // Redirect to auth
      window.location.href = `/auth?shop=${shop}`;
    }
  }, [shop, isAuthenticated, isLoading]);

  return null;
}