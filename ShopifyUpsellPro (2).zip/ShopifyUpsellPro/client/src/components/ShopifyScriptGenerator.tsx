import React from 'react';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast';

/**
 * Component to generate and display the Shopify script tag installation
 */
export default function ShopifyScriptGenerator() {
  const { toast } = useToast();
  const [scriptUrl, setScriptUrl] = React.useState<string>('');
  const [scriptTagId, setScriptTagId] = React.useState<string>('');
  const [isLoading, setIsLoading] = React.useState<boolean>(false);
  
  // Copy script URL to clipboard
  const handleCopyUrl = () => {
    if (!scriptUrl) return;
    
    navigator.clipboard.writeText(scriptUrl)
      .then(() => {
        toast({
          title: "URL copied to clipboard",
          description: "The script URL has been copied to your clipboard."
        });
      })
      .catch(() => {
        toast({
          title: "Failed to copy URL",
          description: "Please try selecting and copying the URL manually.",
          variant: "destructive"
        });
      });
  };
  
  // Create a new script tag in the Shopify store
  const handleCreateScriptTag = async () => {
    setIsLoading(true);
    
    try {
      // Get the shop from URL query parameters
      const params = new URLSearchParams(window.location.search);
      const shop = params.get('shop');
      
      if (!shop) {
        throw new Error("No shop found. Please ensure you're accessing this app through Shopify.");
      }
      
      // Create a script tag using our API endpoint
      const response = await fetch('/api/shopify/script-tags', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ shop }),
      });
      
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || "Failed to create script tag");
      }
      
      const scriptTag = await response.json();
      
      // Set the script URL and ID for display
      setScriptUrl(scriptTag.src);
      setScriptTagId(scriptTag.id);
      
      toast({
        title: "Script tag created",
        description: "The script tag has been created and is active in your store."
      });
    } catch (error: any) {
      console.error("Script creation error:", error);
      toast({
        title: "Failed to create script tag",
        description: error.message || "An error occurred while creating the script tag.",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };
  
  // Delete a script tag from the Shopify store
  const handleDeleteScriptTag = async () => {
    if (!scriptTagId) return;
    
    setIsLoading(true);
    
    try {
      // Get the shop from URL query parameters
      const params = new URLSearchParams(window.location.search);
      const shop = params.get('shop');
      
      if (!shop) {
        throw new Error("No shop found. Please ensure you're accessing this app through Shopify.");
      }
      
      // Delete the script tag using our API endpoint
      const response = await fetch(`/api/shopify/script-tags/${scriptTagId}?shop=${encodeURIComponent(shop)}`, {
        method: 'DELETE',
      });
      
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || "Failed to delete script tag");
      }
      
      setScriptUrl('');
      setScriptTagId('');
      
      toast({
        title: "Script tag deleted",
        description: "The script tag has been removed from your store."
      });
    } catch (error: any) {
      console.error("Script deletion error:", error);
      toast({
        title: "Failed to delete script tag",
        description: error.message || "An error occurred while deleting the script tag.",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };
  
  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle>Shopify Script Tag</CardTitle>
        <CardDescription>
          This script will be loaded on your Shopify store to enable the pre-purchase and post-purchase offers.
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {scriptUrl ? (
          <>
            <div className="space-y-2">
              <Label htmlFor="script-url">Script URL</Label>
              <div className="flex items-center gap-2">
                <Input 
                  id="script-url" 
                  value={scriptUrl} 
                  readOnly 
                  className="font-mono text-sm"
                />
                <Button variant="outline" size="sm" onClick={handleCopyUrl}>
                  Copy
                </Button>
              </div>
              <p className="text-sm text-muted-foreground">
                Script tag ID: {scriptTagId}
              </p>
            </div>
            <div className="bg-muted p-4 rounded-md">
              <p className="text-sm">
                This script tag is automatically installed on your Shopify store via the Shopify API.
                It will trigger the pre-purchase offers when customers add products to their cart.
              </p>
            </div>
          </>
        ) : (
          <div className="bg-muted p-4 rounded-md">
            <p className="text-sm">
              No script tag is currently installed. Click "Install Script" to add the script tag to your Shopify store.
            </p>
          </div>
        )}
      </CardContent>
      <CardFooter>
        {scriptUrl ? (
          <Button variant="destructive" onClick={handleDeleteScriptTag} disabled={isLoading}>
            {isLoading ? "Removing..." : "Remove Script"}
          </Button>
        ) : (
          <Button onClick={handleCreateScriptTag} disabled={isLoading}>
            {isLoading ? "Installing..." : "Install Script"}
          </Button>
        )}
      </CardFooter>
    </Card>
  );
}