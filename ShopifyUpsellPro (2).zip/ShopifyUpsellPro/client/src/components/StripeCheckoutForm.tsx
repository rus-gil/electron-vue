import { useState } from 'react';
import { useStripe, useElements, PaymentElement } from '@stripe/react-stripe-js';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';
import { AlertCircle, CheckCircle } from 'lucide-react';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { apiRequest } from '@/lib/queryClient';

interface StripeCheckoutFormProps {
  onSuccess: () => void;
  onCancel: () => void;
}

export default function StripeCheckoutForm({ onSuccess, onCancel }: StripeCheckoutFormProps) {
  const stripe = useStripe();
  const elements = useElements();
  const { toast } = useToast();
  const [isProcessing, setIsProcessing] = useState(false);
  const [paymentError, setPaymentError] = useState<string | null>(null);
  const [paymentSuccess, setPaymentSuccess] = useState(false);

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();

    if (!stripe || !elements) {
      // Stripe.js hasn't loaded yet
      return;
    }

    setIsProcessing(true);
    setPaymentError(null);

    // Confirm the payment
    const { error } = await stripe.confirmPayment({
      elements,
      confirmParams: {
        return_url: window.location.origin,
      },
      redirect: 'if_required',
    });

    if (error) {
      setPaymentError(error.message || 'An unexpected error occurred');
      setIsProcessing(false);
    } else {
      // Payment succeeded
      setPaymentSuccess(true);
      
      // Notify the server of successful payment
      try {
        await apiRequest('POST', '/api/payment-success');
        toast({
          title: "Premium activated!",
          description: "You now have access to post-purchase offers and other premium features.",
        });
        onSuccess();
      } catch (err) {
        toast({
          title: "Payment successful, but activation failed",
          description: "Your payment was processed but there was an issue activating your premium status. Please contact support.",
          variant: "destructive",
        });
      }
      
      setIsProcessing(false);
    }
  };

  return (
    <div className="space-y-6">
      {paymentError && (
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>Payment Error</AlertTitle>
          <AlertDescription>{paymentError}</AlertDescription>
        </Alert>
      )}
      
      {paymentSuccess ? (
        <Alert className="bg-green-50 border-green-200">
          <CheckCircle className="h-4 w-4 text-green-600" />
          <AlertTitle className="text-green-800">Payment Successful</AlertTitle>
          <AlertDescription className="text-green-700">
            Your premium subscription has been activated. You now have access to all premium features.
          </AlertDescription>
        </Alert>
      ) : (
        <form onSubmit={handleSubmit} className="space-y-6">
          <PaymentElement />
          
          <div className="flex justify-between pt-2">
            <Button
              type="button"
              variant="outline"
              onClick={onCancel}
              disabled={isProcessing}
            >
              Cancel
            </Button>
            
            <Button
              type="submit"
              disabled={!stripe || isProcessing}
              className="bg-shopify-green hover:bg-shopify-green/90 text-white"
            >
              {isProcessing ? "Processing..." : "Subscribe Now"}
            </Button>
          </div>
        </form>
      )}
    </div>
  );
}