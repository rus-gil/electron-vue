import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";
import { BarChart3, Package, Settings, HelpCircle, Plus } from "lucide-react";

export default function Sidebar() {
  const [location] = useLocation();

  const navItems = [
    {
      label: "Offers",
      href: "/",
      icon: Package,
      active: location === "/" || location.startsWith("/offers"),
    },
    {
      label: "Analytics",
      href: "/analytics",
      icon: BarChart3,
      active: location === "/analytics",
    },
    {
      label: "Settings",
      href: "/settings",
      icon: Settings,
      active: location === "/settings",
    },
  ];

  return (
    <div className="w-64 bg-white border-r border-gray-200 flex flex-col h-full">
      <div className="p-4 border-b border-gray-200">
        <h1 className="text-lg font-semibold text-shopify-ink">Upsell Buddy</h1>
        <p className="text-sm text-shopify-text">Pre-purchase offers made easy</p>
      </div>
      
      <nav className="flex-1 p-2">
        {navItems.map((item) => (
          <Link 
            key={item.href} 
            href={item.href}
            className={cn(
              "flex items-center px-3 py-2 text-sm font-medium rounded-md mb-1",
              item.active 
                ? "bg-shopify-green text-white" 
                : "text-shopify-ink hover:bg-gray-100"
            )}
          >
            <item.icon className="h-5 w-5 mr-2" />
            {item.label}
          </Link>
        ))}
      </nav>
      
      <div className="p-4 border-t border-gray-200">
        <a 
          href="#" 
          className="flex items-center text-sm text-shopify-purple hover:text-shopify-ink"
        >
          <HelpCircle className="h-5 w-5 mr-2" />
          Help Center
        </a>
      </div>
    </div>
  );
}
