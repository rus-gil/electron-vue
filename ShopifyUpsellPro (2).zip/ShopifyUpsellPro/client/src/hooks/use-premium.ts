import { useMutation, useQuery } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useState } from "react";

export function usePremiumStatus() {
  const { toast } = useToast();
  const [showCheckout, setShowCheckout] = useState(false);
  
  // Query to get the current premium status
  const premiumStatusQuery = useQuery({
    queryKey: ['/api/premium-status'],
    queryFn: async () => {
      const res = await apiRequest('GET', '/api/premium-status');
      const data = await res.json();
      return data;
    },
  });

  // Mutation to initiate subscription process
  const subscribeMutation = useMutation({
    mutationFn: async () => {
      // Instead of directly activating, we'll open the checkout modal
      return { success: true };
    },
    onSuccess: () => {
      // Show the Stripe checkout dialog instead of directly processing
      setShowCheckout(true);
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to start checkout",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Mutation to cancel subscription
  const cancelSubscriptionMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest('POST', '/api/cancel-subscription');
      return res.json();
    },
    onSuccess: () => {
      toast({
        title: "Subscription canceled",
        description: "Your premium subscription has been canceled.",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/premium-status'] });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to cancel subscription",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Function to handle successful checkout
  const handleCheckoutSuccess = () => {
    // Close the checkout modal
    setShowCheckout(false);
    
    // Refresh the premium status
    queryClient.invalidateQueries({ queryKey: ['/api/premium-status'] });
  };

  return {
    isPremium: premiumStatusQuery.data?.isPremium ?? false,
    isLoading: premiumStatusQuery.isLoading,
    subscribe: subscribeMutation.mutate,
    isSubscribing: subscribeMutation.isPending,
    cancelSubscription: cancelSubscriptionMutation.mutate,
    isCanceling: cancelSubscriptionMutation.isPending,
    showCheckout,
    setShowCheckout,
    handleCheckoutSuccess,
  };
}