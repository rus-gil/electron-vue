import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useOffers } from "@/hooks/use-offers";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";

export default function Analytics() {
  const { offers, isLoading } = useOffers();
  
  const chartData = offers.map(offer => ({
    name: offer.name,
    displays: offer.displays,
    conversions: offer.conversions,
    rate: offer.displays ? Math.round((offer.conversions / offer.displays) * 100) : 0
  }));
  
  const totalDisplays = offers.reduce((sum, offer) => sum + offer.displays, 0);
  const totalConversions = offers.reduce((sum, offer) => sum + offer.conversions, 0);
  const averageRate = totalDisplays ? Math.round((totalConversions / totalDisplays) * 100) : 0;
  
  return (
    <>
      <header className="bg-white border-b border-gray-200 px-6 py-4">
        <div className="flex justify-between items-center">
          <h1 className="text-xl font-semibold text-shopify-ink">Analytics</h1>
        </div>
      </header>
      
      <div className="p-6">
        <div className="grid gap-4 md:grid-cols-3 mb-6">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-shopify-text">Total Displays</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{totalDisplays}</div>
              <p className="text-xs text-shopify-text mt-1">Number of times offers were shown</p>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-shopify-text">Total Conversions</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{totalConversions}</div>
              <p className="text-xs text-shopify-text mt-1">Number of accepted offers</p>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-shopify-text">Average Conversion Rate</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{averageRate}%</div>
              <p className="text-xs text-shopify-text mt-1">Percentage of offers accepted</p>
            </CardContent>
          </Card>
        </div>
        
        <Card className="mb-6">
          <CardHeader>
            <CardTitle>Offer Performance</CardTitle>
            <CardDescription>Displays and conversions for each of your offers</CardDescription>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="h-80 flex items-center justify-center">Loading chart data...</div>
            ) : chartData.length === 0 ? (
              <div className="h-80 flex items-center justify-center text-shopify-text">
                No data available yet. Create offers to see performance.
              </div>
            ) : (
              <div className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart
                    data={chartData}
                    margin={{ top: 20, right: 30, left: 20, bottom: 70 }}
                  >
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis 
                      dataKey="name" 
                      angle={-45} 
                      textAnchor="end" 
                      height={70} 
                      tick={{ fontSize: 12 }}
                    />
                    <YAxis />
                    <Tooltip />
                    <Bar dataKey="displays" name="Displays" fill="hsl(var(--chart-1))" />
                    <Bar dataKey="conversions" name="Conversions" fill="hsl(var(--chart-2))" />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            )}
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader>
            <CardTitle>Conversion Rates</CardTitle>
            <CardDescription>Percentage of displays that result in conversions</CardDescription>
          </CardHeader>
          <CardContent>
            {isLoading ? (
              <div className="h-80 flex items-center justify-center">Loading chart data...</div>
            ) : chartData.length === 0 ? (
              <div className="h-80 flex items-center justify-center text-shopify-text">
                No data available yet. Create offers to see performance.
              </div>
            ) : (
              <div className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart
                    data={chartData}
                    margin={{ top: 20, right: 30, left: 20, bottom: 70 }}
                  >
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis 
                      dataKey="name" 
                      angle={-45} 
                      textAnchor="end" 
                      height={70} 
                      tick={{ fontSize: 12 }}
                    />
                    <YAxis domain={[0, 100]} unit="%" />
                    <Tooltip formatter={(value) => [`${value}%`, 'Conversion Rate']} />
                    <Bar dataKey="rate" name="Conversion Rate" fill="hsl(var(--chart-3))" />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </>
  );
}
